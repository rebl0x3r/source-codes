using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using CommonSender;
using Microsoft.VisualBasic;

namespace HeartSender;

public class BulkSMTP : Form
{
	public Main main;

	private int selected_index = -1;

	private IContainer components;

	private Button btnAllSMTPChecker;

	private DataGridView gridSMTPs;

	private GroupBox groupBox3;

	private DataGridViewTextBoxColumn Host;

	private DataGridViewTextBoxColumn Port;

	private DataGridViewTextBoxColumn Username;

	private DataGridViewTextBoxColumn Password;

	private DataGridViewCheckBoxColumn Secure;

	private DataGridViewTextBoxColumn Status;

	private Button btnImport;

	private Button btnClear;

	public BulkSMTP(Main _main)
	{
		InitializeComponent();
		main = _main;
	}

	private void btnAllSMTPChecker_Click(object sender, EventArgs e)
	{
		Rectangle screensize = Screen.PrimaryScreen.Bounds;
		string input = Interaction.InputBox("Your Email:", "Input Your Email to Check SMTP:", "", screensize.Width / 2 - 200, screensize.Height / 2);
		if (input == "" && input.Split('@').Length != 2)
		{
			MessageBox.Show("Please enter valid email address.", "HeartSender");
			return;
		}
		btnAllSMTPChecker.Enabled = false;
		GxApi api = new GxApi();
		for (int index = 0; index < gridSMTPs.Rows.Count; index++)
		{
			if (gridSMTPs.Rows[index].Cells["Host"].Value.ToString().Trim().Length != 0 && int.Parse(gridSMTPs.Rows[index].Cells["Port"].Value.ToString()) > 0 && gridSMTPs.Rows[index].Cells["Username"].Value.ToString().Trim().Length != 0 && gridSMTPs.Rows[index].Cells["Password"].Value.ToString().Trim().Length != 0)
			{
				GxSMTP new_smtp = new GxSMTP();
				new_smtp.host = gridSMTPs.Rows[index].Cells["Host"].Value.ToString().Trim();
				new_smtp.port = int.Parse(gridSMTPs.Rows[index].Cells["Port"].Value.ToString().Trim());
				new_smtp.username = gridSMTPs.Rows[index].Cells["Username"].Value.ToString().Trim();
				new_smtp.password = gridSMTPs.Rows[index].Cells["Password"].Value.ToString().Trim();
				new_smtp.secure = false;
				if (gridSMTPs.Rows[index].Cells["Secure"].Value != null)
				{
					new_smtp.secure = (bool)gridSMTPs.Rows[index].Cells["Secure"].Value;
				}
				gridSMTPs.Rows[index].Cells["Status"].Value = api.isValidSMTP(GxConfig.baseUrl() + "backend/smtp-checker", new string[7]
				{
					new_smtp.host.Trim(),
					new_smtp.username.Trim(),
					new_smtp.password.Trim(),
					new_smtp.port.ToString().Trim(),
					new_smtp.secure ? "1" : "0",
					"sender@oneskyrocket.com",
					input.Trim()
				});
			}
		}
		btnAllSMTPChecker.Enabled = true;
	}

	private void BulkSMTP_FormClosing(object sender, FormClosingEventArgs e)
	{
		Main.bulk_smtps.Clear();
		for (int index = 0; index < gridSMTPs.Rows.Count; index++)
		{
			try
			{
				if (gridSMTPs.Rows[index] == null || (gridSMTPs.Rows[index].Cells["Host"].Value.ToString().Trim().Length != 0 && int.Parse(gridSMTPs.Rows[index].Cells["Port"].Value.ToString()) > 0 && gridSMTPs.Rows[index].Cells["Username"].Value.ToString().Trim().Length != 0 && gridSMTPs.Rows[index].Cells["Password"].Value.ToString().Trim().Length != 0))
				{
					GxSMTP new_smtp = new GxSMTP();
					new_smtp.host = gridSMTPs.Rows[index].Cells["Host"].Value.ToString().Trim();
					new_smtp.port = int.Parse(gridSMTPs.Rows[index].Cells["Port"].Value.ToString().Trim());
					new_smtp.username = gridSMTPs.Rows[index].Cells["Username"].Value.ToString().Trim();
					new_smtp.password = gridSMTPs.Rows[index].Cells["Password"].Value.ToString().Trim();
					new_smtp.secure = false;
					if (gridSMTPs.Rows[index].Cells["Secure"].Value != null)
					{
						new_smtp.secure = (bool)gridSMTPs.Rows[index].Cells["Secure"].Value;
					}
					Main.bulk_smtps.Add(new_smtp);
				}
			}
			catch (Exception)
			{
			}
		}
	}

	private void BulkSMTP_Load(object sender, EventArgs e)
	{
		if (Main.bulk_smtps.Count <= 0)
		{
			return;
		}
		int index = 0;
		foreach (GxSMTP smtp in Main.bulk_smtps)
		{
			index = gridSMTPs.Rows.Add();
			gridSMTPs.Rows[index].Cells["Host"].Value = smtp.host;
			gridSMTPs.Rows[index].Cells["Port"].Value = smtp.port.ToString();
			gridSMTPs.Rows[index].Cells["Username"].Value = smtp.username;
			gridSMTPs.Rows[index].Cells["Password"].Value = smtp.password;
			gridSMTPs.Rows[index].Cells["Secure"].Value = smtp.secure;
			gridSMTPs.Rows[index].Cells["Status"].Value = "";
		}
	}

	private void gridSMTPs_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
	{
		e.Control.KeyPress -= Port_KeyPress;
		if (gridSMTPs.CurrentCell.ColumnIndex == 1 && e.Control is TextBox tb)
		{
			tb.KeyPress += Port_KeyPress;
		}
	}

	private void Port_KeyPress(object sender, KeyPressEventArgs e)
	{
		if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
		{
			e.Handled = true;
		}
	}

	private void gridSMTPs_MouseClick(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Right)
		{
			if (gridSMTPs.HitTest(e.X, e.Y) != null)
			{
				selected_index = gridSMTPs.HitTest(e.X, e.Y).RowIndex;
			}
			ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
			contextMenuStrip.Items.Add("Add SMTP");
			contextMenuStrip.Items.Add("Add in Library");
			contextMenuStrip.Items.Add("Remove SMTP");
			contextMenuStrip.Show(gridSMTPs, new Point(e.X, e.Y));
			contextMenuStrip.ItemClicked += contexMenu_ItemClicked;
		}
	}

	private void contexMenu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
	{
		ToolStripItem item = e.ClickedItem;
		if (gridSMTPs.Rows.Count > 0)
		{
			if (item.Text == "Add in Library" && selected_index >= 0)
			{
				GxSMTP new_smtp = new GxSMTP();
				new_smtp.host = gridSMTPs.Rows[selected_index].Cells["Host"].Value.ToString().Trim();
				new_smtp.port = int.Parse(gridSMTPs.Rows[selected_index].Cells["Port"].Value.ToString().Trim());
				new_smtp.username = gridSMTPs.Rows[selected_index].Cells["Username"].Value.ToString().Trim();
				new_smtp.password = gridSMTPs.Rows[selected_index].Cells["Password"].Value.ToString().Trim();
				new_smtp.secure = false;
				if (gridSMTPs.Rows[selected_index].Cells["Secure"].Value != null)
				{
					new_smtp.secure = (bool)gridSMTPs.Rows[selected_index].Cells["Secure"].Value;
				}
				Main.smtps.Add(new_smtp);
				main.populateSMTPs();
			}
			else if (item.Text == "Remove SMTP" && selected_index >= 0)
			{
				gridSMTPs.Rows.RemoveAt(selected_index);
			}
		}
		if (item.Text == "Add SMTP")
		{
			int index = gridSMTPs.Rows.Add();
			gridSMTPs.Rows[index].Cells["Host"].Value = "";
			gridSMTPs.Rows[index].Cells["Port"].Value = "";
			gridSMTPs.Rows[index].Cells["Username"].Value = "";
			gridSMTPs.Rows[index].Cells["Password"].Value = "";
			gridSMTPs.Rows[index].Cells["Secure"].Value = false;
		}
	}

	private void btnImport_Click(object sender, EventArgs e)
	{
		OpenFileDialog file = new OpenFileDialog();
		file.Filter = "txt files (*.txt)|*.txt";
		Stream stream;
		if (file.ShowDialog() == DialogResult.OK && (stream = file.OpenFile()) != null)
		{
			using (StreamReader sr = new StreamReader(stream))
			{
				string[] smtps = sr.ReadToEnd().Split(new string[3] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
				loadSMTPData(smtps);
			}
			stream.Close();
		}
	}

	public void loadSMTPData(string[] data)
	{
		try
		{
			int index = 0;
			Main.bulk_smtps.Clear();
			gridSMTPs.Rows.Clear();
			for (int i = 0; i < data.Length; i++)
			{
				string[] tokens = data[i].Split(new string[1] { "|" }, StringSplitOptions.None);
				index = gridSMTPs.Rows.Add();
				gridSMTPs.Rows[index].Cells["Host"].Value = tokens[0];
				gridSMTPs.Rows[index].Cells["Port"].Value = tokens[1];
				gridSMTPs.Rows[index].Cells["Username"].Value = tokens[2];
				gridSMTPs.Rows[index].Cells["Password"].Value = tokens[3];
				gridSMTPs.Rows[index].Cells["Secure"].Value = tokens[4] == "ssl" || tokens[4] == "tls";
				gridSMTPs.Rows[index].Cells["Status"].Value = "";
				GxSMTP new_smtp = new GxSMTP();
				new_smtp.host = gridSMTPs.Rows[index].Cells["Host"].Value.ToString();
				new_smtp.port = int.Parse(gridSMTPs.Rows[index].Cells["Port"].Value.ToString());
				new_smtp.username = gridSMTPs.Rows[index].Cells["Username"].Value.ToString();
				new_smtp.password = gridSMTPs.Rows[index].Cells["Password"].Value.ToString();
				new_smtp.secure = false;
				if (gridSMTPs.Rows[index].Cells["Secure"].Value != null)
				{
					new_smtp.secure = (bool)gridSMTPs.Rows[index].Cells["Secure"].Value;
				}
				Main.bulk_smtps.Add(new_smtp);
			}
		}
		catch (Exception)
		{
			MessageBox.Show("Sorry, Invalid file format.");
		}
	}

	private void btnClear_Click(object sender, EventArgs e)
	{
		gridSMTPs.Rows.Clear();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.BulkSMTP));
		this.btnAllSMTPChecker = new System.Windows.Forms.Button();
		this.gridSMTPs = new System.Windows.Forms.DataGridView();
		this.Host = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Port = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Username = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Secure = new System.Windows.Forms.DataGridViewCheckBoxColumn();
		this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.groupBox3 = new System.Windows.Forms.GroupBox();
		this.btnClear = new System.Windows.Forms.Button();
		this.btnImport = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)this.gridSMTPs).BeginInit();
		this.groupBox3.SuspendLayout();
		base.SuspendLayout();
		this.btnAllSMTPChecker.Image = (System.Drawing.Image)resources.GetObject("btnAllSMTPChecker.Image");
		this.btnAllSMTPChecker.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnAllSMTPChecker.Location = new System.Drawing.Point(536, 280);
		this.btnAllSMTPChecker.Name = "btnAllSMTPChecker";
		this.btnAllSMTPChecker.Size = new System.Drawing.Size(122, 36);
		this.btnAllSMTPChecker.TabIndex = 9;
		this.btnAllSMTPChecker.Text = "  Test All SMTP(s)";
		this.btnAllSMTPChecker.UseVisualStyleBackColor = true;
		this.btnAllSMTPChecker.Click += new System.EventHandler(btnAllSMTPChecker_Click);
		this.gridSMTPs.AllowUserToAddRows = false;
		this.gridSMTPs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.gridSMTPs.Columns.AddRange(this.Host, this.Port, this.Username, this.Password, this.Secure, this.Status);
		this.gridSMTPs.Location = new System.Drawing.Point(9, 18);
		this.gridSMTPs.Name = "gridSMTPs";
		this.gridSMTPs.RowHeadersWidth = 51;
		this.gridSMTPs.Size = new System.Drawing.Size(649, 256);
		this.gridSMTPs.TabIndex = 0;
		this.gridSMTPs.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(gridSMTPs_EditingControlShowing);
		this.gridSMTPs.MouseClick += new System.Windows.Forms.MouseEventHandler(gridSMTPs_MouseClick);
		this.Host.HeaderText = "Host";
		this.Host.MinimumWidth = 6;
		this.Host.Name = "Host";
		this.Host.Width = 125;
		this.Port.HeaderText = "Port";
		this.Port.MaxInputLength = 7;
		this.Port.MinimumWidth = 6;
		this.Port.Name = "Port";
		this.Port.Width = 125;
		this.Username.HeaderText = "Username";
		this.Username.MinimumWidth = 6;
		this.Username.Name = "Username";
		this.Username.Width = 125;
		this.Password.HeaderText = "Password";
		this.Password.MinimumWidth = 6;
		this.Password.Name = "Password";
		this.Password.Width = 125;
		this.Secure.HeaderText = "Secure";
		this.Secure.MinimumWidth = 6;
		this.Secure.Name = "Secure";
		this.Secure.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.Secure.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
		this.Secure.Width = 125;
		this.Status.HeaderText = "Status";
		this.Status.MinimumWidth = 6;
		this.Status.Name = "Status";
		this.Status.Width = 125;
		this.groupBox3.Controls.Add(this.btnClear);
		this.groupBox3.Controls.Add(this.btnImport);
		this.groupBox3.Controls.Add(this.btnAllSMTPChecker);
		this.groupBox3.Controls.Add(this.gridSMTPs);
		this.groupBox3.Location = new System.Drawing.Point(10, 6);
		this.groupBox3.Name = "groupBox3";
		this.groupBox3.Size = new System.Drawing.Size(670, 326);
		this.groupBox3.TabIndex = 10;
		this.groupBox3.TabStop = false;
		this.groupBox3.Text = "SMTP List";
		this.btnClear.Image = (System.Drawing.Image)resources.GetObject("btnClear.Image");
		this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnClear.Location = new System.Drawing.Point(9, 280);
		this.btnClear.Name = "btnClear";
		this.btnClear.Size = new System.Drawing.Size(101, 36);
		this.btnClear.TabIndex = 11;
		this.btnClear.Text = "Clear";
		this.btnClear.UseVisualStyleBackColor = true;
		this.btnClear.Click += new System.EventHandler(btnClear_Click);
		this.btnImport.Image = (System.Drawing.Image)resources.GetObject("btnImport.Image");
		this.btnImport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnImport.Location = new System.Drawing.Point(424, 280);
		this.btnImport.Name = "btnImport";
		this.btnImport.Size = new System.Drawing.Size(101, 36);
		this.btnImport.TabIndex = 10;
		this.btnImport.Text = "Import";
		this.btnImport.UseVisualStyleBackColor = true;
		this.btnImport.Click += new System.EventHandler(btnImport_Click);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(690, 341);
		base.Controls.Add(this.groupBox3);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "BulkSMTP";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Bulk SMTP Checker";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(BulkSMTP_FormClosing);
		base.Load += new System.EventHandler(BulkSMTP_Load);
		((System.ComponentModel.ISupportInitialize)this.gridSMTPs).EndInit();
		this.groupBox3.ResumeLayout(false);
		base.ResumeLayout(false);
	}
}
