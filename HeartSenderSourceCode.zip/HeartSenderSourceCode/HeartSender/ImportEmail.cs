using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace HeartSender;

public class ImportEmail : Form
{
	private string[] emails;

	private Main main;

	private BackgroundWorker worker = new BackgroundWorker();

	private Stream stream;

	private string file_type;

	private IContainer components;

	private GroupBox groupBox1;

	private GroupBox groupBox2;

	private RichTextBox txtEmailList;

	private Label label1;

	private Label lblCount;

	private Button btnImport;

	private Button btnAdd;

	private Button btnRmDpl;

	private ProgressBar ctrlProgress;

	public ImportEmail(Main _main)
	{
		InitializeComponent();
		main = _main;
	}

	private void btnAdd_Click(object sender, EventArgs e)
	{
		getEmails();
		Main.populateEmailsList(emails, main);
		Close();
	}

	private void btnImport_Click(object sender, EventArgs e)
	{
		OpenFileDialog file = new OpenFileDialog();
		file.Filter = "txt files (*.txt)|*.txt|CSV (*.csv)|*.csv";
		if (file.ShowDialog() != DialogResult.OK)
		{
			return;
		}
		stream = file.OpenFile();
		if (stream != null)
		{
			string[] tokens = file.FileName.Split('.');
			file_type = tokens[tokens.Length - 1];
			ctrlProgress.Minimum = 0;
			ctrlProgress.Maximum = 100;
			ctrlProgress.Value = 0;
			worker.DoWork += bgw_DoWork;
			worker.ProgressChanged += bgw_ProgressChanged;
			worker.RunWorkerCompleted += bgw_RunWorkerCompleted;
			worker.WorkerReportsProgress = true;
			worker.WorkerSupportsCancellation = true;
			if (!worker.IsBusy)
			{
				worker.RunWorkerAsync();
			}
		}
	}

	public void bgw_DoWork(object sender, DoWorkEventArgs e)
	{
		BackgroundWorker worker_job = sender as BackgroundWorker;
		using (StreamReader sr = new StreamReader(stream))
		{
			string s = string.Empty;
			int counter = 0;
			List<string> list = new List<string>();
			while ((s = sr.ReadLine()) != null && counter < 300000)
			{
				if (file_type.ToLower().Trim() == "csv")
				{
					string[] tokens = s.Trim().ToLower().Split(';');
					tokens = tokens[0].Trim().ToLower().Split(',');
					list.Add(tokens[0].Trim().ToLower());
				}
				else
				{
					list.Add(s.Trim().ToLower());
				}
				counter++;
			}
			worker_job.ReportProgress(10);
			try
			{
				Invoke((MethodInvoker)delegate
				{
					txtEmailList.Clear();
					txtEmailList.Text = string.Join("\n", list.ToArray());
					lblCount.Text = ((counter < 0) ? "0" : counter.ToString());
				});
				worker_job.ReportProgress(90);
			}
			catch (Exception)
			{
				MessageBox.Show("Sorry, Invalid file format.");
			}
		}
		stream.Close();
	}

	public void bgw_ProgressChanged(object sender, ProgressChangedEventArgs e)
	{
		if (ctrlProgress.Value + e.ProgressPercentage <= ctrlProgress.Maximum)
		{
			ctrlProgress.Value += e.ProgressPercentage;
		}
	}

	public void bgw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
	{
		ctrlProgress.Value = ctrlProgress.Maximum;
	}

	public void loadData()
	{
		try
		{
			txtEmailList.Clear();
			int counter = 0;
			string[] array = emails;
			foreach (string email in array)
			{
				txtEmailList.Text += email;
				txtEmailList.Text += "\n";
				counter++;
			}
			txtEmailList.Text = txtEmailList.Text.Trim();
			lblCount.Text = ((counter < 0) ? "0" : counter.ToString());
		}
		catch (Exception)
		{
			MessageBox.Show("Sorry, Invalid file format.");
		}
	}

	public string[] removeDuplicates(string[] myList)
	{
		ArrayList newList = new ArrayList();
		foreach (string str in myList)
		{
			if (!newList.Contains(str))
			{
				newList.Add(str);
			}
		}
		return (string[])newList.ToArray(typeof(string));
	}

	private void btnRmDpl_Click(object sender, EventArgs e)
	{
		getEmails();
		emails = removeDuplicates(emails);
		loadData();
	}

	private void getEmails()
	{
		emails = txtEmailList.Text.Trim().Split(new string[3] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.ImportEmail));
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.txtEmailList = new System.Windows.Forms.RichTextBox();
		this.groupBox2 = new System.Windows.Forms.GroupBox();
		this.btnImport = new System.Windows.Forms.Button();
		this.btnAdd = new System.Windows.Forms.Button();
		this.btnRmDpl = new System.Windows.Forms.Button();
		this.lblCount = new System.Windows.Forms.Label();
		this.label1 = new System.Windows.Forms.Label();
		this.ctrlProgress = new System.Windows.Forms.ProgressBar();
		this.groupBox1.SuspendLayout();
		this.groupBox2.SuspendLayout();
		base.SuspendLayout();
		this.groupBox1.Controls.Add(this.txtEmailList);
		this.groupBox1.Location = new System.Drawing.Point(12, 12);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(360, 281);
		this.groupBox1.TabIndex = 0;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "Add Email";
		this.txtEmailList.Location = new System.Drawing.Point(6, 19);
		this.txtEmailList.Name = "txtEmailList";
		this.txtEmailList.Size = new System.Drawing.Size(348, 256);
		this.txtEmailList.TabIndex = 0;
		this.txtEmailList.Text = "";
		this.groupBox2.Controls.Add(this.btnImport);
		this.groupBox2.Controls.Add(this.btnAdd);
		this.groupBox2.Controls.Add(this.btnRmDpl);
		this.groupBox2.Controls.Add(this.lblCount);
		this.groupBox2.Controls.Add(this.label1);
		this.groupBox2.Location = new System.Drawing.Point(12, 316);
		this.groupBox2.Name = "groupBox2";
		this.groupBox2.Size = new System.Drawing.Size(360, 57);
		this.groupBox2.TabIndex = 0;
		this.groupBox2.TabStop = false;
		this.btnImport.Image = (System.Drawing.Image)resources.GetObject("btnImport.Image");
		this.btnImport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnImport.Location = new System.Drawing.Point(196, 14);
		this.btnImport.Name = "btnImport";
		this.btnImport.Size = new System.Drawing.Size(75, 34);
		this.btnImport.TabIndex = 4;
		this.btnImport.Text = "Import";
		this.btnImport.UseVisualStyleBackColor = true;
		this.btnImport.Click += new System.EventHandler(btnImport_Click);
		this.btnAdd.Image = (System.Drawing.Image)resources.GetObject("btnAdd.Image");
		this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnAdd.Location = new System.Drawing.Point(277, 14);
		this.btnAdd.Name = "btnAdd";
		this.btnAdd.Size = new System.Drawing.Size(75, 34);
		this.btnAdd.TabIndex = 3;
		this.btnAdd.Text = "Add";
		this.btnAdd.UseVisualStyleBackColor = true;
		this.btnAdd.Click += new System.EventHandler(btnAdd_Click);
		this.btnRmDpl.Image = (System.Drawing.Image)resources.GetObject("btnRmDpl.Image");
		this.btnRmDpl.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnRmDpl.Location = new System.Drawing.Point(110, 14);
		this.btnRmDpl.Name = "btnRmDpl";
		this.btnRmDpl.Size = new System.Drawing.Size(79, 34);
		this.btnRmDpl.TabIndex = 2;
		this.btnRmDpl.Text = "  Rm Dpl";
		this.btnRmDpl.UseVisualStyleBackColor = true;
		this.btnRmDpl.Click += new System.EventHandler(btnRmDpl_Click);
		this.lblCount.AutoSize = true;
		this.lblCount.Location = new System.Drawing.Point(74, 25);
		this.lblCount.Name = "lblCount";
		this.lblCount.Size = new System.Drawing.Size(13, 13);
		this.lblCount.TabIndex = 1;
		this.lblCount.Text = "0";
		this.label1.AutoSize = true;
		this.label1.Location = new System.Drawing.Point(8, 25);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(68, 13);
		this.label1.TabIndex = 0;
		this.label1.Text = "Total Lines : ";
		this.ctrlProgress.Location = new System.Drawing.Point(12, 296);
		this.ctrlProgress.Name = "ctrlProgress";
		this.ctrlProgress.Size = new System.Drawing.Size(360, 23);
		this.ctrlProgress.TabIndex = 1;
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(385, 379);
		base.Controls.Add(this.ctrlProgress);
		base.Controls.Add(this.groupBox2);
		base.Controls.Add(this.groupBox1);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "ImportEmail";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Add Email";
		this.groupBox1.ResumeLayout(false);
		this.groupBox2.ResumeLayout(false);
		this.groupBox2.PerformLayout();
		base.ResumeLayout(false);
	}
}
