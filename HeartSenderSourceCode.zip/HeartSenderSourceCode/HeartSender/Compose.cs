using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using CommonSender;

namespace HeartSender;

public class Compose : Form
{
	private Main main;

	public string attachment_tags = "";

	public string attachment_path = "";

	private IContainer components;

	public Button btnDone;

	private GroupBox groupBox1;

	private RichTextBox txtMessage;

	private ComboBox cbTags;

	private Label label7;

	private Label lblTitle;

	private TextBox tbLetterName;

	public Button btnClear;

	public Button btnSpam;

	public Button btnAttachment;

	private CheckBox isHtml;

	private GroupBox groupBox2;

	private GroupBox groupBox3;

	private TextBox txtFromName;

	private Label label1;

	private TextBox txtSubject;

	private Label label3;

	private Label label2;

	private GroupBox groupBox4;

	private GroupBox groupBox5;

	private RichTextBox txtFromEmail;

	public Compose(Main _main)
	{
		main = _main;
		InitializeComponent();
	}

	private void btnDone_Click(object sender, EventArgs e)
	{
		GxLetter newLetter = new GxLetter();
		if (tbLetterName.Text != "" && txtMessage.Text != "" && txtFromEmail.Text != "" && txtFromName.Text != "" && txtSubject.Text != "")
		{
			if (Main.selected_letter_index != "")
			{
				string letter2 = "";
				if (isHtml.Checked)
				{
					letter2 = txtMessage.Text;
					letter2 = letter2.Replace("\n", "<br>");
				}
				else
				{
					letter2 = txtMessage.Text;
				}
				Main.letters[int.Parse(Main.selected_letter_index)].letter = letter2;
				if (attachment_path != "")
				{
					Main.letters[int.Parse(Main.selected_letter_index)].attachment = attachment_path;
					Main.letters[int.Parse(Main.selected_letter_index)].attachment_tags = attachment_tags;
				}
				else
				{
					Main.letters[int.Parse(Main.selected_letter_index)].attachment = Main.letters[int.Parse(Main.selected_letter_index)].attachment;
					Main.letters[int.Parse(Main.selected_letter_index)].attachment_tags = Main.letters[int.Parse(Main.selected_letter_index)].attachment_tags;
				}
				Main.letters[int.Parse(Main.selected_letter_index)].is_enable = false;
				Main.letters[int.Parse(Main.selected_letter_index)].is_html = true;
				Main.letters[int.Parse(Main.selected_letter_index)].fromemail = txtFromEmail.Lines;
				Main.letters[int.Parse(Main.selected_letter_index)].fromname = txtFromName.Text;
				Main.letters[int.Parse(Main.selected_letter_index)].subject = txtSubject.Text;
				tbLetterName.Text = "";
				txtMessage.Text = "";
				txtSubject.Text = "";
				txtFromName.Text = "";
				txtFromEmail.Text = "";
				MessageBox.Show("Letter Update !", "Heart Sender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				main.gridLetter.Rows.Clear();
				int counter2 = 0;
				for (int j = 0; j < Main.letters.Count; j++)
				{
					int indx2 = main.gridLetter.Rows.Add();
					main.gridLetter.Rows[indx2].Cells[5].Value = Main.letters[j].is_enable;
					for (int l = 0; l < Main.letters[j].fromemail.Length; l++)
					{
						if (counter2 == Main.letters[j].fromemail.Length - 1)
						{
							DataGridViewCell dataGridViewCell = main.gridLetter.Rows[indx2].Cells[1];
							dataGridViewCell.Value = dataGridViewCell.Value?.ToString() + Main.letters[j].fromemail[l];
						}
						else
						{
							DataGridViewCell dataGridViewCell2 = main.gridLetter.Rows[indx2].Cells[1];
							dataGridViewCell2.Value = dataGridViewCell2.Value?.ToString() + Main.letters[j].fromemail[l] + "|";
						}
						counter2++;
					}
					main.gridLetter.Rows[indx2].Cells[0].Value = Main.letters[j].fromname;
					main.gridLetter.Rows[indx2].Cells[2].Value = Main.letters[j].subject;
					main.gridLetter.Rows[indx2].Cells[3].Value = Main.letters[j].name;
					main.gridLetter.Rows[indx2].Cells[4].Value = Main.letters[j].attachment;
				}
				main.gridLetter.ClearSelection();
				Close();
				return;
			}
			string letter = "";
			if (isHtml.Checked)
			{
				letter = txtMessage.Text;
				letter = letter.Replace("\n", "<br>");
			}
			else
			{
				letter = txtMessage.Text;
			}
			newLetter.letter = letter;
			newLetter.attachment = attachment_path;
			newLetter.is_enable = false;
			newLetter.is_html = true;
			newLetter.attachment_tags = attachment_tags;
			newLetter.name = tbLetterName.Text;
			newLetter.fromemail = txtFromEmail.Lines;
			newLetter.fromname = txtFromName.Text;
			newLetter.subject = txtSubject.Text;
			tbLetterName.Text = "";
			txtMessage.Text = "";
			txtSubject.Text = "";
			txtFromName.Text = "";
			txtFromEmail.Text = "";
			Main.letters.Add(newLetter);
			MessageBox.Show("Letter Saved!", "Heart Sender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			main.gridLetter.Rows.Clear();
			int counter = 0;
			for (int i = 0; i < Main.letters.Count; i++)
			{
				int indx = main.gridLetter.Rows.Add();
				main.gridLetter.Rows[indx].Cells[5].Value = Main.letters[i].is_enable;
				for (int k = 0; k < Main.letters[i].fromemail.Length; k++)
				{
					if (counter == Main.letters[i].fromemail.Length - 1)
					{
						DataGridViewCell dataGridViewCell3 = main.gridLetter.Rows[indx].Cells[1];
						dataGridViewCell3.Value = dataGridViewCell3.Value?.ToString() + Main.letters[i].fromemail[k];
					}
					else
					{
						DataGridViewCell dataGridViewCell4 = main.gridLetter.Rows[indx].Cells[1];
						dataGridViewCell4.Value = dataGridViewCell4.Value?.ToString() + Main.letters[i].fromemail[k] + "|";
					}
					counter++;
				}
				main.gridLetter.Rows[indx].Cells[0].Value = Main.letters[i].fromname;
				main.gridLetter.Rows[indx].Cells[2].Value = Main.letters[i].subject;
				main.gridLetter.Rows[indx].Cells[3].Value = Main.letters[i].name;
				main.gridLetter.Rows[indx].Cells[4].Value = Main.letters[i].attachment;
			}
			main.gridLetter.ClearSelection();
			Close();
		}
		else
		{
			MessageBox.Show("Please Fill All Required Field.", "Heart Sender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	private void btnSpam_Click(object sender, EventArgs e)
	{
		if (txtMessage.Text != "")
		{
			List<string> spams = new List<string>();
			foreach (string words in Main.spamwords)
			{
				if (txtMessage.Text.ToLower().Contains(words.ToLower()))
				{
					spams.Add(words);
				}
			}
			if (spams.Count > 0)
			{
				MessageBox.Show("There are " + spams.Count + " words found in your letter which can effect delivery in inbox.\n\r\n\rWords: " + string.Join(", ", spams), "Heart Sender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else
			{
				MessageBox.Show("Your letter looks safe!", "Heart Sender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}
		else
		{
			MessageBox.Show("Please add a message.", "Heart Sender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
	}

	private void btnClear_Click(object sender, EventArgs e)
	{
		txtMessage.Text = "";
		attachment_path = "";
		tbLetterName.Text = "";
	}

	private void btnAttachment_Click(object sender, EventArgs e)
	{
		_ = string.Empty;
		string filePath = string.Empty;
		using OpenFileDialog openFileDialog = new OpenFileDialog();
		openFileDialog.InitialDirectory = "c:\\";
		openFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
		openFileDialog.FilterIndex = 2;
		openFileDialog.RestoreDirectory = true;
		if (openFileDialog.ShowDialog() == DialogResult.OK)
		{
			getAttachmentTags(attachment_path = openFileDialog.FileName);
			MessageBox.Show("Attachment selected", "Heart Sender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
	}

	public void getAttachmentTags(string path)
	{
		if (!(path != ""))
		{
			return;
		}
		FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
		string content = string.Empty;
		new FileInfo(path);
		_ = new string[6] { ".html", ".htm", ".txt", ".rtf", ".log", ".tex" };
		using StreamReader streamReader = new StreamReader(fs, Encoding.UTF8);
		content = streamReader.ReadToEnd();
		Match i = new Regex("(\\#\\#.*?\\#\\#)").Match(content);
		List<string> matches = new List<string>();
		while (i.Success)
		{
			matches.Add(i.Value);
			i = i.NextMatch();
		}
		matches = matches.Distinct().ToList();
		Main.attachment_tags = string.Join("|||", matches);
	}

	private void cbTags_SelectedIndexChanged(object sender, EventArgs e)
	{
		string rs = getTag(cbTags.SelectedItem.ToString());
		txtMessage.SelectedText = rs;
	}

	public string getTag(string tags)
	{
		return tags switch
		{
			"Get Seconds" => "[-Seconds-]", 
			"Get Minutes" => "[-Minutes-]", 
			"Get Hours" => "[-Hours-]", 
			"Get LongTime" => "[-LongTime-]", 
			"Get LongDate" => "[-LongDate-]", 
			"Get ShortDate" => "[-ShortDate-]", 
			"Get TIME" => "[-TIME-]", 
			"Random Links" => "[-LINK-]", 
			"Random Android OS" => "[-ANDROID_OS-]", 
			"Random Android Browser" => "[-ANDROID_BROWSER-]", 
			"Random Apple Macbook Device" => "[-APPLE_MACBOOK-]", 
			"Random Apple Phone Device" => "[-APPLE_PHONE-]", 
			"Random Apple Phone Apps" => "[-APPLE_APPS-]", 
			"Random IP" => "[-IP-]", 
			"Get Email Target" => "[-EMAIL-]", 
			"Random 1 Character" => "[-CHAR1-]", 
			"Random 2 Character" => "[-CHAR2-]", 
			"Random 3 Character" => "[-CHAR3-]", 
			"Random 4 Character" => "[-CHAR4-]", 
			"Random 5 Character" => "[-CHAR5-]", 
			"Random 6 Character" => "[-CHAR6-]", 
			"Random 7 Character" => "[-CHAR7-]", 
			"Random 8 Character" => "[-CHAR8-]", 
			"Random 9 Character" => "[-CHAR9-]", 
			"Random 10 Character" => "[-CHAR10-]", 
			"Get Date" => "[-DATE-]", 
			"Random 1 Number" => "[-NUMBER1-]", 
			"Random 2 Number" => "[-NUMBER2-]", 
			"Random 3 Number" => "[-NUMBER3-]", 
			"Random 4 Number" => "[-NUMBER4-]", 
			"Random 5 Number" => "[-NUMBER5-]", 
			"Random 6 Number" => "[-NUMBER6-]", 
			"Random 7 Number" => "[-NUMBER7-]", 
			"Random 8 Number" => "[-NUMBER8-]", 
			"Random 9 Number" => "[-NUMBER9-]", 
			"Random 10 Number" => "[-NUMBER10-]", 
			"Get Username From Email" => "[-UNAME-]", 
			"Get Domain From Email" => "[-UDOMAIN-]", 
			"Random Text And Number" => "[-RANDOM-]", 
			"Get A Fake Name" => "[-FAKE_NAME-]", 
			"Get A Fake Address" => "[-FAKE_ADDRESS-]", 
			"Get A Fake DOB" => "[-FAKE_DOB-]", 
			"Get A Fake Phone Number" => "[-FAKE_PHONE-]", 
			"Get A Fake Mail" => "[-FAKE_MAIL-]", 
			"Get A Fake Card Number" => "[-FAKE_CARD-]", 
			"Email in base64" => "[-EMAILB64-]", 
			"Generate 10 random letter mix UPPERCASE or lowercase" => "[-random_letter_10-]", 
			"Generate 10 random letter UPPERCASE" => "[-random_letterupp_10-]", 
			"Generate 10 random letter lowercase" => "[-random_letterlow_10-]", 
			"Generate 10 random number and letter mix uppercase or lowercase" => "[-random_letternumber_10-]", 
			"Generate 10 random number and letter UPPERCASE" => "[-random_letternumberlow_10-]", 
			"Generate 10 random number and letter lowercase" => "[-random_letternumberupp_10-]", 
			"Generate random country" => "[-random_country[-", 
			"Generate random email like : res*****@yahoo.com" => "[-random_email-]", 
			"Random COMPANY Name" => "[-Company-]", 
			_ => "0", 
		};
	}

	private void Compose_Load(object sender, EventArgs e)
	{
		if (Main.selected_letter_index.Length > 0)
		{
			tbLetterName.Text = Main.letters[int.Parse(Main.selected_letter_index)].name;
			txtFromEmail.Lines = Main.letters[int.Parse(Main.selected_letter_index)].fromemail;
			txtFromName.Text = Main.letters[int.Parse(Main.selected_letter_index)].fromname.ToString();
			txtSubject.Text = Main.letters[int.Parse(Main.selected_letter_index)].subject.ToString();
			txtMessage.Text = Main.letters[int.Parse(Main.selected_letter_index)].letter.ToString();
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.Compose));
		this.btnDone = new System.Windows.Forms.Button();
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.txtMessage = new System.Windows.Forms.RichTextBox();
		this.cbTags = new System.Windows.Forms.ComboBox();
		this.label7 = new System.Windows.Forms.Label();
		this.lblTitle = new System.Windows.Forms.Label();
		this.tbLetterName = new System.Windows.Forms.TextBox();
		this.btnClear = new System.Windows.Forms.Button();
		this.btnSpam = new System.Windows.Forms.Button();
		this.btnAttachment = new System.Windows.Forms.Button();
		this.isHtml = new System.Windows.Forms.CheckBox();
		this.groupBox2 = new System.Windows.Forms.GroupBox();
		this.groupBox4 = new System.Windows.Forms.GroupBox();
		this.txtSubject = new System.Windows.Forms.TextBox();
		this.label3 = new System.Windows.Forms.Label();
		this.groupBox3 = new System.Windows.Forms.GroupBox();
		this.groupBox5 = new System.Windows.Forms.GroupBox();
		this.txtFromEmail = new System.Windows.Forms.RichTextBox();
		this.label2 = new System.Windows.Forms.Label();
		this.txtFromName = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.groupBox1.SuspendLayout();
		this.groupBox2.SuspendLayout();
		this.groupBox4.SuspendLayout();
		this.groupBox3.SuspendLayout();
		this.groupBox5.SuspendLayout();
		base.SuspendLayout();
		this.btnDone.Image = (System.Drawing.Image)resources.GetObject("btnDone.Image");
		this.btnDone.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnDone.Location = new System.Drawing.Point(747, 537);
		this.btnDone.Name = "btnDone";
		this.btnDone.Size = new System.Drawing.Size(136, 33);
		this.btnDone.TabIndex = 19;
		this.btnDone.Text = "Save";
		this.btnDone.UseVisualStyleBackColor = true;
		this.btnDone.Click += new System.EventHandler(btnDone_Click);
		this.groupBox1.Controls.Add(this.txtMessage);
		this.groupBox1.Location = new System.Drawing.Point(9, 185);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(874, 346);
		this.groupBox1.TabIndex = 137;
		this.groupBox1.TabStop = false;
		this.txtMessage.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
		this.txtMessage.BorderStyle = System.Windows.Forms.BorderStyle.None;
		this.txtMessage.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtMessage.ForeColor = System.Drawing.Color.Black;
		this.txtMessage.Location = new System.Drawing.Point(3, 16);
		this.txtMessage.Name = "txtMessage";
		this.txtMessage.Size = new System.Drawing.Size(868, 327);
		this.txtMessage.TabIndex = 0;
		this.txtMessage.Text = "";
		this.cbTags.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
		this.cbTags.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.cbTags.ForeColor = System.Drawing.Color.Black;
		this.cbTags.FormattingEnabled = true;
		this.cbTags.Items.AddRange(new object[55]
		{
			"Get Seconds", "Get Minutes", "Get Hours", "Get LongTime", "Get LongDate", "Get ShortDate", "Get TIME", "Random Links", "Random Android OS", "Random Android Browser",
			"Random Apple Macbook Device", "Random Apple Phone Device", "Random Apple Phone Apps", "Random IP", "Get Email Target", "Random 1 Character", "Random 2 Character", "Random 3 Character", "Random 4 Character", "Random 5 Character",
			"Random 6 Character", "Random 7 Character", "Random 8 Character", "Random 9 Character", "Random 10 Character", "Get Date", "Random 1 Number", "Random 2 Number", "Random 3 Number", "Random 4 Number",
			"Random 5 Number", "Random 6 Number", "Random 7 Number", "Random 8 Number", "Random 9 Number", "Random 10 Number", "Get Username From Email", "Get Domain From Email", "Random Text And Number", "Get A Fake Name",
			"Get A Fake Address", "Get A Fake DOB", "Get A Fake Phone Number", "Get A Fake Mail", "Get A Fake Card Number", "Email in base64", "Generate 10 random letter mix UPPERCASE or lowercase", "Generate 10 random letter UPPERCASE", "Generate 10 random letter lowercase", "Generate 10 random number and letter mix uppercase or lowercase",
			"Generate 10 random number and letter UPPERCASE", "Generate 10 random number and letter lowercase", "Generate random country", "Generate random email like : res*****@yahoo.com", "Random COMPANY Name"
		});
		this.cbTags.Location = new System.Drawing.Point(101, 95);
		this.cbTags.Name = "cbTags";
		this.cbTags.Size = new System.Drawing.Size(295, 21);
		this.cbTags.TabIndex = 136;
		this.cbTags.Text = "Select";
		this.cbTags.SelectedIndexChanged += new System.EventHandler(cbTags_SelectedIndexChanged);
		this.label7.AutoSize = true;
		this.label7.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.label7.ForeColor = System.Drawing.Color.Black;
		this.label7.Location = new System.Drawing.Point(20, 99);
		this.label7.Name = "label7";
		this.label7.Size = new System.Drawing.Size(50, 15);
		this.label7.TabIndex = 135;
		this.label7.Text = "Pick Tag";
		this.lblTitle.AutoSize = true;
		this.lblTitle.BackColor = System.Drawing.Color.Transparent;
		this.lblTitle.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.lblTitle.ForeColor = System.Drawing.Color.Black;
		this.lblTitle.Location = new System.Drawing.Point(20, 66);
		this.lblTitle.Name = "lblTitle";
		this.lblTitle.Size = new System.Drawing.Size(32, 15);
		this.lblTitle.TabIndex = 134;
		this.lblTitle.Text = "Title:";
		this.tbLetterName.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
		this.tbLetterName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
		this.tbLetterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.tbLetterName.ForeColor = System.Drawing.Color.Black;
		this.tbLetterName.Location = new System.Drawing.Point(101, 62);
		this.tbLetterName.Name = "tbLetterName";
		this.tbLetterName.Size = new System.Drawing.Size(295, 21);
		this.tbLetterName.TabIndex = 133;
		this.btnClear.Image = (System.Drawing.Image)resources.GetObject("btnClear.Image");
		this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnClear.Location = new System.Drawing.Point(605, 537);
		this.btnClear.Name = "btnClear";
		this.btnClear.Size = new System.Drawing.Size(136, 33);
		this.btnClear.TabIndex = 138;
		this.btnClear.Text = "Clear";
		this.btnClear.UseVisualStyleBackColor = true;
		this.btnClear.Click += new System.EventHandler(btnClear_Click);
		this.btnSpam.Image = (System.Drawing.Image)resources.GetObject("btnSpam.Image");
		this.btnSpam.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnSpam.Location = new System.Drawing.Point(153, 537);
		this.btnSpam.Name = "btnSpam";
		this.btnSpam.Size = new System.Drawing.Size(136, 33);
		this.btnSpam.TabIndex = 139;
		this.btnSpam.Text = "Spam";
		this.btnSpam.UseVisualStyleBackColor = true;
		this.btnSpam.Click += new System.EventHandler(btnSpam_Click);
		this.btnAttachment.Image = (System.Drawing.Image)resources.GetObject("btnAttachment.Image");
		this.btnAttachment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnAttachment.Location = new System.Drawing.Point(11, 537);
		this.btnAttachment.Name = "btnAttachment";
		this.btnAttachment.Size = new System.Drawing.Size(136, 33);
		this.btnAttachment.TabIndex = 140;
		this.btnAttachment.Text = "Attachement";
		this.btnAttachment.UseVisualStyleBackColor = true;
		this.btnAttachment.Click += new System.EventHandler(btnAttachment_Click);
		this.isHtml.AutoSize = true;
		this.isHtml.Location = new System.Drawing.Point(97, 128);
		this.isHtml.Name = "isHtml";
		this.isHtml.Size = new System.Drawing.Size(87, 17);
		this.isHtml.TabIndex = 141;
		this.isHtml.Text = "Is Not Html ?";
		this.isHtml.UseVisualStyleBackColor = true;
		this.groupBox2.Controls.Add(this.groupBox4);
		this.groupBox2.Controls.Add(this.groupBox3);
		this.groupBox2.Location = new System.Drawing.Point(12, 13);
		this.groupBox2.Name = "groupBox2";
		this.groupBox2.Size = new System.Drawing.Size(868, 166);
		this.groupBox2.TabIndex = 142;
		this.groupBox2.TabStop = false;
		this.groupBox4.Controls.Add(this.txtSubject);
		this.groupBox4.Controls.Add(this.label3);
		this.groupBox4.Controls.Add(this.tbLetterName);
		this.groupBox4.Controls.Add(this.cbTags);
		this.groupBox4.Controls.Add(this.label7);
		this.groupBox4.Controls.Add(this.lblTitle);
		this.groupBox4.Controls.Add(this.isHtml);
		this.groupBox4.Location = new System.Drawing.Point(443, 8);
		this.groupBox4.Name = "groupBox4";
		this.groupBox4.Size = new System.Drawing.Size(419, 152);
		this.groupBox4.TabIndex = 143;
		this.groupBox4.TabStop = false;
		this.groupBox4.Text = "Letter Settings";
		this.txtSubject.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
		this.txtSubject.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
		this.txtSubject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtSubject.ForeColor = System.Drawing.Color.Black;
		this.txtSubject.Location = new System.Drawing.Point(101, 29);
		this.txtSubject.Name = "txtSubject";
		this.txtSubject.Size = new System.Drawing.Size(295, 21);
		this.txtSubject.TabIndex = 139;
		this.label3.AutoSize = true;
		this.label3.BackColor = System.Drawing.Color.Transparent;
		this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.label3.ForeColor = System.Drawing.Color.Black;
		this.label3.Location = new System.Drawing.Point(16, 32);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(51, 15);
		this.label3.TabIndex = 140;
		this.label3.Text = "Subject :";
		this.groupBox3.Controls.Add(this.groupBox5);
		this.groupBox3.Controls.Add(this.label2);
		this.groupBox3.Controls.Add(this.txtFromName);
		this.groupBox3.Controls.Add(this.label1);
		this.groupBox3.Location = new System.Drawing.Point(6, 8);
		this.groupBox3.Name = "groupBox3";
		this.groupBox3.Size = new System.Drawing.Size(421, 152);
		this.groupBox3.TabIndex = 142;
		this.groupBox3.TabStop = false;
		this.groupBox3.Text = "Config";
		this.groupBox5.Controls.Add(this.txtFromEmail);
		this.groupBox5.Location = new System.Drawing.Point(98, 61);
		this.groupBox5.Name = "groupBox5";
		this.groupBox5.Size = new System.Drawing.Size(295, 84);
		this.groupBox5.TabIndex = 139;
		this.groupBox5.TabStop = false;
		this.txtFromEmail.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
		this.txtFromEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
		this.txtFromEmail.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtFromEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
		this.txtFromEmail.Location = new System.Drawing.Point(3, 16);
		this.txtFromEmail.Name = "txtFromEmail";
		this.txtFromEmail.Size = new System.Drawing.Size(289, 65);
		this.txtFromEmail.TabIndex = 140;
		this.txtFromEmail.Text = "";
		this.label2.AutoSize = true;
		this.label2.BackColor = System.Drawing.Color.Transparent;
		this.label2.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.label2.ForeColor = System.Drawing.Color.Black;
		this.label2.Location = new System.Drawing.Point(13, 97);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(71, 15);
		this.label2.TabIndex = 138;
		this.label2.Text = "From Email :";
		this.txtFromName.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
		this.txtFromName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
		this.txtFromName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtFromName.ForeColor = System.Drawing.Color.Black;
		this.txtFromName.Location = new System.Drawing.Point(98, 27);
		this.txtFromName.Name = "txtFromName";
		this.txtFromName.Size = new System.Drawing.Size(295, 21);
		this.txtFromName.TabIndex = 135;
		this.label1.AutoSize = true;
		this.label1.BackColor = System.Drawing.Color.Transparent;
		this.label1.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.label1.ForeColor = System.Drawing.Color.Black;
		this.label1.Location = new System.Drawing.Point(13, 30);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(74, 15);
		this.label1.TabIndex = 136;
		this.label1.Text = "From Name :";
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(896, 582);
		base.Controls.Add(this.groupBox2);
		base.Controls.Add(this.btnAttachment);
		base.Controls.Add(this.btnSpam);
		base.Controls.Add(this.btnClear);
		base.Controls.Add(this.groupBox1);
		base.Controls.Add(this.btnDone);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "Compose";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Compose Letter";
		base.Load += new System.EventHandler(Compose_Load);
		this.groupBox1.ResumeLayout(false);
		this.groupBox2.ResumeLayout(false);
		this.groupBox4.ResumeLayout(false);
		this.groupBox4.PerformLayout();
		this.groupBox3.ResumeLayout(false);
		this.groupBox3.PerformLayout();
		this.groupBox5.ResumeLayout(false);
		base.ResumeLayout(false);
	}
}
