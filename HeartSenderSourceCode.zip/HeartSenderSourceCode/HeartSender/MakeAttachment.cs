using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Zoople;

namespace HeartSender;

public class MakeAttachment : Form
{
	private Main main;

	private IContainer components;

	private HTMLEditControl ctrlHTMLEditor;

	public ComboBox cbTags;

	public Label label12;

	public Button btnImport;

	public Button button1;

	private SaveFileDialog saveFileDialog1;

	public MakeAttachment(Main _main)
	{
		InitializeComponent();
		main = _main;
	}

	public string getTag(string tags)
	{
		return tags switch
		{
			"ANDROID DEVICE NAMES" => "[-ANDROID_OS-]", 
			"ANDROID BROWSER NAMES" => "[-ANDROID_BROWSER-]", 
			"APPLE DEVICE NAMES" => "[-APPLE_MACBOOK-]", 
			"APPLE PHONE NAMES" => "[-APPLE_PHONE-]", 
			"APPLE APPS NAMES" => "[-APPLE_APPS-]", 
			"RANDOME IP" => "[-IP-]", 
			"RECEIVER EMAIL" => "[-EMAIL-]", 
			"Random character 1" => "[-CHAR1-]", 
			"Random character 2" => "[-CHAR2-]", 
			"Random character 3" => "[-CHAR3-]", 
			"Random character 4" => "[-CHAR4-]", 
			"Random character 5" => "[-CHAR5-]", 
			"Random character 6" => "[-CHAR6-]", 
			"Random character 7" => "[-CHAR7-]", 
			"Random character 8" => "[-CHAR8-]", 
			"Random character 9" => "[-CHAR9-]", 
			"Random character 10" => "[-CHAR10-]", 
			"Random number 1" => "[-NUMBER1-]", 
			"Random number 2" => "[-NUMBER2-]", 
			"Random number 3" => "[-NUMBER3-]", 
			"Random number 4" => "[-NUMBER4-]", 
			"Random number 5" => "[-NUMBER5-]", 
			"Random number 6" => "[-NUMBER6-]", 
			"Random number 7" => "[-NUMBER7-]", 
			"Random number 8" => "[-NUMBER8-]", 
			"Random number 9" => "[-NUMBER9-]", 
			"Random number 10" => "[-NUMBER10-]", 
			"Random number ( Change 10 to any digit to 99 for more numbers )" => "[-random_number_10-]", 
			"Random character ( Change 10 to any digit to 99 for more letters )" => "[-random_letter_10-]", 
			"RANDOM EMAIL ADDRESS SHOW IN LETTER" => "[-random_email-]", 
			"SHOW SECOND IN LETTER" => "[-Seconds-]", 
			"SHOW Minutes IN LETTER" => "[-Minutes-]", 
			"SHOW HOURS IN LETTER" => "[-Hours-]", 
			"SHOW TIME IN LETTER" => "[-TIME-]", 
			"SHOW LONG TIME IN LETTER ( MINS , SECOND , HOURS )" => "[-LongTime-]", 
			"SHOW LONG DATE IN LETTER ( DAY , YEAR , MONTH )" => "[-LongDate-]", 
			"SHOW SHORT DATE IN LETTER ( MONTH )" => "[-ShortDate-]", 
			"SHOW RANDOM COUNTRIES IN LETTER" => "[-RANDOM_COUNTRY-]", 
			"SHOW RANDOM CITY IN LETTER" => "[-City-]", 
			"SHOW RANDOM COMPANY IN LETTER" => "[-Company-]", 
			"SHOW SENDER EMAIL" => "[-Sender_Email-]", 
			"SHOW DATE" => "[-DATE-]", 
			"SHOW DATE & TIME" => "[-DATETIME-]", 
			"SHOW RECEIVER EMAIL NAME ( LIKE ITS GRAB FIRST NAME BEFORE @ )" => "[-UNAME-]", 
			"SHOW DOMAIN NAME ( AFTER @ LIKE GMAIL.COM ETC )" => "[-UDOMAIN-]", 
			"SHOW RANDOM number & character MIX" => "[-RANDOM-]", 
			"SHOW RANDOM FAKE NAMES" => "[-FAKE_NAME-]", 
			"SHOW RANDOM FAKE ADDRESS" => "[-FAKE_ADDRESS-]", 
			"SHOW RANDOM FAKE DATE OF BIRTH" => "[-FAKE_DOB-]", 
			"SHOW RANDOM FAKE PHONE NUMBERS" => "[-FAKE_PHONE-]", 
			"SHOW RANDOM FAKE EMAILS ADDRESS" => "[-FAKE_MAIL-]", 
			"SHOW RANDOM FAKE CREDIT CARDS" => "[-FAKE_CARD-]", 
			"SHOW RANDOM FAKE VIN_NUMBER" => "[-VIN_NUMBER-]", 
			"SHOW RANDOM FAKE BUSINESS EMAIL" => "[-BUSINESS_EMAIL-]", 
			"SHOW RANDOM FAKE INSTITUTE" => "[-INSTITUTE-]", 
			"SHOW RANDOM COMPANY ADDRESS" => "[-COMPANY_ADDRESS-]", 
			"SHOW RANDOM FAKE JOB TITLE" => "[-JOB_TITLE-]", 
			"SHOW SMTP DOMAIN" => "[-SMTPDOMAIN-]", 
			"SHOW SMTP USER" => "[-SMTPUSER-]", 
			"SHOW email Links" => "[-EMAIL_LINK-]", 
			"SHOW Main Domain" => "[-ROOTDOMAIN-]", 
			"Show SMTP DOMAIN" => "[-DOMAINSENDER-]", 
			"SHOW EMAIL ADDRESS IN BASE64 ( MOST USE FULL TAG )" => "[-EMAILB64-]", 
			"SHOW return Random characters" => "[-RND-]", 
			"Random characters and numbers with 32 characters length" => "[-RNDHEX-]", 
			"Current date with Japanese format yyyy mm dd H:mm:ss" => "[-DATEJP-]", 
			"THIS TAG USE FOR RANDOM ROTATES LINKS" => "[-LINK-]", 
			"show random letterupp 10" => "[-random_letterupp_10-]", 
			"show random letter low 10" => "[-random_letterlow_10-]", 
			"show random letternumber 10" => "[-random_letternumber_10-]", 
			"show random letternumberlow 10" => "[-random_letternumberlow_10-]", 
			"show random  letternumberupp 10" => "[-random_letternumberupp_10-]", 
			_ => "0", 
		};
	}

	private void cbTags_SelectedIndexChanged(object sender, EventArgs e)
	{
		string rs = getTag(cbTags.SelectedItem.ToString());
		ctrlHTMLEditor.InsertAtCursor(rs, HTMLEditControl.ed_InsertType.ed_InsertAfterSelection);
	}

	private void Attachment_Load(object sender, EventArgs e)
	{
	}

	private void ctrlHTMLEditor_Load(object sender, EventArgs e)
	{
	}

	private void btnImport_Click(object sender, EventArgs e)
	{
		OpenFileDialog file = new OpenFileDialog();
		file.Filter = "All files (*.*)|*.*";
		if (file.ShowDialog() == DialogResult.OK)
		{
			main.settings[23] = file.FileName;
			getAttachmentTags();
			MessageBox.Show("Attachment selected");
			Close();
		}
	}

	public void getAttachmentTags()
	{
		FileStream fs = new FileStream(main.settings[23], FileMode.Open, FileAccess.Read, FileShare.Read);
		string content = string.Empty;
		new FileInfo(main.settings[23]);
		_ = new string[6] { ".html", ".htm", ".txt", ".rtf", ".log", ".tex" };
		using StreamReader streamReader = new StreamReader(fs, Encoding.UTF8);
		content = streamReader.ReadToEnd();
		Match i = new Regex("(\\#\\#.*?\\#\\#)").Match(content);
		List<string> matches = new List<string>();
		while (i.Success)
		{
			matches.Add(i.Value);
			i = i.NextMatch();
		}
		i = new Regex("(\\[\\-.*?\\-\\])").Match(content);
		while (i.Success)
		{
			matches.Add(i.Value);
			i = i.NextMatch();
		}
		matches = matches.Distinct().ToList();
		Main.attachment_tags = string.Join("|||", matches);
		Main.attachment_tags = Main.attachment_tags.Replace("##AUTOEMAILAE##", "##NEW_AUTOEMAILAE##");
		Main.attachment_tags = Main.attachment_tags.Replace("##EMAIL_LINK##", "##NEW_EMAIL_LINK##");
		Main.attachment_tags = Main.attachment_tags.Replace("##EMAILB64##", "##NEW_EMAILB64##");
		Main.attachment_tags = Main.attachment_tags.Replace("##EMAIL##", "##NEW_EMAIL##");
		Main.attachment_tags = Main.attachment_tags.Replace("[-AUTOEMAILAE-]", "[-NEW_AUTOEMAILAE-]");
		Main.attachment_tags = Main.attachment_tags.Replace("[-EMAIL_LINK-]", "[-NEW_EMAIL_LINK-]");
		Main.attachment_tags = Main.attachment_tags.Replace("[-EMAILB64-]", "[-NEW_EMAILB64-]");
		Main.attachment_tags = Main.attachment_tags.Replace("[-EMAIL-]", "[-NEW_EMAIL-]");
		Main.attachment_tags = Main.attachment_tags.Replace("[-firstname-]", "[-FIRSTNAME-]");
		Main.attachment_tags = Main.attachment_tags.Replace("[-lastname-]", "[-LASTNAME-]");
	}

	private void button1_Click(object sender, EventArgs e)
	{
		saveFileDialog1.Filter = "Html|*.html";
		saveFileDialog1.Title = "Save Your Letter";
		saveFileDialog1.ShowDialog();
	}

	private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
	{
		File.WriteAllText(saveFileDialog1.FileName, ctrlHTMLEditor.DocumentHTML.Replace("\n", Environment.NewLine));
		main.settings[23] = saveFileDialog1.FileName;
		getAttachmentTags();
		MessageBox.Show("Your Letter Save Successfully");
		Close();
	}

	private void label11_Click(object sender, EventArgs e)
	{
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.MakeAttachment));
		this.ctrlHTMLEditor = new Zoople.HTMLEditControl();
		this.cbTags = new System.Windows.Forms.ComboBox();
		this.label12 = new System.Windows.Forms.Label();
		this.btnImport = new System.Windows.Forms.Button();
		this.button1 = new System.Windows.Forms.Button();
		this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
		base.SuspendLayout();
		this.ctrlHTMLEditor.AcceptsReturn = true;
		this.ctrlHTMLEditor.AllowDragInternal = true;
		this.ctrlHTMLEditor.BaseURL = null;
		this.ctrlHTMLEditor.CleanMSWordHTMLOnPaste = true;
		this.ctrlHTMLEditor.CodeEditor.Enabled = true;
		this.ctrlHTMLEditor.CodeEditor.Locked = false;
		this.ctrlHTMLEditor.CodeEditor.WordWrap = false;
		this.ctrlHTMLEditor.CSSText = null;
		this.ctrlHTMLEditor.DocumentHTML = null;
		this.ctrlHTMLEditor.EditingDisabled = false;
		this.ctrlHTMLEditor.EnableInlineSpelling = true;
		this.ctrlHTMLEditor.FontsList = null;
		this.ctrlHTMLEditor.HiddenButtons = null;
		this.ctrlHTMLEditor.ImageStorageLocation = null;
		this.ctrlHTMLEditor.InCodeView = false;
		this.ctrlHTMLEditor.LanguageFile = null;
		this.ctrlHTMLEditor.LicenceKey = "KPH1014-934F-1893";
		this.ctrlHTMLEditor.LicenceKeyInlineSpelling = null;
		this.ctrlHTMLEditor.Location = new System.Drawing.Point(28, 53);
		this.ctrlHTMLEditor.Name = "ctrlHTMLEditor";
		this.ctrlHTMLEditor.Size = new System.Drawing.Size(831, 397);
		this.ctrlHTMLEditor.SpellingAutoCorrectionList = (System.Collections.Hashtable)resources.GetObject("ctrlHTMLEditor.SpellingAutoCorrectionList");
		this.ctrlHTMLEditor.TabIndex = 1;
		this.ctrlHTMLEditor.ToolstripImageScalingSize = new System.Drawing.Size(16, 16);
		this.ctrlHTMLEditor.UseParagraphAsDefault = true;
		this.ctrlHTMLEditor.Load += new System.EventHandler(ctrlHTMLEditor_Load);
		this.cbTags.FormattingEnabled = true;
		this.cbTags.Items.AddRange(new object[72]
		{
			"ANDROID DEVICE NAMES", "ANDROID BROWSER NAMES ", "APPLE DEVICE NAMES", "APPLE PHONE NAMES", "APPLE APPS NAMES", "RANDOME IP", "RECEIVER EMAIL", "Random character 1", "Random character 2", "Random character 3",
			"Random character 4", "Random character 5", "Random character 6", "Random character 7", "Random character 8", "Random character 9", "Random character 10", "Random number 1", "Random number 2", "Random number 3",
			"Random number 4", "Random number 5", "Random number 6", "Random number 7", "Random number 8", "Random number 9", "Random number 10", "Random number ( Change 10 to any digit to 99 for more numbers )", "Random character ( Change 10 to any digit to 99 for more letters )", "RANDOM EMAIL ADDRESS SHOW IN LETTER",
			"SHOW SECOND IN LETTER", "SHOW Minutes IN LETTER", "SHOW HOURS IN LETTER", "SHOW TIME IN LETTER", "SHOW LONG TIME IN LETTER ( MINS , SECOND , HOURS )", "SHOW LONG DATE IN LETTER ( DAY , YEAR , MONTH )", "SHOW SHORT DATE IN LETTER ( MONTH )", "SHOW RANDOM COUNTRIES IN LETTER", "SHOW RANDOM CITY IN LETTER", "SHOW RANDOM COMPANY IN LETTER",
			"SHOW SENDER EMAIL", "SHOW DATE", "SHOW DATE & TIME", "SHOW RECEIVER EMAIL NAME ( LIKE ITS GRAB FIRST NAME BEFORE @ )", "SHOW DOMAIN NAME ( AFTER @ LIKE GMAIL.COM ETC )", "SHOW RANDOM number & character MIX", "SHOW RANDOM FAKE NAMES", "SHOW RANDOM FAKE ADDRESS", "SHOW RANDOM FAKE DATE OF BIRTH", "SHOW RANDOM FAKE PHONE NUMBERS",
			"SHOW RANDOM FAKE EMAILS ADDRESS", "SHOW RANDOM FAKE CREDIT CARDS", "SHOW RANDOM FAKE VIN_NUMBER", "SHOW RANDOM FAKE BUSINESS EMAIL", "SHOW RANDOM FAKE INSTITUTE", "SHOW RANDOM COMPANY ADDRESS", "SHOW RANDOM FAKE JOB TITLE", "SHOW SMTP DOMAIN", "SHOW SMTP USER", "SHOW email Links",
			"SHOW Main Domain", "Show SMTP DOMAIN", "SHOW EMAIL ADDRESS IN BASE64 ( MOST USE FULL TAG )", "SHOW return Random characters", "Random characters and numbers with 32 characters length", "Current date with Japanese format yyyy mm dd H:mm:ss", "THIS TAG USE FOR RANDOM ROTATES LINKS", "show random letterupp 10", "show random letter low 10", "show random letternumber 10",
			"show random letternumberlow 10", "show random  letternumberupp 10"
		});
		this.cbTags.Location = new System.Drawing.Point(498, 15);
		this.cbTags.Margin = new System.Windows.Forms.Padding(4);
		this.cbTags.Name = "cbTags";
		this.cbTags.Size = new System.Drawing.Size(361, 21);
		this.cbTags.TabIndex = 26;
		this.cbTags.Text = "Select";
		this.cbTags.SelectedIndexChanged += new System.EventHandler(cbTags_SelectedIndexChanged);
		this.label12.AutoSize = true;
		this.label12.Location = new System.Drawing.Point(424, 20);
		this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.label12.Name = "label12";
		this.label12.Size = new System.Drawing.Size(50, 13);
		this.label12.TabIndex = 25;
		this.label12.Text = "Pick Tag";
		this.btnImport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnImport.Location = new System.Drawing.Point(28, 456);
		this.btnImport.Name = "btnImport";
		this.btnImport.Size = new System.Drawing.Size(136, 39);
		this.btnImport.TabIndex = 27;
		this.btnImport.Text = "Import";
		this.btnImport.UseVisualStyleBackColor = true;
		this.btnImport.Click += new System.EventHandler(btnImport_Click);
		this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.button1.Location = new System.Drawing.Point(723, 456);
		this.button1.Name = "button1";
		this.button1.Size = new System.Drawing.Size(136, 39);
		this.button1.TabIndex = 28;
		this.button1.Text = "Save";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += new System.EventHandler(button1_Click);
		this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(saveFileDialog1_FileOk);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(894, 507);
		base.Controls.Add(this.button1);
		base.Controls.Add(this.btnImport);
		base.Controls.Add(this.cbTags);
		base.Controls.Add(this.label12);
		base.Controls.Add(this.ctrlHTMLEditor);
		base.Name = "MakeAttachment";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Attachment";
		base.Load += new System.EventHandler(Attachment_Load);
		base.ResumeLayout(false);
		base.PerformLayout();
	}
}
