using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using CommonSender;

namespace HeartSender;

public class Feedback : Form
{
	private IContainer components;

	private GroupBox groupBox2;

	private TextBox txtMessage;

	private Label label5;

	private Button btnSubmit;

	public Feedback()
	{
		InitializeComponent();
	}

	private void btnSubmit_Click(object sender, EventArgs e)
	{
		try
		{
			if (new GxApi().submitFeedabck(txtMessage.Text.Trim()) == "101")
			{
				MessageBox.Show("Sorry, something went wrong. Please try again later!", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			else
			{
				MessageBox.Show("Your feedback successfully submitted!", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}
		catch (Exception)
		{
			MessageBox.Show("Sorry, something went wrong. Please try again later!", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.Feedback));
		this.groupBox2 = new System.Windows.Forms.GroupBox();
		this.txtMessage = new System.Windows.Forms.TextBox();
		this.label5 = new System.Windows.Forms.Label();
		this.btnSubmit = new System.Windows.Forms.Button();
		this.groupBox2.SuspendLayout();
		base.SuspendLayout();
		this.groupBox2.Controls.Add(this.btnSubmit);
		this.groupBox2.Controls.Add(this.txtMessage);
		this.groupBox2.Controls.Add(this.label5);
		this.groupBox2.Location = new System.Drawing.Point(5, 4);
		this.groupBox2.Name = "groupBox2";
		this.groupBox2.Size = new System.Drawing.Size(441, 150);
		this.groupBox2.TabIndex = 8;
		this.groupBox2.TabStop = false;
		this.txtMessage.Location = new System.Drawing.Point(6, 24);
		this.txtMessage.Multiline = true;
		this.txtMessage.Name = "txtMessage";
		this.txtMessage.Size = new System.Drawing.Size(428, 84);
		this.txtMessage.TabIndex = 12;
		this.label5.AutoSize = true;
		this.label5.Location = new System.Drawing.Point(3, 4);
		this.label5.Name = "label5";
		this.label5.Size = new System.Drawing.Size(53, 13);
		this.label5.TabIndex = 13;
		this.label5.Text = "Message:";
		this.btnSubmit.Image = (System.Drawing.Image)resources.GetObject("btnSubmit.Image");
		this.btnSubmit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnSubmit.Location = new System.Drawing.Point(333, 113);
		this.btnSubmit.Name = "btnSubmit";
		this.btnSubmit.Size = new System.Drawing.Size(101, 30);
		this.btnSubmit.TabIndex = 9;
		this.btnSubmit.Text = "Submit";
		this.btnSubmit.UseVisualStyleBackColor = true;
		this.btnSubmit.Click += new System.EventHandler(btnSubmit_Click);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(450, 158);
		base.Controls.Add(this.groupBox2);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "Feedback";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Submit Feedback";
		this.groupBox2.ResumeLayout(false);
		this.groupBox2.PerformLayout();
		base.ResumeLayout(false);
	}
}
