using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using CommonSender;

namespace HeartSender;

public class Main : Form
{
	public string[] settings;

	public static List<string> emails = new List<string>();

	public static List<string> firstname = new List<string>();

	public static List<string> lastname = new List<string>();

	public static List<GxSMTP> smtps = new List<GxSMTP>();

	public static List<string> links = new List<string>();

	public static List<string> proxies = new List<string>();

	public static List<string> spamwords = new List<string>();

	public static List<GxSMTP> bulk_smtps = new List<GxSMTP>();

	public static List<GxLetter> letters = new List<GxLetter>();

	public static List<GxLetter> active_letters = new List<GxLetter>();

	public static string selected_letter_index;

	public string[] fromNames;

	public string[] fromSubjects;

	public string[] fromMails;

	private bool has_valid_license = true;

	private BackgroundWorker worker = new BackgroundWorker();

	private int max_threads;

	private int total_emails;

	private int sent;

	private int failed;

	private int pending;

	public string letter = "";

	private int percentage_change;

	private bool is_completed;

	private static object locker = new object();

	public static string sender_email = "";

	public static string is_validate = "";

	public static DateTime last_activity_time;

	private System.Windows.Forms.Timer timer;

	private static int last_stopped_counter = -1;

	public static string keywords_list = "";

	public static string smtp_domain_name = "";

	public static string smtp_user_name = "";

	private static string[] spamList = new string[386]
	{
		"sure", "received", "deliverability", "examples", "compliant", "strict", "variables", "shut", "reputation", "maintain",
		"addresses", "sending", "spam", "unsolicited", "improve", "regard", "single", "users", "rate", "down",
		"How", "again", "very", "provide", "process", "following", "messages", "let", "customers", "monitor",
		"examples", "them", "including", "#1", "$$$", "100% free", "100% Satisfied", "50% off", "Acceptance", "Access",
		"Accordingly", "Act Now!", "Ad", "Affordable", "All new", "Amazing", "Apply now", "Apply Online", "Auto email removal", "Avoid",
		"Bargain", "Beneficiary", "Best price", "Beverage", "Big bucks", "Billing address", "Billion", "Billion dollars", "Bonus", "Brand new pager",
		"Buy", "Cable converter", "Call", "Call free", "Call now", "Cancel at any time", "Cannot be combined with any other offer", "Cards accepted", "Cash", "Cash bonus",
		"Casino", "Celebrity", "Cents on the dollar", "Certified", "Chance", "Cheap", "Check", "Check or money order", "Claims", "Clearance",
		"Click", "Click here", "Click to remove", "Collect", "Compare", "Confidentially on all orders", "Congratulations", "Consolidate debt and credit", "Consolidate your debt", "Copy accurately",
		"Copy DVDs", "Cost", "Credit", "Credit bureaus", "Credit card offers", "Cures baldness", "Deal", "Dear [email/friend/somebody]", "Diagnostics", "Dig up dirt on friends",
		"Direct email", "Direct marketing", "Discount", "Do it today", "Don’t delete", "Don’t hesitate", "Dormant", "Double your", "Drastically reduced", "Earn",
		"Earn $", "Earn extra cash", "Earn per week", "Easy terms", "Eliminate bad credit", "Eliminate debt", "Email harvest", "Email marketing", "Expect to earn", "Explode your business",
		"Extra income", "F r e e", "Fantastic deal", "Fast cash", "Financial freedom", "Financially independent", "For free", "For instant access", "For just $XXX", "For Only",
		"For you", "Form", "Free", "Free access", "Free cell phone", "Free consultation", "Free DVD", "Free gift", "Free installation", "Free Instant",
		"Free investment", "Free leads", "Free membership", "Free money", "Free offer", "Free preview", "Free priority mail", "Free quote", "Free sample", "Free trial",
		"Free website", "Freedom", "Friend", "Full refund", "Get", "Get it now", "Get out of debt", "Get paid", "Get started now", "Give it away",
		"Giving away", "Great offer", "Guarantee", "Guaranteed", "Have you been turned down?", "Hello", "Here", "Hidden", "Hidden assets", "Hidden charges",
		"Home", "Home based", "Homebased business", "Important information regarding", "Income", "Income from home", "Increase sales", "Increase traffic", "Increase your sales", "Incredible deal",
		"Info you requested", "Information you requested", "Instant", "Insurance", "Internet market", "Internet marketing", "Investment", "Investment decision", "It’s effective", "Join millions",
		"Join millions of Americans", "Laser printer", "Leave", "Legal", "Life", "Insurance", "Lifetime", "Limited time", "Loans", "Lose",
		"Lose weight", "Lose weight spam", "Lower interest rate", "Lower monthly payment", "Lower your mortgage rate", "Lowest insurance rates", "Lowest price", "Luxury car", "Mail in order form", "Maintained",
		"Make $", "Make money", "Marketing", "Marketing solutions", "Mass email", "Medicine", "Medium", "Meet singles", "Member", "Message contains",
		"Million", "Million dollars", "Miracle", "Money", "Mortgage", "Mortgage rates", "Name brand", "Never", "New customers only", "New domain extensions",
		"Nigerian", "No age restrictions", "No catch", "No claim forms", "No credit check", "No disappointment", "No experience", "No fees", "No gimmick", "No hidden",
		"Costs", "No inventory", "No-obligation", "Not intended", "Notspam", "Now", "Now only", "Obligation", "Offer", "Offer expires",
		"Once in lifetime", "One hundred percent free", "One hundred percent guaranteed", "One time", "One time mailing", "Online degree", "Online marketing", "Online pharmacy", "Only", "Only $",
		"Open", "Opportunity", "Order", "Order today", "Orders shipped by", "Outstanding values", "Passwords", "Pennies a day", "Per day", "Per week",
		"Performance", "Phone", "Please read", "Potential earnings", "Pre-approved", "Price", "Print out and fax", "Priority mail", "Prize", "Prizes",
		"Problem", "Produced and sent out", "Profits", "Promise you", "Quote", "Refinance", "Refinance home", "Remove", "Reverses", "Rolex",
		"Sale", "Sales", "Sample", "Satisfaction", "Satisfaction guaranteed", "Search engines", "Shopper", "Shopping spree", "Sign up free today", "Social security number",
		"Solution", "Special promotion", "Stainless steel", "Stock alert", "Stock disclaimer statement", "Stock pick", "Stop", "Stop snoring", "Subscribe", "Success",
		"Teen", "Terms and conditions", "The best rates", "The following form", "They keep your money — no refund!", "They’re just giving it away", "This isn’t junk", "This isn’t spam", "Thousands", "Time limited",
		"Trial", "Undisclosed recipient", "University diplomas", "Unlimited", "Unsecured credit", "Unsecured debt", "Unsolicited", "Unsubscribe", "Urgent", "US dollars",
		"Vacation", "Vacation offers", "Valium", "Viagra", "Vicodin", "Visit our website", "Warranty", "We hate spam", "We honor all", "Web traffic",
		"Weekend getaway", "Weight loss", "What are you waiting for?", "While supplies last", "While you sleep", "Who really wins?", "Why pay more?", "Wife", "Will not believe your eyes", "Win",
		"Winner", "Winning", "Won", "Work at home", "Work from home", "Xanax", "You are a winner!", "You have been selected", "You’re a Winner!", "Reverses aging",
		"Hidden assets", "stop snoring", "Free investment", "Dig up dirt on friends", "Stock disclaimer statement", "Multi level marketing", "Compare rates", "Cable converter", "Claims you can be removed from the list", "Removes wrinkles",
		"Compete for your business", "free installation", "Free grant money", "Auto email removal", "Collect child support", "Free leads", "Amazing stuff", "Tells you it's an ad", "Cash bonus", "Promise you",
		"Claims to be in accordance with some spam law", "Search engine listings", "free preview", "Credit bureaus", "No investment", "Serious cash"
	};

	private static ReaderWriterLock bug_locker = new ReaderWriterLock();

	public static GxSMTP bug_reporter;

	public static string attachment_tags = "";

	public static List<string> delivered = new List<string>();

	public static List<int> dead_list = new List<int>();

	public static Hashtable old_active_list = new Hashtable();

	public static List<string> logs = new List<string>();

	public static List<GxIMAPAccount> imap_accounts = new List<GxIMAPAccount>();

	public static bool imap_running = false;

	public static List<string> imap_emails = new List<string>();

	public static bool is_imap_form_hide = false;

	public static bool is_version_checked = false;

	public static string tester_url;

	private static bool is_bug_reporting = false;

	private IMAP imap;

	private IContainer components;

	public MenuStrip menuStrip1;

	public ToolStripMenuItem configurationToolStripMenuItem;

	public ToolStripMenuItem aboutToolStripMenuItem;

	public ToolStripMenuItem aboutMeToolStripMenuItem;

	public ToolStripMenuItem registerToolStripMenuItem;

	public GroupBox groupBox1;

	public GroupBox groupBox2;

	public GroupBox groupBox4;

	public GroupBox groupBox5;

	public GroupBox groupBox9;

	public GroupBox groupBox10;

	public GroupBox groupBox11;

	public GroupBox groupBox12;

	public GroupBox groupBox14;

	public ProgressBar ctrlProgress;

	public Label label1;

	public Label lblTotalSMTP;

	public Button button1;

	public DataGridView gridEmailList;

	public DataGridView gridHostList;

	public Label label2;

	public Label lblTotalEmails;

	public Button btnClear;

	public Button btnEmailAdd;

	public Label label4;

	public NumericUpDown ctrlConNum;

	public Label label5;

	public Label label6;

	public Label label7;

	public CheckBox chkRetryFailed;

	public NumericUpDown ctrlSleepNum;

	public NumericUpDown ctrlPauseNum;

	public NumericUpDown ctrlFailedNum;

	public Button btnStop;

	public Button btnStart;

	public ComboBox ctrlMailPriority;

	public Label lbProgressStatus;

	public Button btnSMTPEdit;

	private Label lblAnnouncement;

	private ToolStripMenuItem ecryptionsToolStripMenuItem;

	private ToolStripMenuItem fileToolStripMenuItem;

	private ToolStripMenuItem loadSettingsToolStripMenuItem;

	private ToolStripMenuItem saveSettingsToolStripMenuItem;

	private ToolStripMenuItem exitToolStripMenuItem;

	private ToolStripMenuItem customHeaderToolStripMenuItem;

	private ToolStripMenuItem manageProxiesToolStripMenuItem;

	private ToolStripMenuItem addLinksToolStripMenuItem1;

	private ToolStripMenuItem addKeywordsToolStripMenuItem1;

	private ToolStripMenuItem spamWordsToolStripMenuItem1;

	private ToolStripMenuItem bluckToolStripMenuItem;

	private Label label3;

	private Label lbIp;

	private GroupBox groupBox15;

	private RichTextBox txtLogs;

	public Button btnLoad;

	private Label label8;

	public CheckBox chkFastSending;

	private ToolStripMenuItem iMAPAccountsToolStripMenuItem;

	private Button btnClearLogs;

	public Button btnIMAPList;

	private ToolStripMenuItem feedbackToolStripMenuItem;

	private DataGridViewTextBoxColumn Host;

	private DataGridViewTextBoxColumn Port;

	private DataGridViewTextBoxColumn Username;

	private DataGridViewTextBoxColumn Password;

	private DataGridViewTextBoxColumn Secure;

	private DataGridViewTextBoxColumn Limit;

	private DataGridViewTextBoxColumn Usage;

	private DataGridViewTextBoxColumn FromEmail;

	private DataGridViewTextBoxColumn No;

	private DataGridViewTextBoxColumn first_name;

	private DataGridViewTextBoxColumn last_name;

	private DataGridViewTextBoxColumn email;

	private DataGridViewTextBoxColumn status;

	private DataGridViewTextBoxColumn Info;

	public Button btnComposeLetter;

	private Button btnAttachment;

	public Button btnClr;

	private DataGridViewTextBoxColumn Column1;

	private DataGridViewTextBoxColumn Column2;

	private DataGridViewTextBoxColumn Column3;

	private DataGridViewTextBoxColumn Column4;

	private DataGridViewTextBoxColumn Column5;

	private DataGridViewCheckBoxColumn Column6;

	public DataGridView gridLetter;

	public Button btnEdit;

	public Main()
	{
		InitializeComponent();
		bindStartupEvents();
	}

	private void bindStartupEvents()
	{
		AddMouseMoveHandler(this);
	}

	public void checkUpdate(EventArgs e)
	{
		WebClient client = new WebClient();
		try
		{
			string obj = client.DownloadString("http://mrcodertools.com/web/updates/HeartSender/version.txt").ToLower().Trim();
			string current_version = GxLogger.getVersionNumber().Trim();
			if (obj.CompareTo(current_version) > 0 && MessageBox.Show("You have an update. Do you want to install?", "HeartSender", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				Process.Start(".\\AutoUpdater.exe");
				Application.Exit();
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
		is_version_checked = true;
	}

	private void userActivityMonitor()
	{
	}

	private void AddMouseMoveHandler(Control c)
	{
		c.MouseMove += Common_MouseMove;
		if (c.Controls.Count <= 0)
		{
			return;
		}
		foreach (Control ct in c.Controls)
		{
			AddMouseMoveHandler(ct);
		}
	}

	public void updateActivity()
	{
		last_activity_time = DateTime.Now;
	}

	private void Main_Closing(object sender, CancelEventArgs e)
	{
		if (is_version_checked && MessageBox.Show("Do you want to save settings", "HeartSender", MessageBoxButtons.YesNo) == DialogResult.Yes)
		{
			saveSettings("settings.xml");
		}
	}

	public string GetPublicIP()
	{
		try
		{
			return new StreamReader(WebRequest.Create("http://checkip.dyndns.org").GetResponse().GetResponseStream()).ReadToEnd().Trim().Split(':')[1].Substring(1).Split('<')[0];
		}
		catch (Exception)
		{
			return "null";
		}
	}

	public void CheckingIp(string ip)
	{
		int count = new GxApi().isValidIPAddress(GxConfig.baseUrl() + "backend/ip-checker");
		if (count >= 0)
		{
			MessageBox.Show("IP Address Ok!", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		else if (count == -1)
		{
			MessageBox.Show("Sorry, there is some problem verifying your IP Address. Please try again later.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
		else
		{
			MessageBox.Show("IP Address blacklist on " + count + " sites.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	private void Main_Load(object sender, EventArgs e)
	{
		checkUpdate(e);
		load_tester_url();
		string ip = GetPublicIP();
		lbIp.Text = ip;
		lbIp.ForeColor = Color.Green;
		if (GxApi.isIPAddressBlocked(lbIp.Text.Trim()))
		{
			lbIp.ForeColor = Color.Red;
		}
		Text = "HeartSender " + GxLogger.getVersionNumber();
		AutoSize = false;
		lbProgressStatus.Text = "Sent : 0 | Failed : 0 | Pending : 0";
		settings = new string[36];
		settings[0] = "5000";
		settings[1] = "UTF8";
		settings[2] = "Unknown";
		settings[3] = "International";
		settings[4] = "No";
		settings[5] = "";
		settings[6] = "0";
		settings[7] = "0";
		settings[8] = "2";
		settings[9] = "0";
		settings[10] = "0";
		settings[11] = "1";
		settings[12] = "1";
		settings[13] = "0";
		settings[14] = "2";
		settings[15] = "0";
		settings[16] = "";
		settings[17] = "";
		settings[18] = "1";
		settings[19] = "3";
		settings[20] = "50";
		settings[21] = "3000";
		settings[22] = "";
		settings[23] = "";
		settings[24] = "";
		settings[26] = "";
		settings[27] = "";
		settings[28] = "";
		settings[29] = "";
		settings[30] = "";
		settings[31] = "";
		settings[32] = "0";
		settings[33] = "0";
		settings[34] = "";
		settings[35] = "0";
		is_validate = settings[35];
		string[] response = new GxLicense().validLicense();
		if (response[0] == "404")
		{
			has_valid_license = false;
			MessageBox.Show(response[1]);
			Application.Exit();
		}
		btnStart.Enabled = true;
		btnStop.Enabled = false;
		gridEmailList.VirtualMode = false;
		updateActivity();
		if (spamwords.Count == 0)
		{
			spamwords = spamList.ToList();
		}
		spamwords = spamwords.Distinct().ToList();
		onInitLoadSettings();
		string message = GxApi.getAnnouncementMessage("backend/get-message");
		if (message != "-1")
		{
			lblAnnouncement.Text = message;
		}
	}

	public void load_tester_url()
	{
		try
		{
			string html = string.Empty;
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create("https://bestfriendstore.net/web/get/get-url?url=url");
			obj.AutomaticDecompression = DecompressionMethods.GZip;
			using (HttpWebResponse response = (HttpWebResponse)obj.GetResponse())
			{
				using Stream stream = response.GetResponseStream();
				using StreamReader reader = new StreamReader(stream);
				html = reader.ReadToEnd();
			}
			tester_url = html;
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
	}

	private void onInitLoadSettings()
	{
		try
		{
			string filename = "settings.xml";
			if (File.Exists(filename))
			{
				string data = File.ReadAllText(filename).Trim();
				XmlDocument doc = new XmlDocument();
				doc.LoadXml(data);
				loadSMTPs(doc);
				loadLetters(doc);
				loadBulkSMTPs(doc);
				loadEmails(doc);
				loadLinks(doc);
				loadProxies(doc);
				loadSettings(doc);
				loadHeaders(doc);
				loadIMAPAccounts(doc);
				resetSettings();
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.StackTrace.ToString(), "HeartSender");
		}
	}

	private void Common_MouseMove(object sender, MouseEventArgs e)
	{
		updateActivity();
	}

	private void extractMailToolStripMenuItem_Click(object sender, EventArgs e)
	{
		MessageBox.Show("Coming Soon...");
	}

	private void office365EditionToolStripMenuItem_Click(object sender, EventArgs e)
	{
		MessageBox.Show("Coming Soon...");
	}

	private void randomApiToolStripMenuItem_Click(object sender, EventArgs e)
	{
		MessageBox.Show("Coming Soon...");
	}

	private void exiteToolStripMenuItem_Click(object sender, EventArgs e)
	{
		Application.Exit();
	}

	private void btnEmailAdd_Click(object sender, EventArgs e)
	{
		new ImportEmail(this).Show();
	}

	public static void populateEmailsList(string[] _emails, Main current_main)
	{
		int index = 0;
		foreach (string email in _emails)
		{
			if (email != null && !(email == ""))
			{
				string formated_email = email.Replace("\\r\\n", "").Replace("\\r", "").Replace("\\n", "")
					.Trim()
					.ToLower();
				index = current_main.gridEmailList.Rows.Add();
				current_main.gridEmailList.Rows[index].Cells["No"].Value = index + 1;
				current_main.gridEmailList.Rows[index].Cells["Email"].Value = formated_email;
				current_main.gridEmailList.Rows[index].Cells["Status"].Value = "";
				current_main.gridEmailList.Rows[index].Cells["Info"].Value = "";
			}
		}
		current_main.lblTotalEmails.Text = current_main.gridEmailList.Rows.Count.ToString();
	}

	public static void populateLinksList(string[] _links, Main current_main)
	{
		links.Clear();
		foreach (string link in _links)
		{
			if (link != null && !(link == ""))
			{
				links.Add(link);
			}
		}
	}

	public static void populateSpamWordsList(string[] _links, Main current_main)
	{
		spamwords.Clear();
		foreach (string link in _links)
		{
			if (link != null && !(link == ""))
			{
				spamwords.Add(link);
			}
		}
		spamwords = spamwords.Distinct().ToList();
	}

	private void btnClear_Click(object sender, EventArgs e)
	{
		gridEmailList.Rows.Clear();
		lblTotalEmails.Text = "0";
	}

	private void button1_Click(object sender, EventArgs e)
	{
		OpenFileDialog file = new OpenFileDialog();
		file.Filter = "txt files (*.txt)|*.txt";
		Stream stream;
		if (file.ShowDialog() == DialogResult.OK && (stream = file.OpenFile()) != null)
		{
			using (StreamReader sr = new StreamReader(stream))
			{
				string[] smtps = sr.ReadToEnd().Split(new string[3] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
				loadSMTPData(smtps);
			}
			stream.Close();
		}
	}

	public void loadSMTPData(string[] data)
	{
		try
		{
			int index = 0;
			smtps.Clear();
			GxDB db = new GxDB();
			for (int i = 0; i < data.Length; i++)
			{
				string[] tokens = data[i].Split(new string[1] { "|" }, StringSplitOptions.None);
				index = gridHostList.Rows.Add();
				gridHostList.Rows[index].Cells["Host"].Value = tokens[0];
				gridHostList.Rows[index].Cells["Port"].Value = tokens[1];
				gridHostList.Rows[index].Cells["Username"].Value = tokens[2];
				gridHostList.Rows[index].Cells["Password"].Value = tokens[3];
				gridHostList.Rows[index].Cells["Secure"].Value = tokens[4];
				gridHostList.Rows[index].Cells["Limit"].Value = "0";
				gridHostList.Rows[index].Cells["usage"].Value = "0";
				gridHostList.Rows[index].Cells["FromEmail"].Value = tokens[5];
				GxSMTP new_smtp = new GxSMTP();
				new_smtp.host = gridHostList.Rows[index].Cells["Host"].Value.ToString();
				new_smtp.port = int.Parse(gridHostList.Rows[index].Cells["Port"].Value.ToString());
				new_smtp.username = gridHostList.Rows[index].Cells["Username"].Value.ToString();
				new_smtp.password = gridHostList.Rows[index].Cells["Password"].Value.ToString();
				new_smtp.max_limit = 0;
				new_smtp.usage_count = db.getSmtpCount(new_smtp.getMd5Code());
				new_smtp.secure = false;
				new_smtp.from_email = gridHostList.Rows[index].Cells["FromEmail"].Value.ToString();
				if (gridHostList.Rows[index].Cells["Secure"].Value != null)
				{
					new_smtp.secure = gridHostList.Rows[index].Cells["Secure"].Value.ToString() == "tls" || gridHostList.Rows[index].Cells["Secure"].Value.ToString() == "ssl";
				}
				smtps.Add(new_smtp);
			}
			lblTotalSMTP.Text = smtps.Count.ToString();
		}
		catch (Exception)
		{
			MessageBox.Show("Sorry, Invalid file format.");
		}
	}

	public void populateSMTPs()
	{
		int index = 0;
		gridHostList.Rows.Clear();
		foreach (GxSMTP smtp in smtps)
		{
			index = gridHostList.Rows.Add();
			gridHostList.Rows[index].Cells["Host"].Value = smtp.host;
			gridHostList.Rows[index].Cells["Port"].Value = smtp.port.ToString();
			gridHostList.Rows[index].Cells["Username"].Value = smtp.username;
			gridHostList.Rows[index].Cells["Password"].Value = smtp.password;
			gridHostList.Rows[index].Cells["Secure"].Value = (smtp.secure ? "ssl" : "");
			gridHostList.Rows[index].Cells["Limit"].Value = smtp.max_limit.ToString();
			gridHostList.Rows[index].Cells["Usage"].Value = smtp.usage_count.ToString();
			gridHostList.Rows[index].Cells["FromEmail"].Value = smtp.from_email;
		}
		lblTotalSMTP.Text = gridHostList.Rows.Count.ToString();
	}

	private void saveSettings(string filename)
	{
		XmlWriter xmlWriter = XmlWriter.Create(GxConfig.getBasePath() + filename);
		xmlWriter.WriteStartDocument();
		xmlWriter.WriteStartElement("HeartSender");
		xmlWriter.WriteStartElement("Letters");
		for (int i = 0; i < letters.Count; i++)
		{
			xmlWriter.WriteStartElement("Letter");
			xmlWriter.WriteStartElement("Name");
			xmlWriter.WriteString(letters[i].name.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Letter");
			xmlWriter.WriteString(letters[i].letter.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Attachment");
			xmlWriter.WriteString(letters[i].attachment.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Is_Html");
			xmlWriter.WriteString(letters[i].is_html.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Is_Enable");
			xmlWriter.WriteString(letters[i].is_enable.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Attachment_tags");
			if (letters[i].attachment_tags.ToString() != "")
			{
				xmlWriter.WriteString(letters[i].attachment_tags.ToString());
			}
			else
			{
				xmlWriter.WriteString("");
			}
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("FromName");
			xmlWriter.WriteString(letters[i].fromname.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("FromEmail");
			int counter = 0;
			for (int j2 = 0; j2 < letters[i].fromemail.Length; j2++)
			{
				if (counter == letters[i].fromemail.Length - 1)
				{
					xmlWriter.WriteString(letters[i].fromemail[j2].ToString());
				}
				else
				{
					xmlWriter.WriteString(letters[i].fromemail[j2].ToString() + "|");
				}
				counter++;
			}
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Subject");
			xmlWriter.WriteString(letters[i].subject.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteEndElement();
		}
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("SMTPS");
		smtps.Clear();
		GxDB db = new GxDB();
		for (int j = 0; j < gridHostList.Rows.Count; j++)
		{
			GxSMTP smtp = new GxSMTP();
			xmlWriter.WriteStartElement("SMTP");
			xmlWriter.WriteStartElement("Host");
			xmlWriter.WriteString(gridHostList.Rows[j].Cells["Host"].Value.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Port");
			xmlWriter.WriteString(gridHostList.Rows[j].Cells["Port"].Value.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Username");
			xmlWriter.WriteString(gridHostList.Rows[j].Cells["Username"].Value.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Password");
			xmlWriter.WriteString(gridHostList.Rows[j].Cells["Password"].Value.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Secure");
			if (gridHostList.Rows[j].Cells["Secure"].Value != null)
			{
				xmlWriter.WriteString(gridHostList.Rows[j].Cells["Secure"].Value.ToString());
			}
			else
			{
				xmlWriter.WriteString("");
			}
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Limit");
			xmlWriter.WriteString(gridHostList.Rows[j].Cells["Limit"].Value.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("FromEmail");
			xmlWriter.WriteString(gridHostList.Rows[j].Cells["FromEmail"].Value.ToString());
			xmlWriter.WriteEndElement();
			smtp.host = gridHostList.Rows[j].Cells["Host"].Value.ToString();
			smtp.port = int.Parse(gridHostList.Rows[j].Cells["Port"].Value.ToString());
			smtp.username = gridHostList.Rows[j].Cells["Username"].Value.ToString();
			smtp.password = gridHostList.Rows[j].Cells["Password"].Value.ToString();
			smtp.max_limit = int.Parse(gridHostList.Rows[j].Cells["Limit"].Value.ToString());
			smtp.usage_count = db.getSmtpCount(smtp.getMd5Code());
			smtp.secure = false;
			smtp.is_proxy = true;
			smtp.from_email = gridHostList.Rows[j].Cells["FromEmail"].Value.ToString();
			xmlWriter.WriteStartElement("Usage");
			xmlWriter.WriteString(smtp.usage_count.ToString());
			xmlWriter.WriteEndElement();
			if (gridHostList.Rows[j].Cells["Secure"].Value != null)
			{
				smtp.secure = gridHostList.Rows[j].Cells["Secure"].Value.ToString() == "tls" || gridHostList.Rows[j].Cells["Secure"].Value.ToString() == "ssl";
			}
			xmlWriter.WriteEndElement();
			smtps.Add(smtp);
		}
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("BulkSMTPS");
		for (int k = 0; k < bulk_smtps.Count; k++)
		{
			xmlWriter.WriteStartElement("SMTP");
			xmlWriter.WriteStartElement("Host");
			xmlWriter.WriteString(bulk_smtps[k].host.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Port");
			xmlWriter.WriteString(bulk_smtps[k].port.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Username");
			xmlWriter.WriteString(bulk_smtps[k].username.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Password");
			xmlWriter.WriteString(bulk_smtps[k].password.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Secure");
			if (bulk_smtps[k].secure)
			{
				xmlWriter.WriteString("ssl");
			}
			else
			{
				xmlWriter.WriteString("");
			}
			xmlWriter.WriteEndElement();
			xmlWriter.WriteEndElement();
		}
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("IMAPAccounts");
		for (int l = 0; l < imap_accounts.Count; l++)
		{
			xmlWriter.WriteStartElement("IMAPAccount");
			xmlWriter.WriteStartElement("IMAPServer");
			xmlWriter.WriteString(imap_accounts[l].server_name.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Port");
			xmlWriter.WriteString(imap_accounts[l].port.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Username");
			xmlWriter.WriteString(imap_accounts[l].username.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Password");
			xmlWriter.WriteString(imap_accounts[l].password.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("Limit");
			xmlWriter.WriteString(imap_accounts[l].limit.ToString());
			xmlWriter.WriteEndElement();
			xmlWriter.WriteStartElement("SSL");
			if (imap_accounts[l].is_ssl)
			{
				xmlWriter.WriteString("SSL");
			}
			else
			{
				xmlWriter.WriteString("None");
			}
			xmlWriter.WriteEndElement();
			xmlWriter.WriteEndElement();
		}
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("Emails");
		emails.Clear();
		for (int i3 = 0; i3 < gridEmailList.Rows.Count; i3++)
		{
			xmlWriter.WriteStartElement("Email");
			xmlWriter.WriteString(gridEmailList.Rows[i3].Cells["Email"].Value.ToString());
			if (gridEmailList.Rows[i3].Cells["first_name"].Value != null)
			{
				xmlWriter.WriteStartElement("FirstName");
				xmlWriter.WriteString(gridEmailList.Rows[i3].Cells["first_name"].Value.ToString());
				xmlWriter.WriteEndElement();
				firstname.Add(gridEmailList.Rows[i3].Cells["first_name"].Value.ToString());
			}
			if (gridEmailList.Rows[i3].Cells["last_name"].Value != null)
			{
				xmlWriter.WriteStartElement("LastName");
				xmlWriter.WriteString(gridEmailList.Rows[i3].Cells["last_name"].Value.ToString());
				xmlWriter.WriteEndElement();
				lastname.Add(gridEmailList.Rows[i3].Cells["last_name"].Value.ToString());
			}
			xmlWriter.WriteEndElement();
			emails.Add(gridEmailList.Rows[i3].Cells["Email"].Value.ToString());
		}
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("Links");
		for (int i2 = 0; i2 < links.Count; i2++)
		{
			xmlWriter.WriteStartElement("Link");
			xmlWriter.WriteString(links[i2].ToString());
			xmlWriter.WriteEndElement();
		}
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("Headers");
		string[] headers = settings[22].Split(';');
		for (int n = 0; n < headers.Length; n++)
		{
			xmlWriter.WriteStartElement("Header");
			xmlWriter.WriteString(headers[n]);
			xmlWriter.WriteEndElement();
		}
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("Proxies");
		for (int m = 0; m < proxies.Count; m++)
		{
			xmlWriter.WriteStartElement("Proxy");
			xmlWriter.WriteString(proxies[m].ToString());
			xmlWriter.WriteEndElement();
		}
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("Settings");
		xmlWriter.WriteStartElement("Connection");
		xmlWriter.WriteString(ctrlConNum.Value.ToString());
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("PauseEvery");
		xmlWriter.WriteString(ctrlPauseNum.Value.ToString());
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("Delay");
		xmlWriter.WriteString(ctrlSleepNum.Value.ToString());
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("RetryFailed");
		xmlWriter.WriteString(ctrlFailedNum.Value.ToString());
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("MailPriority");
		xmlWriter.WriteString(ctrlMailPriority.Text.ToString());
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("TimeOut");
		xmlWriter.WriteString(settings[0]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("TextEncoding");
		xmlWriter.WriteString(settings[1]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("BodyTransferEncoding");
		xmlWriter.WriteString(settings[2]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("DeliveryFormat");
		xmlWriter.WriteString(settings[3]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("AlternativeView");
		xmlWriter.WriteString(settings[4]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("YourEmail");
		xmlWriter.WriteString(settings[5]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("LetterEncoding");
		xmlWriter.WriteString(settings[6]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("LetterEncryption");
		xmlWriter.WriteString(settings[7]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("SubjectEncoding");
		xmlWriter.WriteString(settings[8]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("LinkEncoding");
		xmlWriter.WriteString(settings[9]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("FromNameEncoding");
		xmlWriter.WriteString(settings[10]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("Attachment");
		xmlWriter.WriteString(settings[23]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("AttachmentName");
		xmlWriter.WriteString(settings[24]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("CustomKeyword");
		xmlWriter.WriteString(keywords_list);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("PreHeader");
		xmlWriter.WriteString(settings[26]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("ReplyEmail");
		xmlWriter.WriteString(settings[27]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("ApiKey");
		xmlWriter.WriteString(settings[28]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("ApiDomain");
		xmlWriter.WriteString(settings[29]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("IMAPKeywords");
		xmlWriter.WriteString(settings[30]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("IMAPRunAt");
		xmlWriter.WriteString(settings[31]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("VerifyEmail");
		xmlWriter.WriteString(settings[32]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("AllowDuplicate");
		xmlWriter.WriteString(settings[33]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("SpamWords");
		xmlWriter.WriteString(settings[34]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteStartElement("AllowValidateEmails");
		xmlWriter.WriteString(settings[35]);
		xmlWriter.WriteEndElement();
		xmlWriter.WriteEndElement();
		xmlWriter.WriteEndDocument();
		xmlWriter.Close();
		if (ctrlMailPriority.Text.ToLower() == "high")
		{
			settings[11] = "1";
		}
		else if (ctrlMailPriority.Text.ToLower() == "normal")
		{
			settings[11] = "3";
		}
		else if (ctrlMailPriority.Text.ToLower() == "low")
		{
			settings[11] = "5";
		}
		settings[19] = ctrlConNum.Value.ToString();
		settings[20] = ctrlPauseNum.Value.ToString();
		settings[21] = ctrlSleepNum.Value.ToString();
		percentage_change = (int)((decimal)emails.Count / ctrlConNum.Value);
	}

	private void resetSettings()
	{
		smtps.Clear();
		GxDB db = new GxDB();
		for (int i = 0; i < gridHostList.Rows.Count; i++)
		{
			GxSMTP smtp = new GxSMTP();
			smtp.host = gridHostList.Rows[i].Cells["Host"].Value.ToString();
			smtp.port = int.Parse(gridHostList.Rows[i].Cells["Port"].Value.ToString());
			smtp.username = gridHostList.Rows[i].Cells["Username"].Value.ToString();
			smtp.password = gridHostList.Rows[i].Cells["Password"].Value.ToString();
			smtp.max_limit = int.Parse(gridHostList.Rows[i].Cells["Limit"].Value.ToString());
			smtp.usage_count = db.getSmtpCount(smtp.getMd5Code());
			smtp.secure = false;
			smtp.is_proxy = true;
			if (gridHostList.Rows[i].Cells["Secure"].Value != null)
			{
				smtp.secure = gridHostList.Rows[i].Cells["Secure"].Value.ToString() == "tls" || gridHostList.Rows[i].Cells["Secure"].Value.ToString() == "ssl";
			}
			smtp.from_email = gridHostList.Rows[i].Cells["FromEmail"].Value.ToString();
			smtps.Add(smtp);
		}
		emails.Clear();
		firstname.Clear();
		lastname.Clear();
		for (int j = 0; j < gridEmailList.Rows.Count; j++)
		{
			emails.Add(gridEmailList.Rows[j].Cells["Email"].Value.ToString());
			if (gridEmailList.Rows[j].Cells["first_name"].Value == null)
			{
				firstname.Add("");
				lastname.Add("");
			}
			else
			{
				firstname.Add(gridEmailList.Rows[j].Cells["first_name"].Value.ToString());
				lastname.Add(gridEmailList.Rows[j].Cells["last_name"].Value.ToString());
			}
		}
		if (ctrlMailPriority.Text.ToLower() == "high")
		{
			settings[11] = "1";
		}
		else if (ctrlMailPriority.Text.ToLower() == "normal")
		{
			settings[11] = "3";
		}
		else if (ctrlMailPriority.Text.ToLower() == "low")
		{
			settings[11] = "5";
		}
		else
		{
			settings[11] = "3";
		}
		settings[19] = ctrlConNum.Value.ToString();
		settings[20] = ctrlPauseNum.Value.ToString();
		settings[21] = ctrlSleepNum.Value.ToString();
		percentage_change = (int)((decimal)emails.Count / ctrlConNum.Value);
	}

	public void btnStart_Click(object sender, EventArgs e)
	{
		try
		{
			if (gridEmailList.Rows.Count == 0 || gridHostList.Rows.Count == 0 || gridLetter.Rows.Count == 0)
			{
				MessageBox.Show("Sorry, your settings are not valid.");
			}
			else if (has_valid_license)
			{
				if (chkFastSending.Checked)
				{
					if (MessageBox.Show("You have enabled Fast Sending, which can dead SMTP quickly. Are you sure to go with this option?", "HeartSender", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
					{
						sending();
					}
				}
				else
				{
					sending();
				}
			}
			else
			{
				MessageBox.Show("Sorry, Your license verification failed.");
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show("ERROR" + ex.Message.ToString());
		}
	}

	public void sending()
	{
		ctrlProgress.Value = 0;
		btnStart.Enabled = false;
		btnStop.Enabled = true;
		ctrlProgress.Value = 0;
		is_completed = false;
		resetSettings();
		for (int i = 0; i < gridEmailList.Rows.Count; i++)
		{
			gridEmailList.Rows[i].Cells["Status"].Value = "Pending";
			gridEmailList.Rows[i].Cells["Info"].Value = "";
		}
		ctrlProgress.Minimum = 0;
		ctrlProgress.Maximum = emails.Count;
		ctrlProgress.Value = 0;
		sent = 0;
		pending = 0;
		lbProgressStatus.Text = "Sent : 0 | Failed : 0 | Pending : " + emails.Count;
		GxLogger.writeLog("--- Started ---", is_append: false);
		if (last_stopped_counter != -1)
		{
			last_stopped_counter++;
			if (MessageBox.Show("Do you want to resume?", "HeartSender", MessageBoxButtons.YesNo) == DialogResult.No)
			{
				last_stopped_counter = -1;
			}
		}
		worker = new BackgroundWorker();
		worker.DoWork += bgw_DoWork;
		worker.ProgressChanged += bgw_ProgressChanged;
		worker.RunWorkerCompleted += bgw_RunWorkerCompleted;
		worker.WorkerReportsProgress = true;
		worker.WorkerSupportsCancellation = true;
		if (!worker.IsBusy)
		{
			worker.RunWorkerAsync();
		}
	}

	public void bgw_DoWork(object sender, DoWorkEventArgs e)
	{
		is_bug_reporting = false;
		GxSetting setting = new GxSetting(this);
		bool num = setting.parseData();
		BackgroundWorker worker_job = sender as BackgroundWorker;
		if (num)
		{
			GxLogger.writeLog("Workers started");
			GxItem item = new GxItem();
			Random r = new Random();
			new GxLicense();
			int sleep = setting.config.sending_delay * 1000;
			if (sleep == 0)
			{
				sleep = 3000;
			}
			if (chkFastSending.Checked)
			{
				sleep = 0;
			}
			max_threads = setting.config.email_countsend;
			int counter = 1;
			int counter_resumed = ((last_stopped_counter == -1) ? (-1) : last_stopped_counter);
			total_emails = emails.Count;
			pending = total_emails;
			if (spamwords.Count > 0)
			{
				setting.config.spam_words = string.Join(",", spamwords);
			}
			if (setting.config.enable_duplicate)
			{
				emails = emails.ToList();
			}
			else
			{
				emails = emails.Distinct().ToList();
			}
			GxLogger.writeLog("Emails => " + total_emails);
			if (total_emails < max_threads)
			{
				max_threads = total_emails;
			}
			if (max_threads == 0)
			{
				max_threads = 1;
			}
			if (max_threads > 10)
			{
				max_threads = 10;
			}
			if (emails.Count <= 10)
			{
				max_threads = emails.Count;
			}
			Console.WriteLine("Max Threads: " + max_threads);
			GxLogger.writeLog("Threads => " + max_threads);
			new List<GxSMTP>();
			string[] keywords = keywords_list.Split(new string[1] { "," }, StringSplitOptions.RemoveEmptyEntries);
			GxSMTP.queue.Clear();
			GxSMTP.is_running = false;
			int smtp_counter = 0;
			int batch_size = 0;
			GxApi api = new GxApi();
			string api_url = GxConfig.baseUrl() + "backend/parse";
			string letter_server_response = "";
			string letter_pending = "";
			int cc = 0;
			int active_letter_counter = 0;
			foreach (string current_email in emails)
			{
				updateActivity();
				if (worker_job.CancellationPending)
				{
					break;
				}
				for (int j = 0; j < letters.Count; j++)
				{
					if (letters[j].is_enable)
					{
						active_letters.Add(letters[j]);
					}
				}
				setting.config.from_name = active_letters[active_letter_counter].fromname;
				setting.config.subject = active_letters[active_letter_counter].subject;
				item = new GxItem();
				while (true)
				{
					if (setting.config.smtp.Count == 0)
					{
						MessageBox.Show("Sorry, all SMTP(s) dead or not working.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						break;
					}
					smtp_counter = (item.smtp_index = ((smtp_counter + 1 < setting.config.smtp.Count) ? (smtp_counter + 1) : 0));
					GxSMTP smtp = setting.config.smtp[r.Next(0, setting.config.smtp.Count)];
					if (smtp.max_limit > 0 && new GxDB().getSmtpCount(smtp.getMd5Code()) + batch_size > smtp.max_limit)
					{
						dead_list.Add(item.smtp_index);
						if (dead_list.Count > 0)
						{
							old_active_list = new Hashtable();
							for (int c4 = 0; c4 < setting.config.smtp.Count; c4++)
							{
								if (dead_list.Contains(c4))
								{
									try
									{
										old_active_list.Add(setting.config.smtp[c4].username + ";" + setting.config.smtp[c4].password + ";" + setting.config.smtp[c4].host + ";" + setting.config.smtp[c4].port, "");
									}
									catch (Exception)
									{
									}
								}
							}
							MessageBox.Show("Notice: Some of SMTP(s) max limit reached. Waiting [20 Sec.] ...!", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
							Thread.Sleep(20000);
							setting.parseData();
							List<GxSMTP> active_list2 = new List<GxSMTP>();
							for (int c3 = 0; c3 < setting.config.smtp.Count; c3++)
							{
								try
								{
									string key2 = setting.config.smtp[c3].username + ";" + setting.config.smtp[c3].password + ";" + setting.config.smtp[c3].host + ";" + setting.config.smtp[c3].port;
									if (!old_active_list.ContainsKey(key2))
									{
										active_list2.Add(setting.config.smtp[c3]);
									}
								}
								catch (Exception)
								{
								}
							}
							setting.config.smtp = active_list2;
							dead_list = new List<int>();
							continue;
						}
					}
					if (active_letter_counter == active_letters.Count)
					{
						active_letter_counter = 0;
					}
					int rr = r.Next(0, active_letters[active_letter_counter].fromemail.Length);
					smtp_domain_name = smtp.host;
					smtp_user_name = smtp.username;
					if (smtp.from_email == "" || smtp.from_email == null)
					{
						smtp.from_email = active_letters[active_letter_counter].fromemail[rr];
					}
					else
					{
						for (int i = 0; i < gridHostList.Rows.Count; i++)
						{
							if (gridHostList.Rows[i].Cells["Password"].Value.ToString() == smtp.password)
							{
								if (gridHostList.Rows[i].Cells["FromEmail"].Value.ToString() == "" || gridHostList.Rows[i].Cells["FromEmail"].Value.ToString() == null)
								{
									smtp.from_email = active_letters[active_letter_counter].fromemail[rr];
								}
								else
								{
									smtp.from_email = gridHostList.Rows[i].Cells["FromEmail"].Value.ToString();
								}
							}
						}
					}
					item.counter = counter;
					item.email = current_email;
					item.firstname = firstname[cc].Trim();
					item.lastname = lastname[cc].Trim();
					item.from_name = setting.config.from_name;
					item.target_email_name = setting.config.target_email_name;
					item.reply_email_name = setting.config.reply_email_name;
					item.reply_email = setting.config.reply_email;
					item.config = setting.config;
					item.letter = active_letters[active_letter_counter].letter;
					item.config.using_attachment = 0;
					if (active_letters[active_letter_counter].attachment != "")
					{
						item.config.using_attachment = 1;
						getAttachmentTags(active_letters[active_letter_counter].attachment);
						item.config.file_attachment = active_letters[active_letter_counter].attachment;
					}
					cc++;
					item.headers = settings[22].Split(';');
					item.sending_delay = sleep;
					smtp.item = item;
					smtp.sender_email = sender_email;
					smtp.smtp_domain_name = smtp_domain_name;
					smtp.smtp_user_name = smtp_user_name;
					smtp.item_progress = "";
					smtp.counter_log = "";
					smtp.item.is_sent = false;
					smtp.counter_index = counter - 1;
					if (counter_resumed != -1 && counter_resumed >= counter)
					{
						counter++;
						smtp.item.is_sent = true;
						smtp.counter_log = "Processed";
						smtp.item_progress = "";
						worker_job.ReportProgress(1, DeepCopy(smtp));
					}
					else
					{
						if (batch_size == 0)
						{
							int letter_counter = 1;
							letter_pending = smtp.item.letter;
							letter_pending = letter_pending.Replace("##AUTOEMAILAE##", "##NEW_AUTOEMAILAE##");
							letter_pending = letter_pending.Replace("##EMAIL_LINK##", "##NEW_EMAIL_LINK##");
							letter_pending = letter_pending.Replace("##EMAILB64##", "##NEW_EMAILB64##");
							letter_pending = letter_pending.Replace("##EMAIL##", "##NEW_EMAIL##");
							letter_pending = letter_pending.Replace("##random_email##", "##NEW_random_email##");
							letter_pending = letter_pending.Replace("[-AUTOEMAILAE-]", "[-NEW_AUTOEMAILAE-]");
							letter_pending = letter_pending.Replace("[-EMAIL_LINK-]", "[-NEW_EMAIL_LINK-]");
							letter_pending = letter_pending.Replace("[-EMAILB64-]", "[-NEW_EMAILB64-]");
							letter_pending = letter_pending.Replace("[-EMAIL-]", "[-NEW_EMAIL-]");
							letter_pending = letter_pending.Replace("[-random_email-]", "[-NEW_random_email-]");
							letter_pending = letter_pending.Replace("[-firstname-]", "[-FIRSTNAME-]");
							letter_pending = letter_pending.Replace("[-lastname-]", "[-LASTNAME-]");
							smtp.item.letter = letter_pending;
							object[] o_list = GxSMTP.processEmail(smtp, links, keywords);
							while (true)
							{
								letter_server_response = api.getLetter((List<string>)o_list[1], api_url);
								if (!(letter_server_response == "100") && !(letter_server_response == "101"))
								{
									break;
								}
								smtp.item.is_sent = false;
								smtp.counter_log = "Template Error: " + smtp.server_response;
								worker.ReportProgress(1, smtp);
								letter_counter++;
								if (letter_counter >= 4)
								{
									break;
								}
								Thread.Sleep(3000);
								smtp.item.is_sent = false;
								smtp.counter_log = "Retrying ...";
								worker.ReportProgress(1, smtp);
							}
						}
						smtp.item.letter = letter_pending;
						smtp.server_response = letter_server_response;
						if (smtp.server_response == "100" || smtp.server_response == "101")
						{
							smtp.item.is_sent = false;
							smtp.counter_log = "Template Error: " + smtp.server_response;
							worker.ReportProgress(1, smtp);
							smtp.server_response = "-1";
						}
						batch_size++;
						bool q_status = GxSMTP.addInQueue(worker_job, DeepCopy(smtp));
						if (!q_status)
						{
							while (!q_status)
							{
								Thread.Sleep(10000);
								q_status = GxSMTP.addInQueue(worker_job, DeepCopy(smtp));
							}
						}
						if (batch_size == 1)
						{
							GxSMTP.processQueue(worker_job, keywords, links, proxies, max_threads);
							Thread.Sleep(2000);
							while (GxSMTP.is_running)
							{
								Thread.Sleep(2000);
							}
							batch_size = 0;
						}
						if (dead_list.Count > 0)
						{
							old_active_list = new Hashtable();
							for (int c2 = 0; c2 < setting.config.smtp.Count; c2++)
							{
								if (dead_list.Contains(c2))
								{
									try
									{
										old_active_list.Add(setting.config.smtp[c2].username + ";" + setting.config.smtp[c2].password + ";" + setting.config.smtp[c2].host + ";" + setting.config.smtp[c2].port, "");
									}
									catch (Exception)
									{
									}
								}
							}
							MessageBox.Show("Notice: Some of SMTP(s) are dead or not working. Waiting [20 Sec.] ...!", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
							Thread.Sleep(20000);
							setting.parseData();
							List<GxSMTP> active_list = new List<GxSMTP>();
							for (int c = 0; c < setting.config.smtp.Count; c++)
							{
								try
								{
									string key = setting.config.smtp[c].username + ";" + setting.config.smtp[c].password + ";" + setting.config.smtp[c].host + ";" + setting.config.smtp[c].port;
									if (!old_active_list.ContainsKey(key))
									{
										active_list.Add(setting.config.smtp[c]);
									}
								}
								catch (Exception)
								{
								}
							}
							setting.config.smtp = active_list;
							dead_list = new List<int>();
						}
						if (worker_job.CancellationPending)
						{
							e.Cancel = true;
						}
						counter++;
						active_letter_counter++;
					}
					goto IL_0dee;
				}
				break;
				IL_0dee:;
			}
			if (GxSMTP.queue.Count > 0 && !GxSMTP.is_running)
			{
				GxSMTP.processQueue(worker_job, keywords, links, proxies, max_threads);
				Thread.Sleep(3000);
			}
			while (GxSMTP.is_running && !worker_job.CancellationPending)
			{
				if (worker_job.CancellationPending)
				{
					e.Cancel = true;
				}
				if (pending == 0)
				{
					GxSMTP.is_running = false;
				}
				Thread.Sleep(3000);
				if (GxSMTP.queue.Count > 0 && !GxSMTP.thread.IsAlive)
				{
					GxSMTP.processQueue(worker_job, keywords, links, proxies, max_threads);
					Thread.Sleep(3000);
				}
			}
			GxApi.heartbeat(delivered);
		}
		else
		{
			MessageBox.Show("Invalid Settings", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	public static void showLogs(string log, RichTextBox txt)
	{
		if (logs.Count > 50)
		{
			logs.RemoveRange(0, 1);
		}
		logs.Add("> " + log);
		logs.Reverse();
		txt.Text = string.Join("\n", logs);
		logs.Reverse();
	}

	public void bgw_ProgressChanged(object sender, ProgressChangedEventArgs e)
	{
		GxSMTP smtp = (GxSMTP)e.UserState;
		last_stopped_counter = smtp.counter_index;
		lock (locker)
		{
			if (smtp.item_progress != "")
			{
				if (smtp.item_progress == "Queued")
				{
					gridEmailList.Rows[smtp.counter_index].Cells["Status"].Value = "Queued";
				}
				else
				{
					gridEmailList.Rows[smtp.counter_index].Cells["Info"].Value = smtp.item_progress;
				}
			}
			else
			{
				if ((!(gridEmailList.Rows[smtp.counter_index].Cells["Status"].Value.ToString() == "Queued") && !(gridEmailList.Rows[smtp.counter_index].Cells["Status"].Value.ToString() == "Pending") && !(gridEmailList.Rows[smtp.counter_index].Cells["Status"].Value.ToString() == "Failed")) || !(smtp.counter_log != ""))
				{
					return;
				}
				if (ctrlProgress.Value + smtp.item.progress_count <= ctrlProgress.Maximum)
				{
					ctrlProgress.Value += smtp.item.progress_count;
				}
				showLogs("[" + gridEmailList.Rows[smtp.counter_index].Cells["Email"].Value.ToString() + "][" + smtp.host + "|" + smtp.port + "|" + smtp.username + "|" + smtp.password + "][" + (smtp.item.is_sent ? "Sent" : "Failed") + "][" + smtp.counter_log + "]", txtLogs);
				gridEmailList.Rows[smtp.counter_index].Cells["Status"].Value = (smtp.item.is_sent ? "Sent" : "Failed");
				gridEmailList.Rows[smtp.counter_index].Cells["Info"].Value = smtp.counter_log;
				if (smtp.item.is_sent)
				{
					sent += smtp.item.progress_count;
					if (sent > emails.Count)
					{
						sent = emails.Count;
					}
					pending -= smtp.item.progress_count;
					if (pending < 0)
					{
						pending = 0;
					}
					new GxDB().add(new string[3]
					{
						smtp.item.email,
						"sent",
						smtp.getMd5Code()
					});
					smtp.usage_count++;
				}
				else
				{
					failed += smtp.item.progress_count;
					if (failed > emails.Count)
					{
						failed = emails.Count;
					}
					pending -= smtp.item.progress_count;
					if (pending < 0)
					{
						pending = 0;
					}
				}
				lbProgressStatus.Text = "Sent : " + sent + " | Failed : " + failed + " | Pending : " + pending;
			}
		}
	}

	public void bgw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
	{
		ctrlProgress.Value = emails.Count;
		if (last_stopped_counter + 1 >= emails.Count)
		{
			last_stopped_counter = -1;
		}
		btnStart.Enabled = true;
		btnStop.Enabled = false;
		lbProgressStatus.Text = "Sent : " + sent + " | Failed : " + failed + " | Pending : 0";
		if (!is_completed && !e.Cancelled)
		{
			is_completed = true;
			GxLogger.writeLog("--- Completed ---");
			MessageBox.Show("Done", "HeartSender", MessageBoxButtons.OK);
			active_letters.Clear();
			GxSMTP.count = 0;
		}
		if (e.Cancelled)
		{
			MessageBox.Show("Operation was canceled");
		}
	}

	private void settingsToolStripMenuItem1_Click(object sender, EventArgs e)
	{
		new Settings(this).Show();
	}

	public static void sentEmailsList()
	{
		using StreamWriter file = new StreamWriter(GxConfig.getBasePath() + "confirmed.txt");
		foreach (string line in GxSMTP.confirmed)
		{
			file.WriteLine(line);
		}
	}

	public static void updateEmailsList(GxConfig config, List<string> list)
	{
		using StreamWriter file = new StreamWriter(GxConfig.getBasePath() + config.list_email);
		foreach (string email in list)
		{
			if (!GxSMTP.confirmed.Contains(email))
			{
				file.WriteLine(email);
			}
		}
	}

	public static void failedEmailsList()
	{
		using StreamWriter file = new StreamWriter(GxConfig.getBasePath() + "failed.txt");
		foreach (string line in GxSMTP.failed)
		{
			file.WriteLine(line);
		}
	}

	public static T DeepCopy<T>(T obj)
	{
		if (!typeof(T).IsSerializable)
		{
			throw new Exception("The source object must be serializable");
		}
		if (obj == null)
		{
			throw new Exception("The source object must not be null");
		}
		T result = default(T);
		using MemoryStream memoryStream = new MemoryStream();
		BinaryFormatter binaryFormatter = new BinaryFormatter();
		binaryFormatter.Serialize(memoryStream, obj);
		memoryStream.Seek(0L, SeekOrigin.Begin);
		result = (T)binaryFormatter.Deserialize(memoryStream);
		memoryStream.Close();
		return result;
	}

	public long getEmailsCount(GxConfig config)
	{
		int max = config.mail_limit;
		long lineCounter = 0L;
		using StreamReader reader = new StreamReader(new FileInfo(GxConfig.getBasePath() + config.list_email).FullName);
		string current_email = string.Empty;
		while ((current_email = reader.ReadLine()) != null)
		{
			if (current_email.Trim().Length > 0 && lineCounter < max)
			{
				emails.Add(current_email);
				lineCounter++;
			}
		}
		return lineCounter;
	}

	private void saveConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
	{
		saveSettings("settings.xml");
		MessageBox.Show("Configuration successfully saved.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
	}

	private void loadConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
	{
		try
		{
			OpenFileDialog file = new OpenFileDialog();
			file.Filter = "XML files (*.xml)|*.xml";
			Stream stream;
			if (file.ShowDialog() == DialogResult.OK && (stream = file.OpenFile()) != null)
			{
				using (StreamReader sr = new StreamReader(stream))
				{
					string data = sr.ReadToEnd().Trim();
					XmlDocument doc = new XmlDocument();
					doc.LoadXml(data);
					loadLetters(doc);
					loadSMTPs(doc);
					loadBulkSMTPs(doc);
					loadEmails(doc);
					loadLinks(doc);
					loadProxies(doc);
					loadSettings(doc);
					loadHeaders(doc);
				}
				stream.Close();
				resetSettings();
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message.ToString(), "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	private void loadLetters(XmlDocument doc)
	{
		int index = 0;
		XmlNode node = doc.DocumentElement.SelectSingleNode("/HeartSender/Letters");
		if (node == null || node.ChildNodes == null || node.ChildNodes.Count <= 0)
		{
			return;
		}
		gridLetter.Rows.Clear();
		letters.Clear();
		new GxDB();
		foreach (XmlNode childNode in node.ChildNodes)
		{
			XmlNodeList list = childNode.ChildNodes;
			GxLetter _new_letter = new GxLetter();
			_new_letter.name = list[0].InnerText;
			_new_letter.letter = list[1].InnerText;
			_new_letter.attachment = list[2].InnerText;
			_new_letter.is_html = true;
			_new_letter.is_enable = bool.Parse(list[4].InnerText);
			_new_letter.attachment_tags = list[5].InnerText;
			_new_letter.fromname = list[6].InnerText;
			string[] rw = (_new_letter.fromemail = list[7].InnerText.Split('|'));
			_new_letter.subject = list[8].InnerText;
			letters.Add(_new_letter);
			index = gridLetter.Rows.Add();
			gridLetter.Rows[index].Cells[5].Value = _new_letter.is_enable;
			gridLetter.Rows[index].Cells[0].Value = _new_letter.fromname;
			int counter = 0;
			for (int i = 0; i < _new_letter.fromemail.Length; i++)
			{
				if (counter == _new_letter.fromemail.Length - 1)
				{
					DataGridViewCell dataGridViewCell = gridLetter.Rows[index].Cells[1];
					dataGridViewCell.Value = dataGridViewCell.Value?.ToString() + _new_letter.fromemail[i];
				}
				else
				{
					DataGridViewCell dataGridViewCell2 = gridLetter.Rows[index].Cells[1];
					dataGridViewCell2.Value = dataGridViewCell2.Value?.ToString() + _new_letter.fromemail[i] + "|";
				}
				counter++;
			}
			gridLetter.Rows[index].Cells[2].Value = _new_letter.subject;
			gridLetter.Rows[index].Cells[3].Value = _new_letter.name;
			gridLetter.Rows[index].Cells[4].Value = _new_letter.attachment;
		}
	}

	private void loadSMTPs(XmlDocument doc)
	{
		int index = 0;
		XmlNode node = doc.DocumentElement.SelectSingleNode("/HeartSender/SMTPS");
		if (node == null || node.ChildNodes == null || node.ChildNodes.Count <= 0)
		{
			return;
		}
		gridHostList.Rows.Clear();
		smtps.Clear();
		GxDB db = new GxDB();
		foreach (XmlNode childNode in node.ChildNodes)
		{
			XmlNodeList list = childNode.ChildNodes;
			index = gridHostList.Rows.Add();
			gridHostList.Rows[index].Cells["Host"].Value = list[0].InnerText;
			gridHostList.Rows[index].Cells["Port"].Value = list[1].InnerText;
			gridHostList.Rows[index].Cells["Username"].Value = list[2].InnerText;
			gridHostList.Rows[index].Cells["Password"].Value = list[3].InnerText;
			gridHostList.Rows[index].Cells["Secure"].Value = list[4].InnerText;
			gridHostList.Rows[index].Cells["Limit"].Value = 0;
			GxSMTP new_smtp = new GxSMTP();
			new_smtp.host = gridHostList.Rows[index].Cells["Host"].Value.ToString();
			new_smtp.port = int.Parse(gridHostList.Rows[index].Cells["Port"].Value.ToString());
			new_smtp.username = gridHostList.Rows[index].Cells["Username"].Value.ToString();
			new_smtp.password = gridHostList.Rows[index].Cells["Password"].Value.ToString();
			new_smtp.max_limit = int.Parse(gridHostList.Rows[index].Cells["Limit"].Value.ToString());
			gridHostList.Rows[index].Cells["Usage"].Value = db.getSmtpCount(new_smtp.getMd5Code());
			if (list.Count >= 6)
			{
				gridHostList.Rows[index].Cells["Limit"].Value = list[5].InnerText;
			}
			new_smtp.secure = false;
			if (gridHostList.Rows[index].Cells["Secure"].Value != null)
			{
				new_smtp.secure = gridHostList.Rows[index].Cells["Secure"].Value.ToString() == "tls" || gridHostList.Rows[index].Cells["Secure"].Value.ToString() == "ssl";
			}
			gridHostList.Rows[index].Cells["FromEmail"].Value = "";
			if (list.Count >= 7)
			{
				new_smtp.from_email = list[6].InnerText.Trim();
				gridHostList.Rows[index].Cells["FromEmail"].Value = list[6].InnerText;
			}
			smtps.Add(new_smtp);
		}
		lblTotalSMTP.Text = gridHostList.Rows.Count.ToString();
	}

	private void loadIMAPAccounts(XmlDocument doc)
	{
		XmlNode node = doc.DocumentElement.SelectSingleNode("/HeartSender/IMAPAccounts");
		if (node == null || node.ChildNodes == null || node.ChildNodes.Count <= 0)
		{
			return;
		}
		imap_accounts.Clear();
		foreach (XmlNode childNode in node.ChildNodes)
		{
			XmlNodeList list = childNode.ChildNodes;
			GxIMAPAccount imap = new GxIMAPAccount();
			imap.server_name = list[0].InnerText;
			imap.port = int.Parse(list[1].InnerText);
			imap.username = list[2].InnerText;
			imap.password = list[3].InnerText;
			imap.limit = int.Parse(list[4].InnerText);
			imap.is_ssl = false;
			if (list[5].InnerText.ToLower() == "ssl")
			{
				imap.is_ssl = true;
			}
			imap_accounts.Add(imap);
		}
	}

	private void load(XmlDocument doc)
	{
		XmlNode node = doc.DocumentElement.SelectSingleNode("/HeartSender/BulkSMTPS");
		if (node == null || node.ChildNodes == null || node.ChildNodes.Count <= 0)
		{
			return;
		}
		bulk_smtps.Clear();
		GxDB db = new GxDB();
		foreach (XmlNode childNode in node.ChildNodes)
		{
			XmlNodeList list = childNode.ChildNodes;
			GxSMTP new_smtp = new GxSMTP();
			new_smtp.host = list[0].InnerText;
			new_smtp.port = int.Parse(list[1].InnerText);
			new_smtp.username = list[2].InnerText;
			new_smtp.password = list[3].InnerText;
			new_smtp.usage_count = db.getSmtpCount(new_smtp.getMd5Code());
			new_smtp.secure = false;
			if (list[4].InnerText != null)
			{
				new_smtp.secure = list[4].InnerText == "tls" || list[4].InnerText == "ssl";
			}
			if (list.Count >= 6)
			{
				new_smtp.max_limit = int.Parse(list[5].InnerText.Trim());
			}
			bulk_smtps.Add(new_smtp);
		}
	}

	private void loadBulkSMTPs(XmlDocument doc)
	{
		XmlNode node = doc.DocumentElement.SelectSingleNode("/HeartSender/BulkSMTPS");
		if (node == null || node.ChildNodes == null || node.ChildNodes.Count <= 0)
		{
			return;
		}
		bulk_smtps.Clear();
		GxDB db = new GxDB();
		foreach (XmlNode childNode in node.ChildNodes)
		{
			XmlNodeList list = childNode.ChildNodes;
			GxSMTP new_smtp = new GxSMTP();
			new_smtp.host = list[0].InnerText;
			new_smtp.port = int.Parse(list[1].InnerText);
			new_smtp.username = list[2].InnerText;
			new_smtp.password = list[3].InnerText;
			new_smtp.usage_count = db.getSmtpCount(new_smtp.getMd5Code());
			new_smtp.secure = false;
			if (list[4].InnerText != null)
			{
				new_smtp.secure = list[4].InnerText == "tls" || list[4].InnerText == "ssl";
			}
			if (list.Count >= 6)
			{
				new_smtp.max_limit = int.Parse(list[5].InnerText.Trim());
			}
			bulk_smtps.Add(new_smtp);
		}
	}

	private void loadEmails(XmlDocument doc)
	{
		int index = 0;
		XmlNode node = doc.DocumentElement.SelectSingleNode("/HeartSender/Emails");
		if (node == null || node.ChildNodes == null || node.ChildNodes.Count <= 0)
		{
			return;
		}
		gridEmailList.Rows.Clear();
		foreach (XmlNode childNode in node.ChildNodes)
		{
			XmlNodeList list = childNode.ChildNodes;
			if (list.Count > 1)
			{
				index = gridEmailList.Rows.Add();
				gridEmailList.Rows[index].Cells["No"].Value = index + 1;
				gridEmailList.Rows[index].Cells["Email"].Value = list[0].InnerText;
				gridEmailList.Rows[index].Cells["first_name"].Value = list[1].InnerText;
				gridEmailList.Rows[index].Cells["last_name"].Value = list[2].InnerText;
				gridEmailList.Rows[index].Cells["Status"].Value = "";
				gridEmailList.Rows[index].Cells["Info"].Value = "";
			}
			else
			{
				index = gridEmailList.Rows.Add();
				gridEmailList.Rows[index].Cells["No"].Value = index + 1;
				gridEmailList.Rows[index].Cells["Email"].Value = list[0].InnerText;
				gridEmailList.Rows[index].Cells["Status"].Value = "";
				gridEmailList.Rows[index].Cells["Info"].Value = "";
			}
		}
		lblTotalEmails.Text = gridEmailList.Rows.Count.ToString();
	}

	private void loadLinks(XmlDocument doc)
	{
		XmlNode node = doc.DocumentElement.SelectSingleNode("/HeartSender/Links");
		if (node == null || node.ChildNodes == null || node.ChildNodes.Count <= 0)
		{
			return;
		}
		links.Clear();
		foreach (XmlNode childNode in node.ChildNodes)
		{
			XmlNodeList list = childNode.ChildNodes;
			links.Add(list[0].InnerText);
		}
	}

	private void loadProxies(XmlDocument doc)
	{
		XmlNode node = doc.DocumentElement.SelectSingleNode("/HeartSender/Proxies");
		if (node == null || node.ChildNodes == null || node.ChildNodes.Count <= 0)
		{
			return;
		}
		proxies.Clear();
		foreach (XmlNode childNode in node.ChildNodes)
		{
			XmlNodeList list = childNode.ChildNodes;
			proxies.Add(list[0].InnerText);
		}
	}

	private void loadSettings(XmlDocument doc)
	{
		XmlNode node = doc.DocumentElement.SelectSingleNode("/HeartSender/Settings");
		if (node.ChildNodes.Count <= 0)
		{
			return;
		}
		foreach (XmlNode inner_node in node.ChildNodes)
		{
			switch (inner_node.Name)
			{
			case "Connection":
				ctrlConNum.Value = int.Parse(inner_node.InnerText);
				settings[19] = inner_node.InnerText;
				break;
			case "PauseEvery":
				ctrlPauseNum.Value = int.Parse(inner_node.InnerText);
				settings[20] = inner_node.InnerText;
				break;
			case "Delay":
				ctrlSleepNum.Value = int.Parse(inner_node.InnerText);
				settings[21] = inner_node.InnerText;
				break;
			case "RetryFailed":
				ctrlFailedNum.Value = int.Parse(inner_node.InnerText);
				break;
			case "MailPriority":
				ctrlMailPriority.Text = inner_node.InnerText;
				settings[11] = inner_node.InnerText;
				break;
			case "TimeOut":
				settings[0] = inner_node.InnerText;
				break;
			case "TextEncoding":
				settings[1] = inner_node.InnerText;
				break;
			case "BodyTransferEncoding":
				settings[2] = inner_node.InnerText;
				break;
			case "DeliveryFormat":
				settings[3] = inner_node.InnerText;
				break;
			case "AlternativeView":
				settings[4] = inner_node.InnerText;
				break;
			case "YourEmail":
				settings[5] = inner_node.InnerText;
				break;
			case "LetterEncoding":
				settings[6] = inner_node.InnerText;
				break;
			case "LetterEncryption":
				settings[7] = inner_node.InnerText;
				break;
			case "SubjectEncoding":
				settings[8] = inner_node.InnerText;
				break;
			case "LinkEncoding":
				settings[9] = inner_node.InnerText;
				break;
			case "FromNameEncoding":
				settings[10] = inner_node.InnerText;
				break;
			case "AttachmentName":
				settings[24] = inner_node.InnerText;
				break;
			case "CustomKeyword":
				keywords_list = inner_node.InnerText.Trim();
				break;
			case "PreHeader":
				settings[26] = inner_node.InnerText;
				break;
			case "ReplyEmail":
				settings[27] = inner_node.InnerText;
				break;
			case "ApiKey":
				settings[28] = inner_node.InnerText;
				break;
			case "ApiDomain":
				settings[29] = inner_node.InnerText;
				break;
			case "IMAPKeywords":
				settings[30] = inner_node.InnerText;
				break;
			case "IMAPRunAt":
				settings[31] = inner_node.InnerText;
				break;
			case "VerifyEmail":
				settings[32] = ((inner_node.InnerText == null || inner_node.InnerText == "") ? "0" : inner_node.InnerText);
				break;
			case "AllowDuplicate":
				settings[33] = ((inner_node.InnerText == null || inner_node.InnerText == "") ? "0" : inner_node.InnerText);
				break;
			case "SpamWords":
				settings[34] = ((inner_node.InnerText == null || inner_node.InnerText == "") ? "0" : inner_node.InnerText);
				break;
			case "AllowValidateEmails":
				settings[35] = ((inner_node.InnerText == null || inner_node.InnerText == "") ? "0" : inner_node.InnerText);
				is_validate = settings[35];
				break;
			}
		}
	}

	private void loadHeaders(XmlDocument doc)
	{
		int index = -1;
		XmlNode node = doc.DocumentElement.SelectSingleNode("/HeartSender/Headers");
		if (node == null || node.ChildNodes == null || node.ChildNodes.Count <= 0)
		{
			return;
		}
		string[] data = new string[node.ChildNodes.Count];
		foreach (XmlNode childNode in node.ChildNodes)
		{
			XmlNodeList list = childNode.ChildNodes;
			if (list != null && list.Count > 0)
			{
				data[++index] = list[0].InnerText;
			}
		}
		settings[22] = string.Join(";", data);
	}

	private void aboutMeToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new About().Show();
	}

	private void registerToolStripMenuItem_Click(object sender, EventArgs e)
	{
		MessageBox.Show("Please paste license key in license.txt");
	}

	private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new CustomHeaders(this).Show();
	}

	private void btnSMTPEdit_Click(object sender, EventArgs e)
	{
		new ManageSMTP(this).Show();
	}

	private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
	{
		OpenFileDialog file = new OpenFileDialog();
		file.Filter = "All files (*.*)|*.*";
		if (file.ShowDialog() == DialogResult.OK)
		{
			settings[23] = file.FileName;
			MessageBox.Show("Attachment selected");
		}
	}

	public void getAttachmentTags(string path)
	{
		FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
		string content = string.Empty;
		new FileInfo(path);
		_ = new string[6] { ".html", ".htm", ".txt", ".rtf", ".log", ".tex" };
		using StreamReader streamReader = new StreamReader(fs, Encoding.UTF8);
		content = streamReader.ReadToEnd();
		Match i = new Regex("(\\#\\#.*?\\#\\#)").Match(content);
		List<string> matches = new List<string>();
		while (i.Success)
		{
			matches.Add(i.Value);
			i = i.NextMatch();
		}
		i = new Regex("(\\[\\-.*?\\-\\])").Match(content);
		while (i.Success)
		{
			matches.Add(i.Value);
			i = i.NextMatch();
		}
		matches = matches.Distinct().ToList();
		attachment_tags = string.Join("|||", matches);
		attachment_tags = attachment_tags.Replace("##AUTOEMAILAE##", "##NEW_AUTOEMAILAE##");
		attachment_tags = attachment_tags.Replace("##EMAIL_LINK##", "##NEW_EMAIL_LINK##");
		attachment_tags = attachment_tags.Replace("##EMAILB64##", "##NEW_EMAILB64##");
		attachment_tags = attachment_tags.Replace("##EMAIL##", "##NEW_EMAIL##");
		attachment_tags = attachment_tags.Replace("[-AUTOEMAILAE-]", "[-NEW_AUTOEMAILAE-]");
		attachment_tags = attachment_tags.Replace("[-EMAIL_LINK-]", "[-NEW_EMAIL_LINK-]");
		attachment_tags = attachment_tags.Replace("[-EMAILB64-]", "[-NEW_EMAILB64-]");
		attachment_tags = attachment_tags.Replace("[-EMAIL-]", "[-NEW_EMAIL-]");
		attachment_tags = attachment_tags.Replace("[-firstname-]", "[-FIRSTNAME-]");
		attachment_tags = attachment_tags.Replace("[-lastname-]", "[-LASTNAME-]");
	}

	private void btnStop_Click(object sender, EventArgs e)
	{
		worker.CancelAsync();
		btnStop.Enabled = false;
		active_letters.Clear();
		GxSMTP.count = 0;
	}

	private void howToUseToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new Help().Show();
	}

	private void addLinksToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new DomainLinks(this).Show();
	}

	private void addKeywordsToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new AddKeyword(this).Show();
	}

	private void addProxiesToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new ProxiesList(this).Show();
	}

	private void button2_Click(object sender, EventArgs e)
	{
	}

	private void spamWordsToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new SpamWords(this).Show();
	}

	private void btnCheckSpam_Click(object sender, EventArgs e)
	{
	}

	private void bulkSMTPCheckerToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new BulkSMTP(this).Show();
	}

	private void groupBox9_Enter(object sender, EventArgs e)
	{
	}

	private void button2_Click_1(object sender, EventArgs e)
	{
		MessageBox.Show(new GxApi().isValidSMTP(GxConfig.baseUrl() + "backend/smtp-checker", new string[7] { "secure.emailsrvr.com", "socialmedia@amhosp.org", "Smedia@27HR", "587", "1", "socialmedia@amhosp.org", "socialmedia1@amhosp.org" }));
	}

	private void ecryptionsToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new Settings(this).Show();
	}

	private void saveSettingsToolStripMenuItem_Click(object sender, EventArgs e)
	{
		saveSettings("settings.xml");
		MessageBox.Show("Configuration successfully saved.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
	}

	private void fileToolStripMenuItem_Click(object sender, EventArgs e)
	{
	}

	private void loadSettingsToolStripMenuItem_Click_1(object sender, EventArgs e)
	{
		try
		{
			OpenFileDialog file = new OpenFileDialog();
			file.Filter = "XML files (*.xml)|*.xml";
			Stream stream;
			if (file.ShowDialog() == DialogResult.OK && (stream = file.OpenFile()) != null)
			{
				using (StreamReader sr = new StreamReader(stream))
				{
					string data = sr.ReadToEnd().Trim();
					XmlDocument doc = new XmlDocument();
					doc.LoadXml(data);
					loadLetters(doc);
					loadSMTPs(doc);
					loadBulkSMTPs(doc);
					loadEmails(doc);
					loadLinks(doc);
					loadProxies(doc);
					loadSettings(doc);
					loadHeaders(doc);
					loadIMAPAccounts(doc);
				}
				stream.Close();
				resetSettings();
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message.ToString(), "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	private void saveSettingsToolStripMenuItem_Click_1(object sender, EventArgs e)
	{
		saveSettings("settings.xml");
		MessageBox.Show("Configuration successfully saved.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
	}

	private void exitToolStripMenuItem_Click(object sender, EventArgs e)
	{
		Application.Exit();
	}

	private void customHeaderToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new CustomHeaders(this).Show();
	}

	private void addLinksToolStripMenuItem1_Click(object sender, EventArgs e)
	{
		new DomainLinks(this).Show();
	}

	private void addKeywordsToolStripMenuItem1_Click(object sender, EventArgs e)
	{
		new AddKeyword(this).Show();
	}

	private void spamWordsToolStripMenuItem1_Click(object sender, EventArgs e)
	{
		new SpamWords(this).Show();
	}

	private void bluckToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new BulkSMTP(this).Show();
	}

	private void manageProxiesToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new ProxiesList(this).Show();
	}

	private void btnAttachment_Click(object sender, EventArgs e)
	{
		new MakeAttachment(this).ShowDialog();
	}

	private void btnLoad_Click(object sender, EventArgs e)
	{
		OpenFileDialog file = new OpenFileDialog();
		file.Filter = "txt files (*.txt)|*.txt";
		if (file.ShowDialog() != DialogResult.OK)
		{
			return;
		}
		Stream stream;
		if ((stream = file.OpenFile()) != null)
		{
			int index = 0;
			using StreamReader sr = new StreamReader(stream);
			string line;
			while ((line = sr.ReadLine()) != null)
			{
				if (line.Contains("|"))
				{
					string[] tokens = line.Split(new string[1] { "|" }, StringSplitOptions.None);
					index = gridEmailList.Rows.Add();
					gridEmailList.Rows[index].Cells[0].Value = (index + 1).ToString();
					gridEmailList.Rows[index].Cells[1].Value = tokens[0];
					gridEmailList.Rows[index].Cells[2].Value = tokens[1];
					gridEmailList.Rows[index].Cells[3].Value = tokens[2];
					index++;
				}
				else
				{
					index = gridEmailList.Rows.Add();
					gridEmailList.Rows[index].Cells[0].Value = (index + 1).ToString();
					gridEmailList.Rows[index].Cells[3].Value = line;
				}
			}
			lblTotalEmails.Text = gridEmailList.Rows.Count.ToString();
		}
		stream.Close();
	}

	private void btnComposeLetter_Click(object sender, EventArgs e)
	{
		new Compose(this).Show();
	}

	private void iMAPAccountsToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new IMAP(this).Show();
	}

	private void btnClearLogs_Click(object sender, EventArgs e)
	{
		txtLogs.Text = "";
		logs.Clear();
	}

	private void btnIMAPList_Click(object sender, EventArgs e)
	{
		if (!imap_running)
		{
			imap = new IMAP(this);
			imap.Show();
		}
		else
		{
			is_imap_form_hide = false;
			imap.show_imap();
		}
	}

	private void btnClearProcess_Click(object sender, EventArgs e)
	{
		txtLogs.Text = "";
	}

	private void btnLoadFromImap_Click(object sender, EventArgs e)
	{
		populateEmailsList(imap_emails.ToArray(), this);
	}

	private void feedbackToolStripMenuItem_Click(object sender, EventArgs e)
	{
		new Feedback().Show();
	}

	private void gridEmailList_CellContentClick(object sender, DataGridViewCellEventArgs e)
	{
	}

	private void btnAttachment_Click_1(object sender, EventArgs e)
	{
		if (gridLetter.Rows.Count > 0)
		{
			letters.RemoveAt(gridLetter.SelectedRows[0].Index);
			gridLetter.Rows.RemoveAt(gridLetter.SelectedRows[0].Index);
		}
		else
		{
			MessageBox.Show("Nothing To remove !!!");
		}
	}

	private void btnComposeLetter_Click_1(object sender, EventArgs e)
	{
		selected_letter_index = "";
		new Compose(this).ShowDialog();
	}

	private void btnClr_Click(object sender, EventArgs e)
	{
		if (gridLetter.Rows.Count > 0)
		{
			letters.Clear();
			gridLetter.Rows.Clear();
		}
		else
		{
			MessageBox.Show("Nothing to Clear !!!");
		}
	}

	private void gridLetter_CellValueChanged(object sender, DataGridViewCellEventArgs e)
	{
		if (gridLetter.Rows.Count > 0 && e.RowIndex != -1)
		{
			if ((bool)gridLetter.Rows[e.RowIndex].Cells[5].Value)
			{
				letters[e.RowIndex].is_enable = true;
			}
			else
			{
				letters[e.RowIndex].is_enable = false;
			}
		}
	}

	private void gridLetter_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
	{
		if (gridLetter.Rows.Count > 0 && e.RowIndex != -1)
		{
			gridLetter.EndEdit();
		}
	}

	private void btnEdit_Click(object sender, EventArgs e)
	{
		if (gridLetter.Rows.Count > 0)
		{
			selected_letter_index = gridLetter.SelectedRows[0].Index.ToString();
			new Compose(this).ShowDialog();
		}
		else
		{
			MessageBox.Show("Nothing To remove !!!");
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.Main));
		System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
		this.menuStrip1 = new System.Windows.Forms.MenuStrip();
		this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.loadSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.saveSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.ecryptionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.configurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.customHeaderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.manageProxiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.addLinksToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
		this.addKeywordsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
		this.spamWordsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
		this.bluckToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.iMAPAccountsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.aboutMeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.registerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.feedbackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.groupBox9 = new System.Windows.Forms.GroupBox();
		this.chkFastSending = new System.Windows.Forms.CheckBox();
		this.ctrlMailPriority = new System.Windows.Forms.ComboBox();
		this.btnStart = new System.Windows.Forms.Button();
		this.btnStop = new System.Windows.Forms.Button();
		this.ctrlFailedNum = new System.Windows.Forms.NumericUpDown();
		this.ctrlSleepNum = new System.Windows.Forms.NumericUpDown();
		this.ctrlPauseNum = new System.Windows.Forms.NumericUpDown();
		this.chkRetryFailed = new System.Windows.Forms.CheckBox();
		this.label7 = new System.Windows.Forms.Label();
		this.label6 = new System.Windows.Forms.Label();
		this.label5 = new System.Windows.Forms.Label();
		this.ctrlConNum = new System.Windows.Forms.NumericUpDown();
		this.label4 = new System.Windows.Forms.Label();
		this.groupBox10 = new System.Windows.Forms.GroupBox();
		this.groupBox11 = new System.Windows.Forms.GroupBox();
		this.groupBox12 = new System.Windows.Forms.GroupBox();
		this.groupBox5 = new System.Windows.Forms.GroupBox();
		this.gridLetter = new System.Windows.Forms.DataGridView();
		this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column6 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
		this.btnComposeLetter = new System.Windows.Forms.Button();
		this.btnAttachment = new System.Windows.Forms.Button();
		this.btnClr = new System.Windows.Forms.Button();
		this.groupBox4 = new System.Windows.Forms.GroupBox();
		this.btnIMAPList = new System.Windows.Forms.Button();
		this.btnLoad = new System.Windows.Forms.Button();
		this.btnClear = new System.Windows.Forms.Button();
		this.btnEmailAdd = new System.Windows.Forms.Button();
		this.lblTotalEmails = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.gridEmailList = new System.Windows.Forms.DataGridView();
		this.No = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.first_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.last_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.email = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.status = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Info = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.groupBox2 = new System.Windows.Forms.GroupBox();
		this.btnSMTPEdit = new System.Windows.Forms.Button();
		this.gridHostList = new System.Windows.Forms.DataGridView();
		this.Host = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Port = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Username = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Secure = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Limit = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Usage = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.FromEmail = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.button1 = new System.Windows.Forms.Button();
		this.lblTotalSMTP = new System.Windows.Forms.Label();
		this.label1 = new System.Windows.Forms.Label();
		this.groupBox14 = new System.Windows.Forms.GroupBox();
		this.ctrlProgress = new System.Windows.Forms.ProgressBar();
		this.lbProgressStatus = new System.Windows.Forms.Label();
		this.lblAnnouncement = new System.Windows.Forms.Label();
		this.label3 = new System.Windows.Forms.Label();
		this.lbIp = new System.Windows.Forms.Label();
		this.groupBox15 = new System.Windows.Forms.GroupBox();
		this.txtLogs = new System.Windows.Forms.RichTextBox();
		this.label8 = new System.Windows.Forms.Label();
		this.btnClearLogs = new System.Windows.Forms.Button();
		this.btnEdit = new System.Windows.Forms.Button();
		this.menuStrip1.SuspendLayout();
		this.groupBox1.SuspendLayout();
		this.groupBox9.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.ctrlFailedNum).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.ctrlSleepNum).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.ctrlPauseNum).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.ctrlConNum).BeginInit();
		this.groupBox10.SuspendLayout();
		this.groupBox5.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.gridLetter).BeginInit();
		this.groupBox4.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.gridEmailList).BeginInit();
		this.groupBox2.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.gridHostList).BeginInit();
		this.groupBox14.SuspendLayout();
		this.groupBox15.SuspendLayout();
		base.SuspendLayout();
		this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
		this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[6] { this.fileToolStripMenuItem, this.ecryptionsToolStripMenuItem, this.configurationToolStripMenuItem, this.iMAPAccountsToolStripMenuItem, this.aboutToolStripMenuItem, this.feedbackToolStripMenuItem });
		this.menuStrip1.Location = new System.Drawing.Point(0, 0);
		this.menuStrip1.Name = "menuStrip1";
		this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
		this.menuStrip1.Size = new System.Drawing.Size(998, 28);
		this.menuStrip1.TabIndex = 0;
		this.menuStrip1.Text = "menuStrip1";
		this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[3] { this.loadSettingsToolStripMenuItem, this.saveSettingsToolStripMenuItem, this.exitToolStripMenuItem });
		this.fileToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("fileToolStripMenuItem.Image");
		this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
		this.fileToolStripMenuItem.Size = new System.Drawing.Size(57, 24);
		this.fileToolStripMenuItem.Text = "File";
		this.fileToolStripMenuItem.Click += new System.EventHandler(fileToolStripMenuItem_Click);
		this.loadSettingsToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("loadSettingsToolStripMenuItem.Image");
		this.loadSettingsToolStripMenuItem.Name = "loadSettingsToolStripMenuItem";
		this.loadSettingsToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
		this.loadSettingsToolStripMenuItem.Text = "Load Settings";
		this.loadSettingsToolStripMenuItem.Click += new System.EventHandler(loadSettingsToolStripMenuItem_Click_1);
		this.saveSettingsToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("saveSettingsToolStripMenuItem.Image");
		this.saveSettingsToolStripMenuItem.Name = "saveSettingsToolStripMenuItem";
		this.saveSettingsToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
		this.saveSettingsToolStripMenuItem.Text = "Save Settings";
		this.saveSettingsToolStripMenuItem.Click += new System.EventHandler(saveSettingsToolStripMenuItem_Click_1);
		this.exitToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("exitToolStripMenuItem.Image");
		this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
		this.exitToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
		this.exitToolStripMenuItem.Text = "Exit";
		this.exitToolStripMenuItem.Click += new System.EventHandler(exitToolStripMenuItem_Click);
		this.ecryptionsToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("ecryptionsToolStripMenuItem.Image");
		this.ecryptionsToolStripMenuItem.Name = "ecryptionsToolStripMenuItem";
		this.ecryptionsToolStripMenuItem.Size = new System.Drawing.Size(113, 24);
		this.ecryptionsToolStripMenuItem.Text = "Configuration";
		this.ecryptionsToolStripMenuItem.Click += new System.EventHandler(ecryptionsToolStripMenuItem_Click);
		this.configurationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[6] { this.customHeaderToolStripMenuItem, this.manageProxiesToolStripMenuItem, this.addLinksToolStripMenuItem1, this.addKeywordsToolStripMenuItem1, this.spamWordsToolStripMenuItem1, this.bluckToolStripMenuItem });
		this.configurationToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("configurationToolStripMenuItem.Image");
		this.configurationToolStripMenuItem.Name = "configurationToolStripMenuItem";
		this.configurationToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
		this.configurationToolStripMenuItem.Text = "Features";
		this.customHeaderToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("customHeaderToolStripMenuItem.Image");
		this.customHeaderToolStripMenuItem.Name = "customHeaderToolStripMenuItem";
		this.customHeaderToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
		this.customHeaderToolStripMenuItem.Text = "Custom Headers";
		this.customHeaderToolStripMenuItem.Click += new System.EventHandler(customHeaderToolStripMenuItem_Click);
		this.manageProxiesToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("manageProxiesToolStripMenuItem.Image");
		this.manageProxiesToolStripMenuItem.Name = "manageProxiesToolStripMenuItem";
		this.manageProxiesToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
		this.manageProxiesToolStripMenuItem.Text = "Manage Proxies";
		this.manageProxiesToolStripMenuItem.Click += new System.EventHandler(manageProxiesToolStripMenuItem_Click);
		this.addLinksToolStripMenuItem1.Image = (System.Drawing.Image)resources.GetObject("addLinksToolStripMenuItem1.Image");
		this.addLinksToolStripMenuItem1.Name = "addLinksToolStripMenuItem1";
		this.addLinksToolStripMenuItem1.Size = new System.Drawing.Size(176, 22);
		this.addLinksToolStripMenuItem1.Text = "Add Links";
		this.addLinksToolStripMenuItem1.Click += new System.EventHandler(addLinksToolStripMenuItem1_Click);
		this.addKeywordsToolStripMenuItem1.Image = (System.Drawing.Image)resources.GetObject("addKeywordsToolStripMenuItem1.Image");
		this.addKeywordsToolStripMenuItem1.Name = "addKeywordsToolStripMenuItem1";
		this.addKeywordsToolStripMenuItem1.Size = new System.Drawing.Size(176, 22);
		this.addKeywordsToolStripMenuItem1.Text = "Add Keywords";
		this.addKeywordsToolStripMenuItem1.Click += new System.EventHandler(addKeywordsToolStripMenuItem1_Click);
		this.spamWordsToolStripMenuItem1.Image = (System.Drawing.Image)resources.GetObject("spamWordsToolStripMenuItem1.Image");
		this.spamWordsToolStripMenuItem1.Name = "spamWordsToolStripMenuItem1";
		this.spamWordsToolStripMenuItem1.Size = new System.Drawing.Size(176, 22);
		this.spamWordsToolStripMenuItem1.Text = "Spam Words";
		this.spamWordsToolStripMenuItem1.Click += new System.EventHandler(spamWordsToolStripMenuItem1_Click);
		this.bluckToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("bluckToolStripMenuItem.Image");
		this.bluckToolStripMenuItem.Name = "bluckToolStripMenuItem";
		this.bluckToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
		this.bluckToolStripMenuItem.Text = "Bulk SMTP Checker";
		this.bluckToolStripMenuItem.Click += new System.EventHandler(bluckToolStripMenuItem_Click);
		this.iMAPAccountsToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("iMAPAccountsToolStripMenuItem.Image");
		this.iMAPAccountsToolStripMenuItem.Name = "iMAPAccountsToolStripMenuItem";
		this.iMAPAccountsToolStripMenuItem.Size = new System.Drawing.Size(121, 24);
		this.iMAPAccountsToolStripMenuItem.Text = "IMAP Accounts";
		this.iMAPAccountsToolStripMenuItem.Click += new System.EventHandler(iMAPAccountsToolStripMenuItem_Click);
		this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.aboutMeToolStripMenuItem, this.registerToolStripMenuItem });
		this.aboutToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("aboutToolStripMenuItem.Image");
		this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
		this.aboutToolStripMenuItem.Size = new System.Drawing.Size(72, 24);
		this.aboutToolStripMenuItem.Text = "About";
		this.aboutMeToolStripMenuItem.Name = "aboutMeToolStripMenuItem";
		this.aboutMeToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
		this.aboutMeToolStripMenuItem.Text = "About Me";
		this.aboutMeToolStripMenuItem.Click += new System.EventHandler(aboutMeToolStripMenuItem_Click);
		this.registerToolStripMenuItem.Name = "registerToolStripMenuItem";
		this.registerToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
		this.registerToolStripMenuItem.Text = "Register";
		this.registerToolStripMenuItem.Click += new System.EventHandler(registerToolStripMenuItem_Click);
		this.feedbackToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("feedbackToolStripMenuItem.Image");
		this.feedbackToolStripMenuItem.Name = "feedbackToolStripMenuItem";
		this.feedbackToolStripMenuItem.Size = new System.Drawing.Size(89, 24);
		this.feedbackToolStripMenuItem.Text = "Feedback";
		this.feedbackToolStripMenuItem.Click += new System.EventHandler(feedbackToolStripMenuItem_Click);
		this.groupBox1.AutoSize = true;
		this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
		this.groupBox1.Controls.Add(this.groupBox9);
		this.groupBox1.Controls.Add(this.groupBox5);
		this.groupBox1.Controls.Add(this.groupBox4);
		this.groupBox1.Controls.Add(this.groupBox2);
		this.groupBox1.Location = new System.Drawing.Point(12, 54);
		this.groupBox1.MinimumSize = new System.Drawing.Size(3, 3);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(977, 553);
		this.groupBox1.TabIndex = 1;
		this.groupBox1.TabStop = false;
		this.groupBox9.BackColor = System.Drawing.SystemColors.Control;
		this.groupBox9.Controls.Add(this.chkFastSending);
		this.groupBox9.Controls.Add(this.ctrlMailPriority);
		this.groupBox9.Controls.Add(this.btnStart);
		this.groupBox9.Controls.Add(this.btnStop);
		this.groupBox9.Controls.Add(this.ctrlFailedNum);
		this.groupBox9.Controls.Add(this.ctrlSleepNum);
		this.groupBox9.Controls.Add(this.ctrlPauseNum);
		this.groupBox9.Controls.Add(this.chkRetryFailed);
		this.groupBox9.Controls.Add(this.label7);
		this.groupBox9.Controls.Add(this.label6);
		this.groupBox9.Controls.Add(this.label5);
		this.groupBox9.Controls.Add(this.ctrlConNum);
		this.groupBox9.Controls.Add(this.label4);
		this.groupBox9.Controls.Add(this.groupBox10);
		this.groupBox9.Controls.Add(this.groupBox12);
		this.groupBox9.Location = new System.Drawing.Point(802, 292);
		this.groupBox9.Name = "groupBox9";
		this.groupBox9.Size = new System.Drawing.Size(169, 242);
		this.groupBox9.TabIndex = 5;
		this.groupBox9.TabStop = false;
		this.groupBox9.Text = "Start Send";
		this.groupBox9.Enter += new System.EventHandler(groupBox9_Enter);
		this.chkFastSending.AutoSize = true;
		this.chkFastSending.Location = new System.Drawing.Point(14, 170);
		this.chkFastSending.Name = "chkFastSending";
		this.chkFastSending.Size = new System.Drawing.Size(88, 17);
		this.chkFastSending.TabIndex = 17;
		this.chkFastSending.Text = "Fast Sending";
		this.chkFastSending.UseVisualStyleBackColor = true;
		this.ctrlMailPriority.DisplayMember = "None";
		this.ctrlMailPriority.FormattingEnabled = true;
		this.ctrlMailPriority.Items.AddRange(new object[4] { "None", "Low", "Normal", "High" });
		this.ctrlMailPriority.Location = new System.Drawing.Point(102, 110);
		this.ctrlMailPriority.Name = "ctrlMailPriority";
		this.ctrlMailPriority.Size = new System.Drawing.Size(61, 21);
		this.ctrlMailPriority.TabIndex = 16;
		this.ctrlMailPriority.Text = "High";
		this.btnStart.Image = (System.Drawing.Image)resources.GetObject("btnStart.Image");
		this.btnStart.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnStart.Location = new System.Drawing.Point(102, 198);
		this.btnStart.Name = "btnStart";
		this.btnStart.Size = new System.Drawing.Size(61, 34);
		this.btnStart.TabIndex = 15;
		this.btnStart.Text = "    Start";
		this.btnStart.UseVisualStyleBackColor = true;
		this.btnStart.Click += new System.EventHandler(btnStart_Click);
		this.btnStop.Image = (System.Drawing.Image)resources.GetObject("btnStop.Image");
		this.btnStop.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnStop.Location = new System.Drawing.Point(14, 198);
		this.btnStop.Name = "btnStop";
		this.btnStop.Size = new System.Drawing.Size(68, 34);
		this.btnStop.TabIndex = 14;
		this.btnStop.Text = "   Stop";
		this.btnStop.UseVisualStyleBackColor = true;
		this.btnStop.Click += new System.EventHandler(btnStop_Click);
		this.ctrlFailedNum.Location = new System.Drawing.Point(102, 142);
		this.ctrlFailedNum.Name = "ctrlFailedNum";
		this.ctrlFailedNum.Size = new System.Drawing.Size(61, 20);
		this.ctrlFailedNum.TabIndex = 13;
		this.ctrlSleepNum.Location = new System.Drawing.Point(102, 80);
		this.ctrlSleepNum.Name = "ctrlSleepNum";
		this.ctrlSleepNum.Size = new System.Drawing.Size(61, 20);
		this.ctrlSleepNum.TabIndex = 12;
		this.ctrlPauseNum.Location = new System.Drawing.Point(102, 51);
		this.ctrlPauseNum.Name = "ctrlPauseNum";
		this.ctrlPauseNum.Size = new System.Drawing.Size(61, 20);
		this.ctrlPauseNum.TabIndex = 11;
		this.chkRetryFailed.AutoSize = true;
		this.chkRetryFailed.Location = new System.Drawing.Point(15, 144);
		this.chkRetryFailed.Name = "chkRetryFailed";
		this.chkRetryFailed.Size = new System.Drawing.Size(79, 17);
		this.chkRetryFailed.TabIndex = 10;
		this.chkRetryFailed.Text = "Rety Failed";
		this.chkRetryFailed.UseVisualStyleBackColor = true;
		this.label7.AutoSize = true;
		this.label7.Location = new System.Drawing.Point(12, 113);
		this.label7.Name = "label7";
		this.label7.Size = new System.Drawing.Size(78, 13);
		this.label7.TabIndex = 9;
		this.label7.Text = "Mail Priority     :";
		this.label6.AutoSize = true;
		this.label6.Location = new System.Drawing.Point(11, 82);
		this.label6.Name = "label6";
		this.label6.Size = new System.Drawing.Size(79, 13);
		this.label6.TabIndex = 8;
		this.label6.Text = "Long Sleep     :";
		this.label5.AutoSize = true;
		this.label5.Location = new System.Drawing.Point(11, 53);
		this.label5.Name = "label5";
		this.label5.Size = new System.Drawing.Size(79, 13);
		this.label5.TabIndex = 7;
		this.label5.Text = "Pause Every   :";
		this.ctrlConNum.Location = new System.Drawing.Point(102, 22);
		this.ctrlConNum.Maximum = new decimal(new int[4] { 30, 0, 0, 0 });
		this.ctrlConNum.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.ctrlConNum.Name = "ctrlConNum";
		this.ctrlConNum.Size = new System.Drawing.Size(61, 20);
		this.ctrlConNum.TabIndex = 6;
		this.ctrlConNum.Value = new decimal(new int[4] { 1, 0, 0, 0 });
		this.label4.AutoSize = true;
		this.label4.Location = new System.Drawing.Point(11, 24);
		this.label4.Name = "label4";
		this.label4.Size = new System.Drawing.Size(79, 13);
		this.label4.TabIndex = 5;
		this.label4.Text = "Connection     :";
		this.groupBox10.Controls.Add(this.groupBox11);
		this.groupBox10.Location = new System.Drawing.Point(525, 0);
		this.groupBox10.Name = "groupBox10";
		this.groupBox10.Size = new System.Drawing.Size(169, 242);
		this.groupBox10.TabIndex = 4;
		this.groupBox10.TabStop = false;
		this.groupBox10.Text = "Letter";
		this.groupBox11.Location = new System.Drawing.Point(525, 0);
		this.groupBox11.Name = "groupBox11";
		this.groupBox11.Size = new System.Drawing.Size(169, 242);
		this.groupBox11.TabIndex = 3;
		this.groupBox11.TabStop = false;
		this.groupBox11.Text = "Letter";
		this.groupBox12.Location = new System.Drawing.Point(525, 0);
		this.groupBox12.Name = "groupBox12";
		this.groupBox12.Size = new System.Drawing.Size(169, 242);
		this.groupBox12.TabIndex = 3;
		this.groupBox12.TabStop = false;
		this.groupBox12.Text = "Letter";
		this.groupBox5.BackColor = System.Drawing.SystemColors.Control;
		this.groupBox5.Controls.Add(this.btnEdit);
		this.groupBox5.Controls.Add(this.gridLetter);
		this.groupBox5.Controls.Add(this.btnComposeLetter);
		this.groupBox5.Controls.Add(this.btnAttachment);
		this.groupBox5.Controls.Add(this.btnClr);
		this.groupBox5.Location = new System.Drawing.Point(15, 292);
		this.groupBox5.Name = "groupBox5";
		this.groupBox5.Size = new System.Drawing.Size(781, 242);
		this.groupBox5.TabIndex = 2;
		this.groupBox5.TabStop = false;
		this.gridLetter.AllowUserToAddRows = false;
		this.gridLetter.AllowUserToDeleteRows = false;
		this.gridLetter.AllowUserToResizeColumns = false;
		this.gridLetter.AllowUserToResizeRows = false;
		dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
		dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
		dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
		dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Control;
		dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
		dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
		this.gridLetter.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
		this.gridLetter.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.gridLetter.Columns.AddRange(this.Column1, this.Column2, this.Column3, this.Column4, this.Column5, this.Column6);
		this.gridLetter.Location = new System.Drawing.Point(7, 12);
		this.gridLetter.Name = "gridLetter";
		this.gridLetter.RowHeadersVisible = false;
		this.gridLetter.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
		this.gridLetter.Size = new System.Drawing.Size(768, 191);
		this.gridLetter.TabIndex = 23;
		this.gridLetter.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(gridLetter_CellMouseUp);
		this.gridLetter.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(gridLetter_CellValueChanged);
		this.Column1.HeaderText = "From Name";
		this.Column1.Name = "Column1";
		this.Column1.Width = 130;
		this.Column2.HeaderText = "From Email";
		this.Column2.Name = "Column2";
		this.Column2.Width = 130;
		this.Column3.HeaderText = "Subject";
		this.Column3.Name = "Column3";
		this.Column3.Width = 130;
		this.Column4.HeaderText = "Letter Name";
		this.Column4.Name = "Column4";
		this.Column4.Width = 130;
		this.Column5.HeaderText = "Letter Attachment";
		this.Column5.Name = "Column5";
		this.Column5.Width = 150;
		this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
		this.Column6.HeaderText = "Enable";
		this.Column6.Name = "Column6";
		this.btnComposeLetter.Image = (System.Drawing.Image)resources.GetObject("btnComposeLetter.Image");
		this.btnComposeLetter.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnComposeLetter.Location = new System.Drawing.Point(252, 209);
		this.btnComposeLetter.Name = "btnComposeLetter";
		this.btnComposeLetter.Size = new System.Drawing.Size(136, 28);
		this.btnComposeLetter.TabIndex = 22;
		this.btnComposeLetter.Text = "Compose Letter";
		this.btnComposeLetter.UseVisualStyleBackColor = true;
		this.btnComposeLetter.Click += new System.EventHandler(btnComposeLetter_Click_1);
		this.btnAttachment.Image = (System.Drawing.Image)resources.GetObject("btnAttachment.Image");
		this.btnAttachment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnAttachment.Location = new System.Drawing.Point(110, 209);
		this.btnAttachment.Name = "btnAttachment";
		this.btnAttachment.Size = new System.Drawing.Size(138, 28);
		this.btnAttachment.TabIndex = 21;
		this.btnAttachment.Text = "Remove Selected";
		this.btnAttachment.UseVisualStyleBackColor = true;
		this.btnAttachment.Click += new System.EventHandler(btnAttachment_Click_1);
		this.btnClr.Image = (System.Drawing.Image)resources.GetObject("btnClr.Image");
		this.btnClr.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnClr.Location = new System.Drawing.Point(533, 209);
		this.btnClr.Name = "btnClr";
		this.btnClr.Size = new System.Drawing.Size(137, 28);
		this.btnClr.TabIndex = 20;
		this.btnClr.Text = "Clear All";
		this.btnClr.UseVisualStyleBackColor = true;
		this.btnClr.Click += new System.EventHandler(btnClr_Click);
		this.groupBox4.BackColor = System.Drawing.SystemColors.Control;
		this.groupBox4.Controls.Add(this.btnIMAPList);
		this.groupBox4.Controls.Add(this.btnLoad);
		this.groupBox4.Controls.Add(this.btnClear);
		this.groupBox4.Controls.Add(this.btnEmailAdd);
		this.groupBox4.Controls.Add(this.lblTotalEmails);
		this.groupBox4.Controls.Add(this.label2);
		this.groupBox4.Controls.Add(this.gridEmailList);
		this.groupBox4.Location = new System.Drawing.Point(268, 12);
		this.groupBox4.Name = "groupBox4";
		this.groupBox4.Size = new System.Drawing.Size(703, 274);
		this.groupBox4.TabIndex = 1;
		this.groupBox4.TabStop = false;
		this.groupBox4.Text = "Email List";
		this.btnIMAPList.Image = (System.Drawing.Image)resources.GetObject("btnIMAPList.Image");
		this.btnIMAPList.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnIMAPList.Location = new System.Drawing.Point(274, 13);
		this.btnIMAPList.Name = "btnIMAPList";
		this.btnIMAPList.Size = new System.Drawing.Size(128, 34);
		this.btnIMAPList.TabIndex = 69;
		this.btnIMAPList.Text = "Enable IMAP List";
		this.btnIMAPList.UseVisualStyleBackColor = true;
		this.btnIMAPList.Click += new System.EventHandler(btnIMAPList_Click);
		this.btnLoad.Image = (System.Drawing.Image)resources.GetObject("btnLoad.Image");
		this.btnLoad.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnLoad.Location = new System.Drawing.Point(408, 13);
		this.btnLoad.Name = "btnLoad";
		this.btnLoad.Size = new System.Drawing.Size(128, 34);
		this.btnLoad.TabIndex = 68;
		this.btnLoad.Text = "Load From File";
		this.btnLoad.UseVisualStyleBackColor = true;
		this.btnLoad.Click += new System.EventHandler(btnLoad_Click);
		this.btnClear.Image = (System.Drawing.Image)resources.GetObject("btnClear.Image");
		this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnClear.Location = new System.Drawing.Point(541, 13);
		this.btnClear.Name = "btnClear";
		this.btnClear.Size = new System.Drawing.Size(75, 34);
		this.btnClear.TabIndex = 4;
		this.btnClear.Text = "Clear";
		this.btnClear.UseVisualStyleBackColor = true;
		this.btnClear.Click += new System.EventHandler(btnClear_Click);
		this.btnEmailAdd.Image = (System.Drawing.Image)resources.GetObject("btnEmailAdd.Image");
		this.btnEmailAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnEmailAdd.Location = new System.Drawing.Point(622, 13);
		this.btnEmailAdd.Name = "btnEmailAdd";
		this.btnEmailAdd.Size = new System.Drawing.Size(75, 34);
		this.btnEmailAdd.TabIndex = 3;
		this.btnEmailAdd.Text = "Add";
		this.btnEmailAdd.UseVisualStyleBackColor = true;
		this.btnEmailAdd.Click += new System.EventHandler(btnEmailAdd_Click);
		this.lblTotalEmails.AutoSize = true;
		this.lblTotalEmails.Location = new System.Drawing.Point(80, 28);
		this.lblTotalEmails.Name = "lblTotalEmails";
		this.lblTotalEmails.Size = new System.Drawing.Size(13, 13);
		this.lblTotalEmails.TabIndex = 2;
		this.lblTotalEmails.Text = "0";
		this.label2.AutoSize = true;
		this.label2.Location = new System.Drawing.Point(6, 28);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(67, 13);
		this.label2.TabIndex = 1;
		this.label2.Text = "Total Emails:";
		this.gridEmailList.AllowUserToAddRows = false;
		this.gridEmailList.AllowUserToDeleteRows = false;
		this.gridEmailList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.gridEmailList.Columns.AddRange(this.No, this.first_name, this.last_name, this.email, this.status, this.Info);
		this.gridEmailList.Location = new System.Drawing.Point(6, 55);
		this.gridEmailList.Name = "gridEmailList";
		this.gridEmailList.RowHeadersWidth = 51;
		this.gridEmailList.Size = new System.Drawing.Size(691, 213);
		this.gridEmailList.TabIndex = 0;
		this.gridEmailList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(gridEmailList_CellContentClick);
		this.No.HeaderText = "No";
		this.No.MinimumWidth = 6;
		this.No.Name = "No";
		this.No.Width = 50;
		this.first_name.HeaderText = "First Name";
		this.first_name.Name = "first_name";
		this.last_name.HeaderText = "Last Name";
		this.last_name.Name = "last_name";
		this.email.HeaderText = "Email";
		this.email.MinimumWidth = 6;
		this.email.Name = "email";
		this.email.Width = 200;
		this.status.HeaderText = "Status";
		this.status.MinimumWidth = 6;
		this.status.Name = "status";
		this.status.Width = 70;
		this.Info.HeaderText = "Info";
		this.Info.MinimumWidth = 6;
		this.Info.Name = "Info";
		this.Info.Width = 400;
		this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
		this.groupBox2.Controls.Add(this.btnSMTPEdit);
		this.groupBox2.Controls.Add(this.gridHostList);
		this.groupBox2.Controls.Add(this.button1);
		this.groupBox2.Controls.Add(this.lblTotalSMTP);
		this.groupBox2.Controls.Add(this.label1);
		this.groupBox2.Location = new System.Drawing.Point(6, 12);
		this.groupBox2.Name = "groupBox2";
		this.groupBox2.Size = new System.Drawing.Size(256, 274);
		this.groupBox2.TabIndex = 0;
		this.groupBox2.TabStop = false;
		this.groupBox2.Text = "SMTP";
		this.btnSMTPEdit.Image = (System.Drawing.Image)resources.GetObject("btnSMTPEdit.Image");
		this.btnSMTPEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnSMTPEdit.Location = new System.Drawing.Point(182, 14);
		this.btnSMTPEdit.Name = "btnSMTPEdit";
		this.btnSMTPEdit.Size = new System.Drawing.Size(71, 34);
		this.btnSMTPEdit.TabIndex = 2;
		this.btnSMTPEdit.Text = "Edit";
		this.btnSMTPEdit.UseVisualStyleBackColor = true;
		this.btnSMTPEdit.Click += new System.EventHandler(btnSMTPEdit_Click);
		this.gridHostList.AllowUserToAddRows = false;
		this.gridHostList.AllowUserToDeleteRows = false;
		this.gridHostList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.gridHostList.Columns.AddRange(this.Host, this.Port, this.Username, this.Password, this.Secure, this.Limit, this.Usage, this.FromEmail);
		this.gridHostList.Location = new System.Drawing.Point(6, 55);
		this.gridHostList.Name = "gridHostList";
		this.gridHostList.RowHeadersWidth = 51;
		this.gridHostList.Size = new System.Drawing.Size(244, 213);
		this.gridHostList.TabIndex = 1;
		this.Host.HeaderText = "Host";
		this.Host.MinimumWidth = 6;
		this.Host.Name = "Host";
		this.Host.Width = 125;
		this.Port.HeaderText = "Port";
		this.Port.MinimumWidth = 6;
		this.Port.Name = "Port";
		this.Port.Width = 125;
		this.Username.HeaderText = "Username";
		this.Username.MinimumWidth = 6;
		this.Username.Name = "Username";
		this.Username.Width = 125;
		this.Password.HeaderText = "Password";
		this.Password.MinimumWidth = 6;
		this.Password.Name = "Password";
		this.Password.Width = 125;
		this.Secure.HeaderText = "Secure";
		this.Secure.MinimumWidth = 6;
		this.Secure.Name = "Secure";
		this.Secure.Width = 125;
		this.Limit.HeaderText = "Limit";
		this.Limit.MinimumWidth = 6;
		this.Limit.Name = "Limit";
		this.Limit.Width = 125;
		this.Usage.HeaderText = "Usage";
		this.Usage.MinimumWidth = 6;
		this.Usage.Name = "Usage";
		this.Usage.Width = 125;
		this.FromEmail.HeaderText = "FromEmail";
		this.FromEmail.Name = "FromEmail";
		this.button1.Image = (System.Drawing.Image)resources.GetObject("button1.Image");
		this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.button1.Location = new System.Drawing.Point(108, 14);
		this.button1.Name = "button1";
		this.button1.Size = new System.Drawing.Size(71, 34);
		this.button1.TabIndex = 0;
		this.button1.Text = "  Import";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += new System.EventHandler(button1_Click);
		this.lblTotalSMTP.AutoSize = true;
		this.lblTotalSMTP.Location = new System.Drawing.Point(73, 28);
		this.lblTotalSMTP.Name = "lblTotalSMTP";
		this.lblTotalSMTP.Size = new System.Drawing.Size(13, 13);
		this.lblTotalSMTP.TabIndex = 1;
		this.lblTotalSMTP.Text = "0";
		this.label1.AutoSize = true;
		this.label1.Location = new System.Drawing.Point(6, 28);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(67, 13);
		this.label1.TabIndex = 0;
		this.label1.Text = "Total SMTP:";
		this.groupBox14.Controls.Add(this.ctrlProgress);
		this.groupBox14.Controls.Add(this.lbProgressStatus);
		this.groupBox14.Location = new System.Drawing.Point(13, 720);
		this.groupBox14.Name = "groupBox14";
		this.groupBox14.Size = new System.Drawing.Size(976, 53);
		this.groupBox14.TabIndex = 3;
		this.groupBox14.TabStop = false;
		this.groupBox14.Text = "Status: Ready";
		this.ctrlProgress.Location = new System.Drawing.Point(270, 12);
		this.ctrlProgress.Name = "ctrlProgress";
		this.ctrlProgress.Size = new System.Drawing.Size(701, 34);
		this.ctrlProgress.TabIndex = 5;
		this.lbProgressStatus.AutoSize = true;
		this.lbProgressStatus.Location = new System.Drawing.Point(7, 24);
		this.lbProgressStatus.Name = "lbProgressStatus";
		this.lbProgressStatus.Size = new System.Drawing.Size(0, 13);
		this.lbProgressStatus.TabIndex = 5;
		this.lblAnnouncement.AutoSize = true;
		this.lblAnnouncement.BackColor = System.Drawing.Color.FromArgb(192, 0, 0);
		this.lblAnnouncement.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.lblAnnouncement.ForeColor = System.Drawing.Color.Yellow;
		this.lblAnnouncement.Location = new System.Drawing.Point(14, 31);
		this.lblAnnouncement.Name = "lblAnnouncement";
		this.lblAnnouncement.Size = new System.Drawing.Size(0, 16);
		this.lblAnnouncement.TabIndex = 4;
		this.label3.AutoSize = true;
		this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
		this.label3.Location = new System.Drawing.Point(823, 36);
		this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(51, 15);
		this.label3.TabIndex = 5;
		this.label3.Text = "Your IP :";
		this.lbIp.AutoSize = true;
		this.lbIp.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.lbIp.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
		this.lbIp.Location = new System.Drawing.Point(876, 36);
		this.lbIp.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
		this.lbIp.Name = "lbIp";
		this.lbIp.Size = new System.Drawing.Size(51, 15);
		this.lbIp.TabIndex = 6;
		this.lbIp.Text = "Your IP :";
		this.groupBox15.Controls.Add(this.txtLogs);
		this.groupBox15.Location = new System.Drawing.Point(15, 648);
		this.groupBox15.Margin = new System.Windows.Forms.Padding(2);
		this.groupBox15.Name = "groupBox15";
		this.groupBox15.Padding = new System.Windows.Forms.Padding(2);
		this.groupBox15.Size = new System.Drawing.Size(974, 67);
		this.groupBox15.TabIndex = 7;
		this.groupBox15.TabStop = false;
		this.txtLogs.BackColor = System.Drawing.Color.Gainsboro;
		this.txtLogs.BorderStyle = System.Windows.Forms.BorderStyle.None;
		this.txtLogs.Location = new System.Drawing.Point(5, 11);
		this.txtLogs.Margin = new System.Windows.Forms.Padding(2);
		this.txtLogs.Name = "txtLogs";
		this.txtLogs.Size = new System.Drawing.Size(964, 50);
		this.txtLogs.TabIndex = 0;
		this.txtLogs.Text = "";
		this.label8.AutoSize = true;
		this.label8.Location = new System.Drawing.Point(14, 635);
		this.label8.Name = "label8";
		this.label8.Size = new System.Drawing.Size(75, 13);
		this.label8.TabIndex = 8;
		this.label8.Text = "Sending Logs:";
		this.btnClearLogs.Image = (System.Drawing.Image)resources.GetObject("btnClearLogs.Image");
		this.btnClearLogs.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnClearLogs.Location = new System.Drawing.Point(879, 614);
		this.btnClearLogs.Name = "btnClearLogs";
		this.btnClearLogs.Size = new System.Drawing.Size(110, 34);
		this.btnClearLogs.TabIndex = 18;
		this.btnClearLogs.Text = "Clear Logs";
		this.btnClearLogs.UseVisualStyleBackColor = true;
		this.btnClearLogs.Click += new System.EventHandler(btnClearLogs_Click);
		this.btnEdit.Image = (System.Drawing.Image)resources.GetObject("btnEdit.Image");
		this.btnEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnEdit.Location = new System.Drawing.Point(392, 209);
		this.btnEdit.Name = "btnEdit";
		this.btnEdit.Size = new System.Drawing.Size(137, 28);
		this.btnEdit.TabIndex = 24;
		this.btnEdit.Text = "Edit Letter";
		this.btnEdit.UseVisualStyleBackColor = true;
		this.btnEdit.Click += new System.EventHandler(btnEdit_Click);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
		base.ClientSize = new System.Drawing.Size(998, 781);
		base.Controls.Add(this.btnClearLogs);
		base.Controls.Add(this.groupBox14);
		base.Controls.Add(this.label8);
		base.Controls.Add(this.groupBox15);
		base.Controls.Add(this.lbIp);
		base.Controls.Add(this.label3);
		base.Controls.Add(this.lblAnnouncement);
		base.Controls.Add(this.menuStrip1);
		base.Controls.Add(this.groupBox1);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.MainMenuStrip = this.menuStrip1;
		base.MaximizeBox = false;
		base.Name = "Main";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "HeartSender";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(Main_Closing);
		base.Load += new System.EventHandler(Main_Load);
		this.menuStrip1.ResumeLayout(false);
		this.menuStrip1.PerformLayout();
		this.groupBox1.ResumeLayout(false);
		this.groupBox9.ResumeLayout(false);
		this.groupBox9.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.ctrlFailedNum).EndInit();
		((System.ComponentModel.ISupportInitialize)this.ctrlSleepNum).EndInit();
		((System.ComponentModel.ISupportInitialize)this.ctrlPauseNum).EndInit();
		((System.ComponentModel.ISupportInitialize)this.ctrlConNum).EndInit();
		this.groupBox10.ResumeLayout(false);
		this.groupBox5.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.gridLetter).EndInit();
		this.groupBox4.ResumeLayout(false);
		this.groupBox4.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.gridEmailList).EndInit();
		this.groupBox2.ResumeLayout(false);
		this.groupBox2.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.gridHostList).EndInit();
		this.groupBox14.ResumeLayout(false);
		this.groupBox14.PerformLayout();
		this.groupBox15.ResumeLayout(false);
		base.ResumeLayout(false);
		base.PerformLayout();
	}
}
