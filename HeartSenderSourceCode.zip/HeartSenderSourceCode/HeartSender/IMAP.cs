using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using CommonSender;
using MailKit.Net.Imap;

namespace HeartSender;

public class IMAP : Form
{
	private BackgroundWorker worker = new BackgroundWorker();

	private Main _main;

	private GxIMAP imap;

	public static bool is_auto_script;

	private int flag;

	private IContainer components;

	private DataGridView gridIMAPEmails;

	private GroupBox groupBox1;

	private Label label2;

	private TextBox txtLimit;

	private NumericUpDown ntbPort;

	private RadioButton radioButton2;

	private RadioButton rbSSL;

	private Label lbImap;

	private Label lbPassword;

	private Label lbUserName;

	private Label lbPort;

	private TextBox txtImap;

	private TextBox txtPassword;

	private TextBox txtUsername;

	public Button btnStart;

	public Button btnStop;

	public Button btnSave;

	private Button btnCheckIP;

	private DataGridView gridIMAPAccounts;

	private Label label1;

	private Button btnAddSMTP;

	private Label label3;

	private DataGridViewTextBoxColumn Email;

	private DataGridViewTextBoxColumn IMAPServer;

	private DataGridViewTextBoxColumn UserName;

	private DataGridViewTextBoxColumn Password;

	private DataGridViewTextBoxColumn Port;

	private DataGridViewTextBoxColumn SSL;

	private DataGridViewTextBoxColumn Limit;

	private Button btnClear;

	private Button btnRemove;

	private Button btnRmDpl;

	private Button btnImport;

	public Button btnClose;

	public IMAP(Main main)
	{
		_main = main;
		imap = new GxIMAP(_main, this);
		InitializeComponent();
	}

	private void btnCheckIP_Click(object sender, EventArgs e)
	{
		using ImapClient c = new ImapClient();
		try
		{
			c.Connect(txtImap.Text, Convert.ToInt16(ntbPort.Value), rbSSL.Checked);
			c.AuthenticationMechanisms.Remove("XOAUTH2");
			c.Authenticate(txtUsername.Text, txtPassword.Text);
			MessageBox.Show("Account Ok!", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		catch (Exception ex)
		{
			MessageBox.Show("hello");
			MessageBox.Show(ex.Message.ToString(), "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	private void btnAddSMTP_Click(object sender, EventArgs e)
	{
		if (txtImap.Text.Trim().Length == 0 || txtUsername.Text.Trim().Length == 0 || txtPassword.Text.Trim().Length == 0)
		{
			MessageBox.Show("Please enter complete detail.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			return;
		}
		GxIMAPAccount account = new GxIMAPAccount();
		account.server_name = txtImap.Text.Trim();
		account.username = txtUsername.Text.Trim();
		account.password = txtPassword.Text.Trim();
		account.limit = int.Parse(txtLimit.Text.Trim());
		account.port = int.Parse(ntbPort.Value.ToString());
		account.is_ssl = rbSSL.Checked;
		Main.imap_accounts.Add(account);
		int index = gridIMAPAccounts.Rows.Add();
		gridIMAPAccounts.Rows[index].Cells["UserName"].Value = account.username;
		gridIMAPAccounts.Rows[index].Cells["Password"].Value = account.password;
		gridIMAPAccounts.Rows[index].Cells["Port"].Value = account.port.ToString();
		gridIMAPAccounts.Rows[index].Cells["Limit"].Value = account.limit.ToString();
		gridIMAPAccounts.Rows[index].Cells["SSL"].Value = (account.is_ssl ? "SSL" : "None");
		gridIMAPAccounts.Rows[index].Cells["IMAPServer"].Value = account.server_name;
	}

	private void btnSave_Click(object sender, EventArgs e)
	{
		if (gridIMAPAccounts.Rows.Count == 0)
		{
			MessageBox.Show("Sorry, no IMAP account(s) added.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			return;
		}
		btnStart.Enabled = false;
		btnStop.Enabled = true;
		btnClear.Enabled = false;
		btnRmDpl.Enabled = false;
		btnRemove.Enabled = false;
		btnSave.Enabled = false;
		btnClose.Enabled = true;
		Main.imap_running = true;
		worker.DoWork += bgw_DoWork;
		worker.ProgressChanged += bgw_ProgressChanged;
		worker.RunWorkerCompleted += bgw_RunWorkerCompleted;
		worker.WorkerReportsProgress = true;
		worker.WorkerSupportsCancellation = true;
		if (!worker.IsBusy)
		{
			worker.RunWorkerAsync();
		}
	}

	public void show_imap()
	{
		base.Visible = true;
		flag = 1;
	}

	private void IMAP_Load(object sender, EventArgs e)
	{
		if (Main.imap_accounts.Count <= 0)
		{
			return;
		}
		int index = 0;
		foreach (GxIMAPAccount imap in Main.imap_accounts)
		{
			index = gridIMAPAccounts.Rows.Add();
			gridIMAPAccounts.Rows[index].Cells["IMAPServer"].Value = imap.server_name;
			gridIMAPAccounts.Rows[index].Cells["Port"].Value = imap.port.ToString();
			gridIMAPAccounts.Rows[index].Cells["Username"].Value = imap.username;
			gridIMAPAccounts.Rows[index].Cells["Password"].Value = imap.password;
			gridIMAPAccounts.Rows[index].Cells["SSL"].Value = (imap.is_ssl ? "SSL" : "None");
			gridIMAPAccounts.Rows[index].Cells["Limit"].Value = imap.limit;
		}
	}

	private void btnClear_Click(object sender, EventArgs e)
	{
		gridIMAPAccounts.Rows.Clear();
	}

	private void btnRemove_Click(object sender, EventArgs e)
	{
		if (gridIMAPAccounts.SelectedRows.Count > 0)
		{
			foreach (DataGridViewRow row in gridIMAPAccounts.SelectedRows)
			{
				gridIMAPAccounts.Rows.RemoveAt(row.Index);
			}
			return;
		}
		MessageBox.Show("Please Select Atleast One Row to Delete.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
	}

	public void btnStart_Click(object sender, EventArgs e)
	{
		if (gridIMAPAccounts.Rows.Count == 0)
		{
			MessageBox.Show("Sorry, no IMAP account(s) added.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			return;
		}
		flag = 2;
		btnStart.Enabled = false;
		btnStop.Enabled = true;
		btnClear.Enabled = false;
		btnRmDpl.Enabled = false;
		btnRemove.Enabled = false;
		btnSave.Enabled = false;
		btnClose.Enabled = true;
		Main.imap_running = true;
		worker.DoWork += bgw_DoWork;
		worker.ProgressChanged += bgw_ProgressChanged;
		worker.RunWorkerCompleted += bgw_RunWorkerCompleted;
		worker.WorkerReportsProgress = true;
		worker.WorkerSupportsCancellation = true;
		if (!worker.IsBusy)
		{
			worker.RunWorkerAsync();
		}
	}

	public void bgw_DoWork(object sender, DoWorkEventArgs e)
	{
		BackgroundWorker worker_job = sender as BackgroundWorker;
		foreach (GxIMAPAccount account in Main.imap_accounts)
		{
			if (worker_job.CancellationPending)
			{
				break;
			}
			getIMAPEmails(account, worker_job, imap);
		}
	}

	public void removeDuplicatesInGrid(GxIMAP imap)
	{
		string[] emails = imap.emails.Distinct().ToList().ToArray();
		Main.emails.Clear();
		gridIMAPEmails.Rows.Clear();
		string[] array = emails;
		foreach (string obj in array)
		{
			Console.WriteLine(obj.Trim().ToLower());
			string formated_email = obj.Replace("\\r\\n", "").Replace("\\r", "").Replace("\\n", "")
				.Trim()
				.ToLower();
			int index = gridIMAPEmails.Rows.Add();
			gridIMAPEmails.Rows[index].Cells["Email"].Value = formated_email;
			Main.emails.Add(formated_email);
		}
		_main.gridEmailList.Rows.Clear();
		Main.populateEmailsList(emails, _main);
	}

	public void getIMAPEmails(GxIMAPAccount account, BackgroundWorker worker, GxIMAP imap)
	{
		imap.execute(account, worker);
	}

	public void bgw_ProgressChanged(object sender, ProgressChangedEventArgs e)
	{
		string email = (string)e.UserState;
		try
		{
			if (!Main.is_imap_form_hide && flag == 0)
			{
				Main.is_imap_form_hide = true;
				Hide();
			}
			else if (!Main.is_imap_form_hide && flag == 1)
			{
				Main.is_imap_form_hide = true;
			}
			int index = gridIMAPEmails.Rows.Add();
			int index2 = _main.gridEmailList.Rows.Add();
			gridIMAPEmails.Rows[index].Cells["Email"].Value = email.Trim().ToLower();
			_main.gridEmailList.Rows[index2].Cells[1].Value = email.Trim().ToLower();
		}
		catch (Exception)
		{
		}
	}

	public void bgw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
	{
		btnStart.Enabled = true;
		btnStop.Enabled = false;
		btnClear.Enabled = true;
		btnRmDpl.Enabled = true;
		btnRemove.Enabled = true;
		btnSave.Enabled = true;
		btnClose.Enabled = true;
		Main.imap_running = false;
		removeDuplicatesInGrid(imap);
		if (!is_auto_script)
		{
			is_auto_script = false;
			if (!e.Cancelled)
			{
				MessageBox.Show("Done", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			if (e.Cancelled)
			{
				MessageBox.Show("Operation was canceled", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}
		else
		{
			is_auto_script = false;
			Close();
			_main.btnStart_Click(sender, e);
		}
	}

	private void btnStop_Click(object sender, EventArgs e)
	{
		worker.CancelAsync();
		btnStop.Enabled = false;
	}

	private void btnRmDpl_Click(object sender, EventArgs e)
	{
		removeDuplicatesInGrid(imap);
	}

	private void IMAP_FormClosing(object sender, FormClosingEventArgs e)
	{
		Main.imap_running = false;
	}

	private void btnImport_Click(object sender, EventArgs e)
	{
		OpenFileDialog file = new OpenFileDialog();
		file.Filter = "txt files (*.txt)|*.txt";
		Stream stream;
		if (file.ShowDialog() == DialogResult.OK && (stream = file.OpenFile()) != null)
		{
			using (StreamReader sr = new StreamReader(stream))
			{
				string[] smtps = sr.ReadToEnd().Split(new string[3] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
				loadIMAPData(smtps);
			}
			stream.Close();
		}
	}

	public void loadIMAPData(string[] data)
	{
		try
		{
			int index = 0;
			Main.imap_accounts.Clear();
			new GxDB();
			foreach (string line in data)
			{
				string[] tokens = line.Split('|');
				if (line.Length >= 5)
				{
					index = gridIMAPAccounts.Rows.Add();
					gridIMAPAccounts.Rows[index].Cells["IMAPServer"].Value = tokens[0];
					gridIMAPAccounts.Rows[index].Cells["UserName"].Value = tokens[1];
					gridIMAPAccounts.Rows[index].Cells["Password"].Value = tokens[2];
					gridIMAPAccounts.Rows[index].Cells["Port"].Value = tokens[3];
					gridIMAPAccounts.Rows[index].Cells["SSL"].Value = tokens[4];
					gridIMAPAccounts.Rows[index].Cells["Limit"].Value = tokens[5];
					GxIMAPAccount account = new GxIMAPAccount();
					account.server_name = gridIMAPAccounts.Rows[index].Cells["IMAPServer"].Value.ToString();
					account.username = gridIMAPAccounts.Rows[index].Cells["UserName"].Value.ToString();
					account.password = gridIMAPAccounts.Rows[index].Cells["Password"].Value.ToString();
					account.limit = int.Parse(gridIMAPAccounts.Rows[index].Cells["Limit"].Value.ToString());
					account.port = int.Parse(gridIMAPAccounts.Rows[index].Cells["Port"].Value.ToString());
					account.is_ssl = ((gridIMAPAccounts.Rows[index].Cells["SSL"].Value.ToString() == "ssl") ? true : false);
					Main.imap_accounts.Add(account);
				}
			}
		}
		catch (Exception)
		{
			MessageBox.Show("Sorry, Invalid file format.");
		}
	}

	private void btnClose_Click(object sender, EventArgs e)
	{
		Main.is_imap_form_hide = true;
		Hide();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.IMAP));
		this.gridIMAPEmails = new System.Windows.Forms.DataGridView();
		this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.btnImport = new System.Windows.Forms.Button();
		this.btnAddSMTP = new System.Windows.Forms.Button();
		this.btnCheckIP = new System.Windows.Forms.Button();
		this.label2 = new System.Windows.Forms.Label();
		this.txtLimit = new System.Windows.Forms.TextBox();
		this.ntbPort = new System.Windows.Forms.NumericUpDown();
		this.radioButton2 = new System.Windows.Forms.RadioButton();
		this.rbSSL = new System.Windows.Forms.RadioButton();
		this.lbImap = new System.Windows.Forms.Label();
		this.lbPassword = new System.Windows.Forms.Label();
		this.lbUserName = new System.Windows.Forms.Label();
		this.lbPort = new System.Windows.Forms.Label();
		this.txtImap = new System.Windows.Forms.TextBox();
		this.txtPassword = new System.Windows.Forms.TextBox();
		this.txtUsername = new System.Windows.Forms.TextBox();
		this.btnStart = new System.Windows.Forms.Button();
		this.btnStop = new System.Windows.Forms.Button();
		this.btnSave = new System.Windows.Forms.Button();
		this.gridIMAPAccounts = new System.Windows.Forms.DataGridView();
		this.IMAPServer = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.UserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Port = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.SSL = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Limit = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.label1 = new System.Windows.Forms.Label();
		this.label3 = new System.Windows.Forms.Label();
		this.btnClear = new System.Windows.Forms.Button();
		this.btnRemove = new System.Windows.Forms.Button();
		this.btnRmDpl = new System.Windows.Forms.Button();
		this.btnClose = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)this.gridIMAPEmails).BeginInit();
		this.groupBox1.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.ntbPort).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.gridIMAPAccounts).BeginInit();
		base.SuspendLayout();
		this.gridIMAPEmails.AllowUserToAddRows = false;
		this.gridIMAPEmails.AllowUserToDeleteRows = false;
		this.gridIMAPEmails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.gridIMAPEmails.Columns.AddRange(this.Email);
		this.gridIMAPEmails.Location = new System.Drawing.Point(7, 42);
		this.gridIMAPEmails.Margin = new System.Windows.Forms.Padding(4);
		this.gridIMAPEmails.Name = "gridIMAPEmails";
		this.gridIMAPEmails.RowHeadersWidth = 51;
		this.gridIMAPEmails.Size = new System.Drawing.Size(393, 438);
		this.gridIMAPEmails.TabIndex = 0;
		this.Email.HeaderText = "Email";
		this.Email.MinimumWidth = 6;
		this.Email.Name = "Email";
		this.Email.Width = 250;
		this.groupBox1.Controls.Add(this.btnImport);
		this.groupBox1.Controls.Add(this.btnAddSMTP);
		this.groupBox1.Controls.Add(this.btnCheckIP);
		this.groupBox1.Controls.Add(this.label2);
		this.groupBox1.Controls.Add(this.txtLimit);
		this.groupBox1.Controls.Add(this.ntbPort);
		this.groupBox1.Controls.Add(this.radioButton2);
		this.groupBox1.Controls.Add(this.rbSSL);
		this.groupBox1.Controls.Add(this.lbImap);
		this.groupBox1.Controls.Add(this.lbPassword);
		this.groupBox1.Controls.Add(this.lbUserName);
		this.groupBox1.Controls.Add(this.lbPort);
		this.groupBox1.Controls.Add(this.txtImap);
		this.groupBox1.Controls.Add(this.txtPassword);
		this.groupBox1.Controls.Add(this.txtUsername);
		this.groupBox1.Location = new System.Drawing.Point(408, 5);
		this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
		this.groupBox1.Size = new System.Drawing.Size(677, 206);
		this.groupBox1.TabIndex = 4;
		this.groupBox1.TabStop = false;
		this.btnImport.Image = (System.Drawing.Image)resources.GetObject("btnImport.Image");
		this.btnImport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnImport.Location = new System.Drawing.Point(349, 159);
		this.btnImport.Margin = new System.Windows.Forms.Padding(4);
		this.btnImport.Name = "btnImport";
		this.btnImport.Size = new System.Drawing.Size(100, 41);
		this.btnImport.TabIndex = 87;
		this.btnImport.Text = "Import";
		this.btnImport.UseVisualStyleBackColor = true;
		this.btnImport.Click += new System.EventHandler(btnImport_Click);
		this.btnAddSMTP.Image = (System.Drawing.Image)resources.GetObject("btnAddSMTP.Image");
		this.btnAddSMTP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnAddSMTP.Location = new System.Drawing.Point(239, 159);
		this.btnAddSMTP.Margin = new System.Windows.Forms.Padding(4);
		this.btnAddSMTP.Name = "btnAddSMTP";
		this.btnAddSMTP.Size = new System.Drawing.Size(103, 41);
		this.btnAddSMTP.TabIndex = 86;
		this.btnAddSMTP.Text = "Add";
		this.btnAddSMTP.UseVisualStyleBackColor = true;
		this.btnAddSMTP.Click += new System.EventHandler(btnAddSMTP_Click);
		this.btnCheckIP.Image = (System.Drawing.Image)resources.GetObject("btnCheckIP.Image");
		this.btnCheckIP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnCheckIP.Location = new System.Drawing.Point(131, 159);
		this.btnCheckIP.Margin = new System.Windows.Forms.Padding(4);
		this.btnCheckIP.Name = "btnCheckIP";
		this.btnCheckIP.Size = new System.Drawing.Size(100, 41);
		this.btnCheckIP.TabIndex = 84;
		this.btnCheckIP.Text = "   Check";
		this.btnCheckIP.UseVisualStyleBackColor = true;
		this.btnCheckIP.Click += new System.EventHandler(btnCheckIP_Click);
		this.label2.AutoSize = true;
		this.label2.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.label2.Location = new System.Drawing.Point(339, 85);
		this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(48, 18);
		this.label2.TabIndex = 77;
		this.label2.Text = "Limit :";
		this.txtLimit.BackColor = System.Drawing.Color.FromArgb(246, 248, 249);
		this.txtLimit.Font = new System.Drawing.Font("Microsoft JhengHei", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtLimit.ForeColor = System.Drawing.Color.FromArgb(68, 77, 101);
		this.txtLimit.Location = new System.Drawing.Point(431, 80);
		this.txtLimit.Margin = new System.Windows.Forms.Padding(4);
		this.txtLimit.Name = "txtLimit";
		this.txtLimit.Size = new System.Drawing.Size(237, 32);
		this.txtLimit.TabIndex = 76;
		this.txtLimit.Text = "0";
		this.ntbPort.BackColor = System.Drawing.Color.FromArgb(246, 248, 249);
		this.ntbPort.Font = new System.Drawing.Font("Microsoft JhengHei", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.ntbPort.Location = new System.Drawing.Point(132, 81);
		this.ntbPort.Margin = new System.Windows.Forms.Padding(4);
		this.ntbPort.Maximum = new decimal(new int[4] { 9999999, 0, 0, 0 });
		this.ntbPort.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.ntbPort.Name = "ntbPort";
		this.ntbPort.Size = new System.Drawing.Size(196, 27);
		this.ntbPort.TabIndex = 75;
		this.ntbPort.Value = new decimal(new int[4] { 993, 0, 0, 0 });
		this.radioButton2.AutoSize = true;
		this.radioButton2.Location = new System.Drawing.Point(80, 0);
		this.radioButton2.Margin = new System.Windows.Forms.Padding(4);
		this.radioButton2.Name = "radioButton2";
		this.radioButton2.Size = new System.Drawing.Size(63, 21);
		this.radioButton2.TabIndex = 54;
		this.radioButton2.Text = "None";
		this.radioButton2.UseVisualStyleBackColor = true;
		this.rbSSL.AutoSize = true;
		this.rbSSL.Checked = true;
		this.rbSSL.Location = new System.Drawing.Point(12, 0);
		this.rbSSL.Margin = new System.Windows.Forms.Padding(4);
		this.rbSSL.Name = "rbSSL";
		this.rbSSL.Size = new System.Drawing.Size(55, 21);
		this.rbSSL.TabIndex = 53;
		this.rbSSL.TabStop = true;
		this.rbSSL.Text = "SSL";
		this.rbSSL.UseVisualStyleBackColor = true;
		this.lbImap.AutoSize = true;
		this.lbImap.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.lbImap.Location = new System.Drawing.Point(16, 126);
		this.lbImap.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lbImap.Name = "lbImap";
		this.lbImap.Size = new System.Drawing.Size(96, 18);
		this.lbImap.TabIndex = 48;
		this.lbImap.Text = "IMAP Server :";
		this.lbPassword.AutoSize = true;
		this.lbPassword.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.lbPassword.Location = new System.Drawing.Point(339, 41);
		this.lbPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lbPassword.Name = "lbPassword";
		this.lbPassword.Size = new System.Drawing.Size(77, 18);
		this.lbPassword.TabIndex = 50;
		this.lbPassword.Text = "Password :";
		this.lbUserName.AutoSize = true;
		this.lbUserName.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.lbUserName.Location = new System.Drawing.Point(15, 41);
		this.lbUserName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lbUserName.Name = "lbUserName";
		this.lbUserName.Size = new System.Drawing.Size(88, 18);
		this.lbUserName.TabIndex = 49;
		this.lbUserName.Text = "User Name :";
		this.lbPort.AutoSize = true;
		this.lbPort.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.lbPort.Location = new System.Drawing.Point(15, 85);
		this.lbPort.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lbPort.Name = "lbPort";
		this.lbPort.Size = new System.Drawing.Size(42, 18);
		this.lbPort.TabIndex = 47;
		this.lbPort.Text = "Port :";
		this.txtImap.BackColor = System.Drawing.Color.FromArgb(246, 248, 249);
		this.txtImap.Font = new System.Drawing.Font("Microsoft JhengHei", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtImap.ForeColor = System.Drawing.Color.FromArgb(68, 77, 101);
		this.txtImap.Location = new System.Drawing.Point(132, 119);
		this.txtImap.Margin = new System.Windows.Forms.Padding(4);
		this.txtImap.Name = "txtImap";
		this.txtImap.Size = new System.Drawing.Size(536, 32);
		this.txtImap.TabIndex = 44;
		this.txtPassword.BackColor = System.Drawing.Color.FromArgb(246, 248, 249);
		this.txtPassword.Font = new System.Drawing.Font("Microsoft JhengHei", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtPassword.ForeColor = System.Drawing.Color.FromArgb(68, 77, 101);
		this.txtPassword.Location = new System.Drawing.Point(431, 37);
		this.txtPassword.Margin = new System.Windows.Forms.Padding(4);
		this.txtPassword.Name = "txtPassword";
		this.txtPassword.PasswordChar = '*';
		this.txtPassword.Size = new System.Drawing.Size(237, 32);
		this.txtPassword.TabIndex = 46;
		this.txtUsername.BackColor = System.Drawing.Color.FromArgb(246, 248, 249);
		this.txtUsername.Font = new System.Drawing.Font("Microsoft JhengHei", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtUsername.ForeColor = System.Drawing.Color.FromArgb(68, 77, 101);
		this.txtUsername.Location = new System.Drawing.Point(132, 37);
		this.txtUsername.Margin = new System.Windows.Forms.Padding(4);
		this.txtUsername.Name = "txtUsername";
		this.txtUsername.Size = new System.Drawing.Size(195, 32);
		this.txtUsername.TabIndex = 45;
		this.btnStart.Image = (System.Drawing.Image)resources.GetObject("btnStart.Image");
		this.btnStart.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnStart.Location = new System.Drawing.Point(7, 484);
		this.btnStart.Margin = new System.Windows.Forms.Padding(4);
		this.btnStart.Name = "btnStart";
		this.btnStart.Size = new System.Drawing.Size(111, 42);
		this.btnStart.TabIndex = 82;
		this.btnStart.Text = "    Start";
		this.btnStart.UseVisualStyleBackColor = true;
		this.btnStart.Click += new System.EventHandler(btnStart_Click);
		this.btnStop.Enabled = false;
		this.btnStop.Image = (System.Drawing.Image)resources.GetObject("btnStop.Image");
		this.btnStop.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnStop.Location = new System.Drawing.Point(127, 484);
		this.btnStop.Margin = new System.Windows.Forms.Padding(4);
		this.btnStop.Name = "btnStop";
		this.btnStop.Size = new System.Drawing.Size(113, 42);
		this.btnStop.TabIndex = 81;
		this.btnStop.Text = "   Stop";
		this.btnStop.UseVisualStyleBackColor = true;
		this.btnStop.Click += new System.EventHandler(btnStop_Click);
		this.btnSave.Image = (System.Drawing.Image)resources.GetObject("btnSave.Image");
		this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnSave.Location = new System.Drawing.Point(968, 484);
		this.btnSave.Margin = new System.Windows.Forms.Padding(4);
		this.btnSave.Name = "btnSave";
		this.btnSave.Size = new System.Drawing.Size(117, 42);
		this.btnSave.TabIndex = 83;
		this.btnSave.Text = "Save";
		this.btnSave.UseVisualStyleBackColor = true;
		this.btnSave.Click += new System.EventHandler(btnSave_Click);
		this.gridIMAPAccounts.AllowUserToAddRows = false;
		this.gridIMAPAccounts.AllowUserToDeleteRows = false;
		this.gridIMAPAccounts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.gridIMAPAccounts.Columns.AddRange(this.IMAPServer, this.UserName, this.Password, this.Port, this.SSL, this.Limit);
		this.gridIMAPAccounts.Location = new System.Drawing.Point(408, 241);
		this.gridIMAPAccounts.Margin = new System.Windows.Forms.Padding(4);
		this.gridIMAPAccounts.Name = "gridIMAPAccounts";
		this.gridIMAPAccounts.RowHeadersWidth = 51;
		this.gridIMAPAccounts.Size = new System.Drawing.Size(677, 239);
		this.gridIMAPAccounts.TabIndex = 84;
		this.IMAPServer.HeaderText = "IMAPServer";
		this.IMAPServer.MinimumWidth = 6;
		this.IMAPServer.Name = "IMAPServer";
		this.IMAPServer.Width = 125;
		this.UserName.HeaderText = "UserName";
		this.UserName.MinimumWidth = 6;
		this.UserName.Name = "UserName";
		this.UserName.Width = 125;
		this.Password.HeaderText = "Password";
		this.Password.MinimumWidth = 6;
		this.Password.Name = "Password";
		this.Password.Width = 125;
		this.Port.HeaderText = "Port";
		this.Port.MinimumWidth = 6;
		this.Port.Name = "Port";
		this.Port.Width = 125;
		this.SSL.HeaderText = "SSL";
		this.SSL.MinimumWidth = 6;
		this.SSL.Name = "SSL";
		this.SSL.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.SSL.Width = 125;
		this.Limit.HeaderText = "Limit";
		this.Limit.MinimumWidth = 6;
		this.Limit.Name = "Limit";
		this.Limit.Width = 125;
		this.label1.AutoSize = true;
		this.label1.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.label1.ForeColor = System.Drawing.Color.FromArgb(64, 64, 64);
		this.label1.Location = new System.Drawing.Point(407, 218);
		this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(143, 18);
		this.label1.TabIndex = 85;
		this.label1.Text = "IMAP Accounts List:";
		this.label3.AutoSize = true;
		this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.label3.ForeColor = System.Drawing.Color.FromArgb(64, 64, 64);
		this.label3.Location = new System.Drawing.Point(7, 14);
		this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(291, 18);
		this.label3.TabIndex = 86;
		this.label3.Text = "Email List Extracted From IMAP Accounts:";
		this.btnClear.Image = (System.Drawing.Image)resources.GetObject("btnClear.Image");
		this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnClear.Location = new System.Drawing.Point(407, 484);
		this.btnClear.Margin = new System.Windows.Forms.Padding(4);
		this.btnClear.Name = "btnClear";
		this.btnClear.Size = new System.Drawing.Size(120, 42);
		this.btnClear.TabIndex = 88;
		this.btnClear.Text = "Clear";
		this.btnClear.UseVisualStyleBackColor = true;
		this.btnClear.Click += new System.EventHandler(btnClear_Click);
		this.btnRemove.Image = (System.Drawing.Image)resources.GetObject("btnRemove.Image");
		this.btnRemove.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnRemove.Location = new System.Drawing.Point(539, 484);
		this.btnRemove.Margin = new System.Windows.Forms.Padding(4);
		this.btnRemove.Name = "btnRemove";
		this.btnRemove.Size = new System.Drawing.Size(136, 42);
		this.btnRemove.TabIndex = 87;
		this.btnRemove.Text = "  Remove Row";
		this.btnRemove.UseVisualStyleBackColor = true;
		this.btnRemove.Click += new System.EventHandler(btnRemove_Click);
		this.btnRmDpl.Image = (System.Drawing.Image)resources.GetObject("btnRmDpl.Image");
		this.btnRmDpl.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnRmDpl.Location = new System.Drawing.Point(295, 484);
		this.btnRmDpl.Margin = new System.Windows.Forms.Padding(4);
		this.btnRmDpl.Name = "btnRmDpl";
		this.btnRmDpl.Size = new System.Drawing.Size(105, 42);
		this.btnRmDpl.TabIndex = 89;
		this.btnRmDpl.Text = "  Rm Dpl";
		this.btnRmDpl.UseVisualStyleBackColor = true;
		this.btnRmDpl.Click += new System.EventHandler(btnRmDpl_Click);
		this.btnClose.Image = (System.Drawing.Image)resources.GetObject("btnClose.Image");
		this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnClose.Location = new System.Drawing.Point(846, 484);
		this.btnClose.Margin = new System.Windows.Forms.Padding(4);
		this.btnClose.Name = "btnClose";
		this.btnClose.Size = new System.Drawing.Size(117, 42);
		this.btnClose.TabIndex = 90;
		this.btnClose.Text = "hide";
		this.btnClose.UseVisualStyleBackColor = true;
		this.btnClose.Click += new System.EventHandler(btnClose_Click);
		base.AutoScaleDimensions = new System.Drawing.SizeF(8f, 16f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(1092, 530);
		base.Controls.Add(this.btnClose);
		base.Controls.Add(this.btnRmDpl);
		base.Controls.Add(this.btnClear);
		base.Controls.Add(this.btnRemove);
		base.Controls.Add(this.label3);
		base.Controls.Add(this.label1);
		base.Controls.Add(this.gridIMAPAccounts);
		base.Controls.Add(this.btnSave);
		base.Controls.Add(this.btnStart);
		base.Controls.Add(this.btnStop);
		base.Controls.Add(this.groupBox1);
		base.Controls.Add(this.gridIMAPEmails);
		this.ForeColor = System.Drawing.Color.FromArgb(64, 64, 64);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.Margin = new System.Windows.Forms.Padding(4);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "IMAP";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "IMAP Settings";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(IMAP_FormClosing);
		base.Load += new System.EventHandler(IMAP_Load);
		((System.ComponentModel.ISupportInitialize)this.gridIMAPEmails).EndInit();
		this.groupBox1.ResumeLayout(false);
		this.groupBox1.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.ntbPort).EndInit();
		((System.ComponentModel.ISupportInitialize)this.gridIMAPAccounts).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}
}
