using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace HeartSender;

public class AddKeyword : Form
{
	private Main main;

	private IContainer components;

	private GroupBox groupBox1;

	private RichTextBox txtKeywords;

	private Button btnSave;

	public AddKeyword(Main _main)
	{
		InitializeComponent();
		main = _main;
	}

	private void AddKeyword_Load(object sender, EventArgs e)
	{
		txtKeywords.Text = Main.keywords_list.Trim();
	}

	private void btnSave_Click(object sender, EventArgs e)
	{
		Main.keywords_list = txtKeywords.Text.Trim();
		Close();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.AddKeyword));
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.txtKeywords = new System.Windows.Forms.RichTextBox();
		this.btnSave = new System.Windows.Forms.Button();
		this.groupBox1.SuspendLayout();
		base.SuspendLayout();
		this.groupBox1.Controls.Add(this.txtKeywords);
		this.groupBox1.Location = new System.Drawing.Point(11, 16);
		this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
		this.groupBox1.Size = new System.Drawing.Size(507, 369);
		this.groupBox1.TabIndex = 0;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "Enter Comma separated keywords";
		this.txtKeywords.Location = new System.Drawing.Point(7, 25);
		this.txtKeywords.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
		this.txtKeywords.Name = "txtKeywords";
		this.txtKeywords.Size = new System.Drawing.Size(491, 336);
		this.txtKeywords.TabIndex = 1;
		this.txtKeywords.Text = "";
		this.btnSave.Image = (System.Drawing.Image)resources.GetObject("btnSave.Image");
		this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnSave.Location = new System.Drawing.Point(383, 393);
		this.btnSave.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
		this.btnSave.Name = "btnSave";
		this.btnSave.Size = new System.Drawing.Size(134, 47);
		this.btnSave.TabIndex = 2;
		this.btnSave.Text = "Save";
		this.btnSave.UseVisualStyleBackColor = true;
		this.btnSave.Click += new System.EventHandler(btnSave_Click);
		base.AutoScaleDimensions = new System.Drawing.SizeF(8f, 16f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(529, 447);
		base.Controls.Add(this.btnSave);
		base.Controls.Add(this.groupBox1);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "AddKeyword";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Add Keywords";
		base.Load += new System.EventHandler(AddKeyword_Load);
		this.groupBox1.ResumeLayout(false);
		base.ResumeLayout(false);
	}
}
