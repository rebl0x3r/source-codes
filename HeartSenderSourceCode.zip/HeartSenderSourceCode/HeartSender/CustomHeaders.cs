using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace HeartSender;

public class CustomHeaders : Form
{
	public Main main;

	private IContainer components;

	private DataGridView gridHeaders;

	private DataGridViewTextBoxColumn Key;

	private DataGridViewTextBoxColumn Value;

	private Button btnAdd;

	private Button btnDel;

	private Button btnImport;

	private Button btnOk;

	public CustomHeaders(Main _main)
	{
		InitializeComponent();
		main = _main;
	}

	private void btnImport_Click(object sender, EventArgs e)
	{
		OpenFileDialog file = new OpenFileDialog();
		file.Filter = "txt files (*.txt)|*.txt";
		Stream stream;
		if (file.ShowDialog() == DialogResult.OK && (stream = file.OpenFile()) != null)
		{
			using (StreamReader sr = new StreamReader(stream))
			{
				string[] data = sr.ReadToEnd().Split(new string[3] { "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
				loadData(data);
			}
			stream.Close();
		}
	}

	private void loadData(string[] rows)
	{
		try
		{
			if (rows.Length == 0)
			{
				return;
			}
			gridHeaders.Rows.Clear();
			int index = 0;
			foreach (string line in rows)
			{
				if (line.Trim().Length >= 1)
				{
					string[] row = line.Split('|');
					index = gridHeaders.Rows.Add();
					gridHeaders.Rows[index].Cells["Key"].Value = row[0];
					gridHeaders.Rows[index].Cells["Value"].Value = row[1];
				}
			}
		}
		catch (Exception)
		{
			MessageBox.Show("Sorry, Invalid file format.");
		}
	}

	private void btnOk_Click(object sender, EventArgs e)
	{
		main.settings[22] = getHeaders();
		Close();
	}

	private string getHeaders()
	{
		string[] headers = new string[gridHeaders.Rows.Count];
		for (int i = 0; i < gridHeaders.Rows.Count - 1; i++)
		{
			if (!(gridHeaders.Rows[i].Cells["Key"].Value.ToString() == ""))
			{
				headers[i] = gridHeaders.Rows[i].Cells["Key"].Value.ToString() + "|" + gridHeaders.Rows[i].Cells["Value"].Value.ToString();
			}
		}
		return string.Join(";", headers);
	}

	private void btnAdd_Click(object sender, EventArgs e)
	{
		gridHeaders.Rows.Add("", "");
	}

	private void btnDel_Click(object sender, EventArgs e)
	{
		if (gridHeaders.SelectedRows.Count > 0)
		{
			foreach (DataGridViewRow row in gridHeaders.SelectedRows)
			{
				gridHeaders.Rows.RemoveAt(row.Index);
			}
			return;
		}
		MessageBox.Show("Please select atleast one row to delete.");
	}

	private void CustomHeaders_Load(object sender, EventArgs e)
	{
		if (main.settings[22].Length <= 0)
		{
			return;
		}
		gridHeaders.Rows.Clear();
		int index = 0;
		string[] array = main.settings[22].Split(';');
		foreach (string line in array)
		{
			if (line.Trim().Length >= 1)
			{
				string[] row = line.Split('|');
				index = gridHeaders.Rows.Add();
				gridHeaders.Rows[index].Cells["Key"].Value = row[0];
				gridHeaders.Rows[index].Cells["Value"].Value = row[1];
			}
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.CustomHeaders));
		this.gridHeaders = new System.Windows.Forms.DataGridView();
		this.Key = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Value = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.btnAdd = new System.Windows.Forms.Button();
		this.btnDel = new System.Windows.Forms.Button();
		this.btnImport = new System.Windows.Forms.Button();
		this.btnOk = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)this.gridHeaders).BeginInit();
		base.SuspendLayout();
		this.gridHeaders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.gridHeaders.Columns.AddRange(this.Key, this.Value);
		this.gridHeaders.Location = new System.Drawing.Point(9, 9);
		this.gridHeaders.Name = "gridHeaders";
		this.gridHeaders.RowHeadersWidth = 51;
		this.gridHeaders.Size = new System.Drawing.Size(531, 405);
		this.gridHeaders.TabIndex = 0;
		this.Key.HeaderText = "Key";
		this.Key.MinimumWidth = 6;
		this.Key.Name = "Key";
		this.Key.Width = 125;
		this.Value.HeaderText = "Value";
		this.Value.MinimumWidth = 6;
		this.Value.Name = "Value";
		this.Value.Width = 125;
		this.btnAdd.Image = (System.Drawing.Image)resources.GetObject("btnAdd.Image");
		this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnAdd.Location = new System.Drawing.Point(152, 420);
		this.btnAdd.Name = "btnAdd";
		this.btnAdd.Size = new System.Drawing.Size(94, 33);
		this.btnAdd.TabIndex = 1;
		this.btnAdd.Text = "  Add Rows";
		this.btnAdd.UseVisualStyleBackColor = true;
		this.btnAdd.Click += new System.EventHandler(btnAdd_Click);
		this.btnDel.Image = (System.Drawing.Image)resources.GetObject("btnDel.Image");
		this.btnDel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnDel.Location = new System.Drawing.Point(250, 420);
		this.btnDel.Name = "btnDel";
		this.btnDel.Size = new System.Drawing.Size(91, 33);
		this.btnDel.TabIndex = 2;
		this.btnDel.Text = "   Del. Rows";
		this.btnDel.UseVisualStyleBackColor = true;
		this.btnDel.Click += new System.EventHandler(btnDel_Click);
		this.btnImport.Image = (System.Drawing.Image)resources.GetObject("btnImport.Image");
		this.btnImport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnImport.Location = new System.Drawing.Point(346, 420);
		this.btnImport.Name = "btnImport";
		this.btnImport.Size = new System.Drawing.Size(94, 33);
		this.btnImport.TabIndex = 3;
		this.btnImport.Text = "Import";
		this.btnImport.UseVisualStyleBackColor = true;
		this.btnImport.Click += new System.EventHandler(btnImport_Click);
		this.btnOk.Image = (System.Drawing.Image)resources.GetObject("btnOk.Image");
		this.btnOk.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnOk.Location = new System.Drawing.Point(446, 420);
		this.btnOk.Name = "btnOk";
		this.btnOk.Size = new System.Drawing.Size(94, 33);
		this.btnOk.TabIndex = 5;
		this.btnOk.Text = "Done";
		this.btnOk.UseVisualStyleBackColor = true;
		this.btnOk.Click += new System.EventHandler(btnOk_Click);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(551, 465);
		base.Controls.Add(this.btnOk);
		base.Controls.Add(this.btnImport);
		base.Controls.Add(this.btnDel);
		base.Controls.Add(this.btnAdd);
		base.Controls.Add(this.gridHeaders);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "CustomHeaders";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Custom Headers";
		base.Load += new System.EventHandler(CustomHeaders_Load);
		((System.ComponentModel.ISupportInitialize)this.gridHeaders).EndInit();
		base.ResumeLayout(false);
	}
}
