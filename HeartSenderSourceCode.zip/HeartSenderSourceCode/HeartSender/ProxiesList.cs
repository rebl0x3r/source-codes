using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Net;
using System.Windows.Forms;
using CommonSender;

namespace HeartSender;

public class ProxiesList : Form
{
	public Main main;

	private IContainer components;

	private Button btnDone;

	private Button btnRemove;

	private DataGridView gridProxies;

	private Button btnAddSMTP;

	private NumericUpDown ctrlNumPort;

	private Button btnClear;

	private GroupBox groupBox3;

	private Label label2;

	private TextBox txtHost;

	private Label label1;

	private GroupBox groupBox1;

	private TextBox txtPassword;

	private Label label4;

	private TextBox txtUsername;

	private Label label3;

	private Label label5;

	private ComboBox cmbType;

	private Button btnProxyChecker;

	private Button btnBulkTest;

	private Button btnClean;

	private Button btnImport;

	private DataGridViewTextBoxColumn Host;

	private DataGridViewTextBoxColumn Port;

	private DataGridViewTextBoxColumn Username;

	private DataGridViewTextBoxColumn Password;

	private DataGridViewTextBoxColumn ProxyType;

	private DataGridViewTextBoxColumn Column1;

	public ProxiesList(Main _main)
	{
		InitializeComponent();
		main = _main;
	}

	private void ProxiesList_Load(object sender, EventArgs e)
	{
		if (Main.proxies.Count <= 0)
		{
			return;
		}
		gridProxies.Rows.Clear();
		int index = 0;
		foreach (string proxy in Main.proxies)
		{
			if (!(proxy.Trim() == ""))
			{
				string[] tokens = proxy.Split(new string[1] { "|||" }, StringSplitOptions.None);
				if (tokens.Length > 4)
				{
					index = gridProxies.Rows.Add();
					gridProxies.Rows[index].Cells["Host"].Value = tokens[0].Trim();
					gridProxies.Rows[index].Cells["Port"].Value = tokens[1].Trim();
					gridProxies.Rows[index].Cells["Username"].Value = tokens[2].Trim();
					gridProxies.Rows[index].Cells["Password"].Value = tokens[3].Trim();
					gridProxies.Rows[index].Cells["ProxyType"].Value = tokens[4].Trim();
				}
			}
		}
	}

	private void btnRemove_Click(object sender, EventArgs e)
	{
		if (gridProxies.SelectedRows.Count > 0)
		{
			foreach (DataGridViewRow row in gridProxies.SelectedRows)
			{
				gridProxies.Rows.RemoveAt(row.Index);
			}
			return;
		}
		MessageBox.Show("Please select atleast one row to delete.");
	}

	private void btnClear_Click(object sender, EventArgs e)
	{
		gridProxies.Rows.Clear();
	}

	private void btnDone_Click(object sender, EventArgs e)
	{
		Main.proxies.Clear();
		for (int index = 0; index < gridProxies.Rows.Count; index++)
		{
			if (!(gridProxies.Rows[index].Cells["Host"].Value.ToString() == "") && gridProxies.Rows[index].Cells["Port"].Value.ToString().Trim().Length != 0)
			{
				string[] tokens = new string[5]
				{
					gridProxies.Rows[index].Cells["Host"].Value.ToString().Trim(),
					gridProxies.Rows[index].Cells["Port"].Value.ToString().Trim(),
					gridProxies.Rows[index].Cells["Username"].Value.ToString().Trim(),
					gridProxies.Rows[index].Cells["Password"].Value.ToString().Trim(),
					gridProxies.Rows[index].Cells["ProxyType"].Value.ToString().Trim()
				};
				Main.proxies.Add(string.Join("|||", tokens));
			}
		}
		Close();
	}

	private void btnAddSMTP_Click(object sender, EventArgs e)
	{
		if (txtHost.Text.Trim().Length == 0 || ctrlNumPort.Value <= 0m || cmbType.Text.Trim().Length == 0)
		{
			MessageBox.Show("Please enter valid details for Proxy.");
			return;
		}
		int index = gridProxies.Rows.Add();
		gridProxies.Rows[index].Cells["Host"].Value = txtHost.Text;
		gridProxies.Rows[index].Cells["Port"].Value = ctrlNumPort.Value.ToString();
		gridProxies.Rows[index].Cells["Username"].Value = txtUsername.Text;
		gridProxies.Rows[index].Cells["Password"].Value = txtPassword.Text;
		gridProxies.Rows[index].Cells["ProxyType"].Value = cmbType.Text;
		string[] tokens = new string[5]
		{
			gridProxies.Rows[index].Cells["Host"].Value.ToString().Trim(),
			gridProxies.Rows[index].Cells["Port"].Value.ToString().Trim(),
			gridProxies.Rows[index].Cells["Username"].Value.ToString().Trim(),
			gridProxies.Rows[index].Cells["Password"].Value.ToString().Trim(),
			gridProxies.Rows[index].Cells["ProxyType"].Value.ToString().Trim()
		};
		Main.proxies.Add(string.Join("|||", tokens));
	}

	private void btnCheck_Click(object sender, EventArgs e)
	{
		GxLicense gxLicense = new GxLicense();
		string type = "s5";
		if (cmbType.Text == "Http" || cmbType.Text == "Https")
		{
			type = "h";
		}
		else if (cmbType.Text == "Sock4")
		{
			type = "s4";
		}
		if (gxLicense.checkProxy(txtHost.Text.Trim() + ":" + ctrlNumPort.Value.ToString().Trim() + ":" + type.Trim()))
		{
			MessageBox.Show("Connection Ok!", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		else
		{
			MessageBox.Show("Sorry, there is some problem with the Proxy. Couldn't connect.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	private void btnProxyChecker_Click(object sender, EventArgs e)
	{
		try
		{
			WebProxy myProxy = null;
			myProxy = new WebProxy(txtHost.Text + ":" + int.Parse(ctrlNumPort.Value.ToString()));
			if ((txtPassword.Text != "" && txtUsername.Text != "") || (txtUsername.Text != null && txtPassword.Text != null))
			{
				ICredentials credentials = new NetworkCredential(txtUsername.Text, txtPassword.Text);
				myProxy = new WebProxy(txtHost.Text + ":" + int.Parse(ctrlNumPort.Value.ToString()), BypassOnLocal: true, null, credentials);
			}
			else
			{
				myProxy = new WebProxy(txtHost.Text + ":" + int.Parse(ctrlNumPort.Value.ToString()));
			}
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create("http://www.microsoft.com");
			obj.UserAgent = "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.2 Safari/537.36";
			obj.Timeout = 10000;
			obj.Proxy = myProxy;
			MessageBox.Show(((HttpWebResponse)obj.GetResponse()).StatusDescription);
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
	}

	private void btnBulkTest_Click(object sender, EventArgs e)
	{
		for (int i = 0; i < gridProxies.Rows.Count; i++)
		{
			try
			{
				WebProxy myProxy = null;
				if ((gridProxies.Rows[i].Cells[2].Value.ToString() != "" && gridProxies.Rows[i].Cells[3].Value.ToString() != "") || (gridProxies.Rows[i].Cells[2].Value.ToString() != null && gridProxies.Rows[i].Cells[3].Value.ToString() != null))
				{
					ICredentials credentials = new NetworkCredential(gridProxies.Rows[i].Cells[2].Value.ToString(), gridProxies.Rows[i].Cells[3].Value.ToString());
					myProxy = new WebProxy(gridProxies.Rows[i].Cells[0].Value.ToString() + ":" + int.Parse(gridProxies.Rows[i].Cells[1].Value.ToString()), BypassOnLocal: true, null, credentials);
				}
				else
				{
					myProxy = new WebProxy(gridProxies.Rows[i].Cells[0].Value.ToString() + ":" + int.Parse(gridProxies.Rows[i].Cells[1].Value.ToString()));
				}
				HttpWebRequest obj = (HttpWebRequest)WebRequest.Create("http://www.microsoft.com");
				obj.UserAgent = "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.2 Safari/537.36";
				obj.Timeout = 5000;
				obj.Proxy = myProxy;
				HttpWebResponse myWebResponse = (HttpWebResponse)obj.GetResponse();
				gridProxies.Rows[i].Cells[5].Value = myWebResponse.StatusDescription;
			}
			catch (Exception ex)
			{
				gridProxies.Rows[i].Cells[5].Value = ex.Message;
			}
		}
	}

	private void btnClean_Click(object sender, EventArgs e)
	{
		foreach (DataGridViewRow item in (IEnumerable)gridProxies.Rows)
		{
			if (!item.Cells[5].Value.ToString().Contains("OK"))
			{
				gridProxies.Rows.Remove(item);
			}
		}
	}

	private void btnImport_Click(object sender, EventArgs e)
	{
		OpenFileDialog file = new OpenFileDialog();
		file.Filter = "txt files (*.txt)|*.txt";
		Stream stream;
		if (file.ShowDialog() == DialogResult.OK && (stream = file.OpenFile()) != null)
		{
			using (StreamReader sr = new StreamReader(stream))
			{
				string[] data = sr.ReadToEnd().Split(new string[3] { "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
				loadData(data);
			}
			stream.Close();
		}
	}

	private void loadData(string[] rows)
	{
		try
		{
			if (rows.Length == 0)
			{
				return;
			}
			gridProxies.Rows.Clear();
			int index = 0;
			foreach (string line in rows)
			{
				if (line.Trim().Length >= 1)
				{
					string[] row = line.Split('|');
					if (row.Length >= 5)
					{
						index = gridProxies.Rows.Add();
						gridProxies.Rows[index].Cells[0].Value = row[0];
						gridProxies.Rows[index].Cells[1].Value = row[1];
						gridProxies.Rows[index].Cells[2].Value = row[2];
						gridProxies.Rows[index].Cells[3].Value = row[3];
						gridProxies.Rows[index].Cells[4].Value = row[4];
					}
				}
			}
			Main.proxies.Clear();
			string[] tokens = new string[5];
			for (int i = 0; i < gridProxies.Rows.Count; i++)
			{
				try
				{
					tokens[0] = gridProxies.Rows[i].Cells[0].Value.ToString().Trim();
					tokens[1] = gridProxies.Rows[i].Cells[1].Value.ToString().Trim();
					tokens[2] = gridProxies.Rows[i].Cells[2].Value.ToString().Trim();
					tokens[3] = gridProxies.Rows[i].Cells[3].Value.ToString().Trim();
					tokens[4] = gridProxies.Rows[i].Cells[4].Value.ToString().Trim();
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message, "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}
		catch (Exception)
		{
			MessageBox.Show("Sorry, Invalid file format.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.ProxiesList));
		this.btnDone = new System.Windows.Forms.Button();
		this.btnRemove = new System.Windows.Forms.Button();
		this.gridProxies = new System.Windows.Forms.DataGridView();
		this.btnAddSMTP = new System.Windows.Forms.Button();
		this.ctrlNumPort = new System.Windows.Forms.NumericUpDown();
		this.btnClear = new System.Windows.Forms.Button();
		this.groupBox3 = new System.Windows.Forms.GroupBox();
		this.label2 = new System.Windows.Forms.Label();
		this.txtHost = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.btnProxyChecker = new System.Windows.Forms.Button();
		this.label5 = new System.Windows.Forms.Label();
		this.cmbType = new System.Windows.Forms.ComboBox();
		this.txtPassword = new System.Windows.Forms.TextBox();
		this.label4 = new System.Windows.Forms.Label();
		this.txtUsername = new System.Windows.Forms.TextBox();
		this.label3 = new System.Windows.Forms.Label();
		this.btnBulkTest = new System.Windows.Forms.Button();
		this.btnClean = new System.Windows.Forms.Button();
		this.btnImport = new System.Windows.Forms.Button();
		this.Host = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Port = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Username = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.ProxyType = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		((System.ComponentModel.ISupportInitialize)this.gridProxies).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.ctrlNumPort).BeginInit();
		this.groupBox3.SuspendLayout();
		this.groupBox1.SuspendLayout();
		base.SuspendLayout();
		this.btnDone.Image = (System.Drawing.Image)resources.GetObject("btnDone.Image");
		this.btnDone.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnDone.Location = new System.Drawing.Point(529, 295);
		this.btnDone.Name = "btnDone";
		this.btnDone.Size = new System.Drawing.Size(94, 36);
		this.btnDone.TabIndex = 2;
		this.btnDone.Text = "Done";
		this.btnDone.UseVisualStyleBackColor = true;
		this.btnDone.Click += new System.EventHandler(btnDone_Click);
		this.btnRemove.Image = (System.Drawing.Image)resources.GetObject("btnRemove.Image");
		this.btnRemove.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnRemove.Location = new System.Drawing.Point(190, 295);
		this.btnRemove.Name = "btnRemove";
		this.btnRemove.Size = new System.Drawing.Size(110, 36);
		this.btnRemove.TabIndex = 1;
		this.btnRemove.Text = "Remove Row";
		this.btnRemove.UseVisualStyleBackColor = true;
		this.btnRemove.Click += new System.EventHandler(btnRemove_Click);
		this.gridProxies.AllowUserToAddRows = false;
		this.gridProxies.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.gridProxies.Columns.AddRange(this.Host, this.Port, this.Username, this.Password, this.ProxyType, this.Column1);
		this.gridProxies.Location = new System.Drawing.Point(6, 21);
		this.gridProxies.Name = "gridProxies";
		this.gridProxies.RowHeadersWidth = 51;
		this.gridProxies.Size = new System.Drawing.Size(617, 259);
		this.gridProxies.TabIndex = 0;
		this.btnAddSMTP.Location = new System.Drawing.Point(545, 83);
		this.btnAddSMTP.Name = "btnAddSMTP";
		this.btnAddSMTP.Size = new System.Drawing.Size(78, 27);
		this.btnAddSMTP.TabIndex = 6;
		this.btnAddSMTP.Text = "Add";
		this.btnAddSMTP.UseVisualStyleBackColor = true;
		this.btnAddSMTP.Click += new System.EventHandler(btnAddSMTP_Click);
		this.ctrlNumPort.Location = new System.Drawing.Point(42, 90);
		this.ctrlNumPort.Maximum = new decimal(new int[4] { 9999999, 0, 0, 0 });
		this.ctrlNumPort.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.ctrlNumPort.Name = "ctrlNumPort";
		this.ctrlNumPort.Size = new System.Drawing.Size(240, 20);
		this.ctrlNumPort.TabIndex = 4;
		this.ctrlNumPort.Value = new decimal(new int[4] { 1, 0, 0, 0 });
		this.btnClear.Image = (System.Drawing.Image)resources.GetObject("btnClear.Image");
		this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnClear.Location = new System.Drawing.Point(93, 295);
		this.btnClear.Name = "btnClear";
		this.btnClear.Size = new System.Drawing.Size(94, 36);
		this.btnClear.TabIndex = 3;
		this.btnClear.Text = "Clear";
		this.btnClear.UseVisualStyleBackColor = true;
		this.btnClear.Click += new System.EventHandler(btnClear_Click);
		this.groupBox3.Controls.Add(this.btnImport);
		this.groupBox3.Controls.Add(this.btnClean);
		this.groupBox3.Controls.Add(this.btnBulkTest);
		this.groupBox3.Controls.Add(this.btnClear);
		this.groupBox3.Controls.Add(this.btnDone);
		this.groupBox3.Controls.Add(this.btnRemove);
		this.groupBox3.Controls.Add(this.gridProxies);
		this.groupBox3.Location = new System.Drawing.Point(12, 139);
		this.groupBox3.Name = "groupBox3";
		this.groupBox3.Size = new System.Drawing.Size(629, 337);
		this.groupBox3.TabIndex = 10;
		this.groupBox3.TabStop = false;
		this.groupBox3.Text = "Proxies List";
		this.label2.AutoSize = true;
		this.label2.Location = new System.Drawing.Point(10, 90);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(32, 13);
		this.label2.TabIndex = 3;
		this.label2.Text = "Port: ";
		this.txtHost.Location = new System.Drawing.Point(42, 57);
		this.txtHost.Name = "txtHost";
		this.txtHost.Size = new System.Drawing.Size(240, 20);
		this.txtHost.TabIndex = 2;
		this.label1.AutoSize = true;
		this.label1.Location = new System.Drawing.Point(9, 60);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(35, 13);
		this.label1.TabIndex = 1;
		this.label1.Text = "Host: ";
		this.groupBox1.Controls.Add(this.btnProxyChecker);
		this.groupBox1.Controls.Add(this.label5);
		this.groupBox1.Controls.Add(this.cmbType);
		this.groupBox1.Controls.Add(this.txtPassword);
		this.groupBox1.Controls.Add(this.btnAddSMTP);
		this.groupBox1.Controls.Add(this.label4);
		this.groupBox1.Controls.Add(this.ctrlNumPort);
		this.groupBox1.Controls.Add(this.txtUsername);
		this.groupBox1.Controls.Add(this.label3);
		this.groupBox1.Controls.Add(this.label2);
		this.groupBox1.Controls.Add(this.txtHost);
		this.groupBox1.Controls.Add(this.label1);
		this.groupBox1.Location = new System.Drawing.Point(12, 9);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(629, 125);
		this.groupBox1.TabIndex = 9;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "Add Sock Proxy";
		this.btnProxyChecker.Location = new System.Drawing.Point(467, 83);
		this.btnProxyChecker.Name = "btnProxyChecker";
		this.btnProxyChecker.Size = new System.Drawing.Size(72, 27);
		this.btnProxyChecker.TabIndex = 14;
		this.btnProxyChecker.Text = "Test Proxy";
		this.btnProxyChecker.UseVisualStyleBackColor = true;
		this.btnProxyChecker.Click += new System.EventHandler(btnProxyChecker_Click);
		this.label5.AutoSize = true;
		this.label5.Location = new System.Drawing.Point(343, 53);
		this.label5.Name = "label5";
		this.label5.Size = new System.Drawing.Size(34, 13);
		this.label5.TabIndex = 13;
		this.label5.Text = "Type:";
		this.cmbType.FormattingEnabled = true;
		this.cmbType.Items.AddRange(new object[3] { "Http", "Sock4", "Sock5" });
		this.cmbType.Location = new System.Drawing.Point(383, 53);
		this.cmbType.Name = "cmbType";
		this.cmbType.Size = new System.Drawing.Size(240, 21);
		this.cmbType.TabIndex = 12;
		this.cmbType.Text = "Sock5";
		this.txtPassword.Location = new System.Drawing.Point(383, 18);
		this.txtPassword.Name = "txtPassword";
		this.txtPassword.Size = new System.Drawing.Size(240, 20);
		this.txtPassword.TabIndex = 11;
		this.label4.AutoSize = true;
		this.label4.Location = new System.Drawing.Point(344, 18);
		this.label4.Name = "label4";
		this.label4.Size = new System.Drawing.Size(33, 13);
		this.label4.TabIndex = 10;
		this.label4.Text = "Pass:";
		this.txtUsername.Location = new System.Drawing.Point(42, 25);
		this.txtUsername.Name = "txtUsername";
		this.txtUsername.Size = new System.Drawing.Size(240, 20);
		this.txtUsername.TabIndex = 8;
		this.label3.AutoSize = true;
		this.label3.Location = new System.Drawing.Point(9, 25);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(32, 13);
		this.label3.TabIndex = 8;
		this.label3.Text = "User:";
		this.btnBulkTest.Image = (System.Drawing.Image)resources.GetObject("btnBulkTest.Image");
		this.btnBulkTest.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnBulkTest.Location = new System.Drawing.Point(431, 295);
		this.btnBulkTest.Name = "btnBulkTest";
		this.btnBulkTest.Size = new System.Drawing.Size(94, 36);
		this.btnBulkTest.TabIndex = 6;
		this.btnBulkTest.Text = "Test all";
		this.btnBulkTest.UseVisualStyleBackColor = true;
		this.btnBulkTest.Click += new System.EventHandler(btnBulkTest_Click);
		this.btnClean.Image = (System.Drawing.Image)resources.GetObject("btnClean.Image");
		this.btnClean.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnClean.Location = new System.Drawing.Point(303, 295);
		this.btnClean.Name = "btnClean";
		this.btnClean.Size = new System.Drawing.Size(126, 36);
		this.btnClean.TabIndex = 7;
		this.btnClean.Text = "Clean proxies";
		this.btnClean.UseVisualStyleBackColor = true;
		this.btnClean.Click += new System.EventHandler(btnClean_Click);
		this.btnImport.Image = (System.Drawing.Image)resources.GetObject("btnImport.Image");
		this.btnImport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnImport.Location = new System.Drawing.Point(7, 294);
		this.btnImport.Name = "btnImport";
		this.btnImport.Size = new System.Drawing.Size(82, 36);
		this.btnImport.TabIndex = 8;
		this.btnImport.Text = "Import";
		this.btnImport.UseVisualStyleBackColor = true;
		this.btnImport.Click += new System.EventHandler(btnImport_Click);
		this.Host.HeaderText = "Host";
		this.Host.MinimumWidth = 6;
		this.Host.Name = "Host";
		this.Host.Width = 125;
		this.Port.HeaderText = "Port";
		this.Port.MinimumWidth = 6;
		this.Port.Name = "Port";
		this.Port.Width = 125;
		this.Username.HeaderText = "Username";
		this.Username.MinimumWidth = 6;
		this.Username.Name = "Username";
		this.Username.Width = 125;
		this.Password.HeaderText = "Password";
		this.Password.MinimumWidth = 6;
		this.Password.Name = "Password";
		this.Password.Width = 125;
		this.ProxyType.HeaderText = "ProxyType";
		this.ProxyType.MinimumWidth = 6;
		this.ProxyType.Name = "ProxyType";
		this.ProxyType.Width = 125;
		this.Column1.HeaderText = "Status";
		this.Column1.Name = "Column1";
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(653, 488);
		base.Controls.Add(this.groupBox3);
		base.Controls.Add(this.groupBox1);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "ProxiesList";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Manage Proxies";
		base.Load += new System.EventHandler(ProxiesList_Load);
		((System.ComponentModel.ISupportInitialize)this.gridProxies).EndInit();
		((System.ComponentModel.ISupportInitialize)this.ctrlNumPort).EndInit();
		this.groupBox3.ResumeLayout(false);
		this.groupBox1.ResumeLayout(false);
		this.groupBox1.PerformLayout();
		base.ResumeLayout(false);
	}
}
