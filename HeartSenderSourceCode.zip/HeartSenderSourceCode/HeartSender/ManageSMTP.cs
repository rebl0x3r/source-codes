using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text;
using System.Windows.Forms;
using CommonSender;
using Microsoft.VisualBasic;

namespace HeartSender;

public class ManageSMTP : Form
{
	public Main main;

	private string EA_license = "ES-D1508812687-00796-43EDA8441T7A552E-FV3A13A8DF3826B7";

	private IContainer components;

	private GroupBox groupBox1;

	private Label label1;

	private Label label2;

	private TextBox txtHost;

	private NumericUpDown ctrlNumPort;

	private Button btnAddSMTP;

	private Button btnTest;

	private GroupBox groupBox2;

	private CheckBox chkAuth;

	private CheckBox chkSSL;

	private Label label3;

	private Label label4;

	private TextBox txtUsername;

	private TextBox txtPassword;

	private GroupBox groupBox3;

	private DataGridView gridSMTPs;

	private Button btnClear;

	private Button btnDone;

	private Button btnRemove;

	private Button btnCheckIP;

	private TextBox txtToEmail;

	private Label label6;

	private TextBox txtFromEmail;

	private Label label5;

	private CheckBox chkDirectDelivery;

	private TextBox txtMaxLimit;

	private Label label7;

	private DataGridViewTextBoxColumn Host;

	private DataGridViewTextBoxColumn Port;

	private DataGridViewTextBoxColumn Username;

	private DataGridViewTextBoxColumn Password;

	private DataGridViewTextBoxColumn Secure;

	private DataGridViewTextBoxColumn Limit;

	private DataGridViewTextBoxColumn Usage;

	private DataGridViewTextBoxColumn FromEmail;

	private Button btnOnlineCheck;

	public ManageSMTP(Main _main)
	{
		InitializeComponent();
		main = _main;
	}

	private void ManageSMTP_Load(object sender, EventArgs e)
	{
		if (Main.smtps.Count <= 0)
		{
			return;
		}
		int index = 0;
		GxDB db = new GxDB();
		foreach (GxSMTP smtp in Main.smtps)
		{
			index = gridSMTPs.Rows.Add();
			smtp.usage_count = db.getSmtpCount(smtp.getMd5Code());
			gridSMTPs.Rows[index].Cells["Host"].Value = smtp.host;
			gridSMTPs.Rows[index].Cells["Port"].Value = smtp.port.ToString();
			gridSMTPs.Rows[index].Cells["Username"].Value = smtp.username;
			gridSMTPs.Rows[index].Cells["Password"].Value = smtp.password;
			gridSMTPs.Rows[index].Cells["Secure"].Value = (smtp.secure ? "ssl" : "");
			gridSMTPs.Rows[index].Cells["Limit"].Value = smtp.max_limit;
			gridSMTPs.Rows[index].Cells["Usage"].Value = smtp.usage_count;
			gridSMTPs.Rows[index].Cells["FromEmail"].Value = smtp.from_email;
		}
	}

	private void button4_Click(object sender, EventArgs e)
	{
		Main.smtps.Clear();
		GxDB db = new GxDB();
		for (int index = 0; index < gridSMTPs.Rows.Count; index++)
		{
			if ((gridSMTPs.Rows[index].Cells["Host"].Value.ToString().Trim().Length != 0 && int.Parse(gridSMTPs.Rows[index].Cells["Port"].Value.ToString()) > 0 && gridSMTPs.Rows[index].Cells["Username"].Value.ToString().Trim().Length != 0 && gridSMTPs.Rows[index].Cells["Password"].Value.ToString().Trim().Length != 0) || !(gridSMTPs.Rows[index].Cells["Host"].Value.ToString().Trim().ToLower() != "direct"))
			{
				GxSMTP new_smtp = new GxSMTP();
				new_smtp.host = gridSMTPs.Rows[index].Cells["Host"].Value.ToString().Trim();
				new_smtp.port = int.Parse(gridSMTPs.Rows[index].Cells["Port"].Value.ToString().Trim());
				new_smtp.username = gridSMTPs.Rows[index].Cells["Username"].Value.ToString().Trim();
				new_smtp.password = gridSMTPs.Rows[index].Cells["Password"].Value.ToString().Trim();
				new_smtp.max_limit = int.Parse(gridSMTPs.Rows[index].Cells["Limit"].Value.ToString().Trim());
				new_smtp.usage_count = db.getSmtpCount(new_smtp.getMd5Code());
				new_smtp.secure = false;
				if (gridSMTPs.Rows[index].Cells["Secure"].Value != null)
				{
					new_smtp.secure = gridSMTPs.Rows[index].Cells["Secure"].Value.ToString() == "tls" || gridSMTPs.Rows[index].Cells["Secure"].Value.ToString() == "ssl";
				}
				new_smtp.from_email = gridSMTPs.Rows[index].Cells["FromEmail"].Value.ToString().Trim();
				Main.smtps.Add(new_smtp);
			}
		}
		main.populateSMTPs();
		Close();
	}

	private void button5_Click(object sender, EventArgs e)
	{
		gridSMTPs.Rows.Clear();
	}

	private void btnRemove_Click(object sender, EventArgs e)
	{
		if (gridSMTPs.SelectedRows.Count > 0)
		{
			foreach (DataGridViewRow row in gridSMTPs.SelectedRows)
			{
				gridSMTPs.Rows.RemoveAt(row.Index);
			}
			return;
		}
		MessageBox.Show("Please select atleast one row to delete.");
	}

	private void btnAddSMTP_Click(object sender, EventArgs e)
	{
		if ((txtHost.Text.Trim().Length == 0 || ctrlNumPort.Value <= 0m || txtUsername.Text.Trim().Length == 0 || txtPassword.Text.Trim().Length == 0) && txtHost.Text.Trim() != "localhost" && txtHost.Text.Trim() != "127.0.0.1" && !chkDirectDelivery.Checked)
		{
			MessageBox.Show("Please enter valid detail for SMTP.");
			return;
		}
		int index = gridSMTPs.Rows.Add();
		gridSMTPs.Rows[index].Cells["Host"].Value = txtHost.Text.Trim();
		gridSMTPs.Rows[index].Cells["Port"].Value = ctrlNumPort.Value.ToString();
		gridSMTPs.Rows[index].Cells["Username"].Value = txtUsername.Text.Trim();
		gridSMTPs.Rows[index].Cells["Password"].Value = txtPassword.Text.Trim();
		gridSMTPs.Rows[index].Cells["Secure"].Value = (chkSSL.Checked ? "ssl" : "");
		gridSMTPs.Rows[index].Cells["Limit"].Value = 0;
		if (txtMaxLimit.Text.Trim().Length > 0)
		{
			gridSMTPs.Rows[index].Cells["Limit"].Value = txtMaxLimit.Text.Trim();
		}
		gridSMTPs.Rows[index].Cells["Usage"].Value = 0;
		gridSMTPs.Rows[index].Cells["FromEmail"].Value = txtFromEmail.Text.Trim();
		GxSMTP new_smtp = new GxSMTP();
		new_smtp.host = txtHost.Text;
		new_smtp.port = int.Parse(ctrlNumPort.Value.ToString());
		new_smtp.username = txtUsername.Text;
		new_smtp.password = txtPassword.Text;
		new_smtp.secure = chkSSL.Checked;
		new_smtp.max_limit = 0;
		if (txtMaxLimit.Text.Trim().Length > 0)
		{
			new_smtp.max_limit = int.Parse(txtMaxLimit.Text.Trim());
		}
		new_smtp.from_email = txtFromEmail.Text.Trim();
		Main.smtps.Add(new_smtp);
	}

	private void btnTest_Click(object sender, EventArgs e)
	{
		if (txtHost.Text.Trim().Length == 0 || ctrlNumPort.Value <= 0m)
		{
			MessageBox.Show("Please enter valid detail for SMTP.");
		}
		else if (txtToEmail.Text == "")
		{
			MessageBox.Show("Please enter valid [To Email] address.");
		}
		else if (txtFromEmail.Text == "")
		{
			MessageBox.Show("Please enter valid [From Email] address.");
		}
		else if (txtToEmail.Text == txtFromEmail.Text)
		{
			MessageBox.Show("[From Email] and [To Email] address should be different.");
		}
		else
		{
			btnTest.Enabled = false;
			MessageBox.Show(new GxApi().isValidSMTP(GxConfig.baseUrl() + "backend/smtp-checker", new string[7]
			{
				txtHost.Text.Trim(),
				txtUsername.Text.Trim(),
				txtPassword.Text.Trim(),
				ctrlNumPort.Value.ToString().Trim(),
				chkSSL.Checked ? "1" : "0",
				txtFromEmail.Text.Trim(),
				txtToEmail.Text.Trim()
			}));
		}
		btnTest.Enabled = true;
	}

	private void btnCheckIP_Click(object sender, EventArgs e)
	{
		int count = new GxApi().isValidIPAddress(GxConfig.baseUrl() + "backend/ip-checker");
		if (count >= 0)
		{
			MessageBox.Show("IP Address Ok!", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		else if (count == -1)
		{
			MessageBox.Show("Sorry, there is some problem verifying your IP Address. Please try again later.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
		else
		{
			MessageBox.Show("IP Address blacklist on " + count + " sites.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	private void chkDirectDelivery_CheckedChanged(object sender, EventArgs e)
	{
		if (chkDirectDelivery.Checked)
		{
			txtHost.Text = "Direct";
			ctrlNumPort.Value = 1m;
		}
		else
		{
			txtHost.Text = "";
			ctrlNumPort.Value = 587m;
		}
	}

	private void btnAllSMTPChecker_Click(object sender, EventArgs e)
	{
		Rectangle screensize = Screen.PrimaryScreen.Bounds;
		string input = Interaction.InputBox("Your Email:", "Input Your Email to Check SMTP:", "", screensize.Width / 2 - 200, screensize.Height / 2);
		if (input == "" && input.Split('@').Length != 2)
		{
			MessageBox.Show("Please enter valid email address.", "HeartSender");
			return;
		}
		GxApi api = new GxApi();
		for (int index = 0; index < gridSMTPs.Rows.Count; index++)
		{
			if ((gridSMTPs.Rows[index].Cells["Host"].Value.ToString().Trim().Length != 0 && int.Parse(gridSMTPs.Rows[index].Cells["Port"].Value.ToString()) > 0 && gridSMTPs.Rows[index].Cells["Username"].Value.ToString().Trim().Length != 0 && gridSMTPs.Rows[index].Cells["Password"].Value.ToString().Trim().Length != 0) || !(gridSMTPs.Rows[index].Cells["Host"].Value.ToString().Trim().ToLower() != "direct"))
			{
				GxSMTP new_smtp = new GxSMTP();
				new_smtp.host = gridSMTPs.Rows[index].Cells["Host"].Value.ToString().Trim();
				new_smtp.port = int.Parse(gridSMTPs.Rows[index].Cells["Port"].Value.ToString().Trim());
				new_smtp.username = gridSMTPs.Rows[index].Cells["Username"].Value.ToString().Trim();
				new_smtp.password = gridSMTPs.Rows[index].Cells["Password"].Value.ToString().Trim();
				new_smtp.max_limit = int.Parse(gridSMTPs.Rows[index].Cells["Limit"].Value.ToString().Trim());
				new_smtp.secure = false;
				if (gridSMTPs.Rows[index].Cells["Secure"].Value != null)
				{
					new_smtp.secure = gridSMTPs.Rows[index].Cells["Secure"].Value.ToString() == "tls" || gridSMTPs.Rows[index].Cells["Secure"].Value.ToString() == "ssl";
				}
				new_smtp.from_email = gridSMTPs.Rows[index].Cells["FromEmail"].Value.ToString().Trim();
				gridSMTPs.Rows[index].Cells["Status"].Value = api.isValidSMTP(GxConfig.baseUrl() + "backend/smtp-checker", new string[7]
				{
					new_smtp.host.Trim(),
					new_smtp.username.Trim(),
					new_smtp.password.Trim(),
					new_smtp.port.ToString().Trim(),
					new_smtp.secure ? "1" : "0",
					"sender@oneskyrocket.com",
					input.Trim()
				});
			}
		}
	}

	private void btnOnlineCheck_Click(object sender, EventArgs e)
	{
		if (txtHost.Text.Trim().Length == 0 || ctrlNumPort.Value <= 0m)
		{
			MessageBox.Show("Please enter valid detail for SMTP.");
			return;
		}
		if (txtToEmail.Text == "")
		{
			MessageBox.Show("Please enter valid [To Email] address.");
			return;
		}
		if (txtFromEmail.Text == "")
		{
			MessageBox.Show("Please enter valid [From Email] address.");
			return;
		}
		if (txtToEmail.Text == txtFromEmail.Text)
		{
			MessageBox.Show("[From Email] and [To Email] address should be different.");
			return;
		}
		string auth = (chkSSL.Checked ? "1" : "0");
		string paramters = "host=" + txtHost.Text + "&port=" + ctrlNumPort.Value + "&username=" + txtUsername.Text + "&password=" + txtPassword.Text + "&auth=" + auth + "&fromemail=" + txtFromEmail.Text + "&toemail=" + txtToEmail.Text;
		string api_url = "https://bestfriendstore.net/web/leads/check-smtp?" + paramters;
		try
		{
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create(api_url);
			obj.Method = "GET";
			HttpWebResponse webresponse = (HttpWebResponse)obj.GetResponse();
			Encoding enc = Encoding.GetEncoding("utf-8");
			string result = new StreamReader(webresponse.GetResponseStream(), enc).ReadToEnd();
			webresponse.Close();
			if (result.ToString().Trim() == "ok")
			{
				MessageBox.Show("Smtp Working Prefect !!");
			}
			else
			{
				MessageBox.Show(result.ToString().Trim());
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.ManageSMTP));
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.txtMaxLimit = new System.Windows.Forms.TextBox();
		this.label7 = new System.Windows.Forms.Label();
		this.btnCheckIP = new System.Windows.Forms.Button();
		this.groupBox2 = new System.Windows.Forms.GroupBox();
		this.chkDirectDelivery = new System.Windows.Forms.CheckBox();
		this.txtToEmail = new System.Windows.Forms.TextBox();
		this.label6 = new System.Windows.Forms.Label();
		this.txtFromEmail = new System.Windows.Forms.TextBox();
		this.label5 = new System.Windows.Forms.Label();
		this.txtPassword = new System.Windows.Forms.TextBox();
		this.label4 = new System.Windows.Forms.Label();
		this.txtUsername = new System.Windows.Forms.TextBox();
		this.label3 = new System.Windows.Forms.Label();
		this.chkSSL = new System.Windows.Forms.CheckBox();
		this.chkAuth = new System.Windows.Forms.CheckBox();
		this.btnAddSMTP = new System.Windows.Forms.Button();
		this.btnTest = new System.Windows.Forms.Button();
		this.ctrlNumPort = new System.Windows.Forms.NumericUpDown();
		this.label2 = new System.Windows.Forms.Label();
		this.txtHost = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.groupBox3 = new System.Windows.Forms.GroupBox();
		this.btnClear = new System.Windows.Forms.Button();
		this.btnDone = new System.Windows.Forms.Button();
		this.btnRemove = new System.Windows.Forms.Button();
		this.gridSMTPs = new System.Windows.Forms.DataGridView();
		this.Host = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Port = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Username = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Secure = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Limit = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Usage = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.FromEmail = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.btnOnlineCheck = new System.Windows.Forms.Button();
		this.groupBox1.SuspendLayout();
		this.groupBox2.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.ctrlNumPort).BeginInit();
		this.groupBox3.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.gridSMTPs).BeginInit();
		base.SuspendLayout();
		this.groupBox1.Controls.Add(this.btnOnlineCheck);
		this.groupBox1.Controls.Add(this.txtMaxLimit);
		this.groupBox1.Controls.Add(this.label7);
		this.groupBox1.Controls.Add(this.btnCheckIP);
		this.groupBox1.Controls.Add(this.groupBox2);
		this.groupBox1.Controls.Add(this.btnAddSMTP);
		this.groupBox1.Controls.Add(this.btnTest);
		this.groupBox1.Controls.Add(this.ctrlNumPort);
		this.groupBox1.Controls.Add(this.label2);
		this.groupBox1.Controls.Add(this.txtHost);
		this.groupBox1.Controls.Add(this.label1);
		this.groupBox1.Location = new System.Drawing.Point(7, 8);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(670, 231);
		this.groupBox1.TabIndex = 0;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "Add SMTP";
		this.txtMaxLimit.Location = new System.Drawing.Point(557, 20);
		this.txtMaxLimit.Name = "txtMaxLimit";
		this.txtMaxLimit.Size = new System.Drawing.Size(64, 20);
		this.txtMaxLimit.TabIndex = 17;
		this.label7.AutoSize = true;
		this.label7.Location = new System.Drawing.Point(497, 22);
		this.label7.Name = "label7";
		this.label7.Size = new System.Drawing.Size(54, 13);
		this.label7.TabIndex = 18;
		this.label7.Text = "Max Limit:";
		this.btnCheckIP.Image = (System.Drawing.Image)resources.GetObject("btnCheckIP.Image");
		this.btnCheckIP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnCheckIP.Location = new System.Drawing.Point(9, 182);
		this.btnCheckIP.Name = "btnCheckIP";
		this.btnCheckIP.Size = new System.Drawing.Size(111, 38);
		this.btnCheckIP.TabIndex = 9;
		this.btnCheckIP.Text = "   Check Your IP";
		this.btnCheckIP.UseVisualStyleBackColor = true;
		this.btnCheckIP.Click += new System.EventHandler(btnCheckIP_Click);
		this.groupBox2.Controls.Add(this.chkDirectDelivery);
		this.groupBox2.Controls.Add(this.txtToEmail);
		this.groupBox2.Controls.Add(this.label6);
		this.groupBox2.Controls.Add(this.txtFromEmail);
		this.groupBox2.Controls.Add(this.label5);
		this.groupBox2.Controls.Add(this.txtPassword);
		this.groupBox2.Controls.Add(this.label4);
		this.groupBox2.Controls.Add(this.txtUsername);
		this.groupBox2.Controls.Add(this.label3);
		this.groupBox2.Controls.Add(this.chkSSL);
		this.groupBox2.Controls.Add(this.chkAuth);
		this.groupBox2.Location = new System.Drawing.Point(9, 55);
		this.groupBox2.Name = "groupBox2";
		this.groupBox2.Size = new System.Drawing.Size(645, 121);
		this.groupBox2.TabIndex = 7;
		this.groupBox2.TabStop = false;
		this.chkDirectDelivery.AutoSize = true;
		this.chkDirectDelivery.ForeColor = System.Drawing.Color.Blue;
		this.chkDirectDelivery.Location = new System.Drawing.Point(83, 97);
		this.chkDirectDelivery.Name = "chkDirectDelivery";
		this.chkDirectDelivery.Size = new System.Drawing.Size(95, 17);
		this.chkDirectDelivery.TabIndex = 16;
		this.chkDirectDelivery.Text = "Direct Delivery";
		this.chkDirectDelivery.UseVisualStyleBackColor = true;
		this.chkDirectDelivery.CheckedChanged += new System.EventHandler(chkDirectDelivery_CheckedChanged);
		this.txtToEmail.Location = new System.Drawing.Point(421, 31);
		this.txtToEmail.Name = "txtToEmail";
		this.txtToEmail.Size = new System.Drawing.Size(191, 20);
		this.txtToEmail.TabIndex = 14;
		this.label6.AutoSize = true;
		this.label6.Location = new System.Drawing.Point(361, 33);
		this.label6.Name = "label6";
		this.label6.Size = new System.Drawing.Size(48, 13);
		this.label6.TabIndex = 15;
		this.label6.Text = "To Email";
		this.txtFromEmail.Location = new System.Drawing.Point(83, 31);
		this.txtFromEmail.Name = "txtFromEmail";
		this.txtFromEmail.Size = new System.Drawing.Size(191, 20);
		this.txtFromEmail.TabIndex = 12;
		this.label5.AutoSize = true;
		this.label5.Location = new System.Drawing.Point(23, 34);
		this.label5.Name = "label5";
		this.label5.Size = new System.Drawing.Size(58, 13);
		this.label5.TabIndex = 13;
		this.label5.Text = "From Email";
		this.txtPassword.Location = new System.Drawing.Point(421, 63);
		this.txtPassword.Name = "txtPassword";
		this.txtPassword.Size = new System.Drawing.Size(191, 20);
		this.txtPassword.TabIndex = 11;
		this.label4.AutoSize = true;
		this.label4.Location = new System.Drawing.Point(361, 63);
		this.label4.Name = "label4";
		this.label4.Size = new System.Drawing.Size(30, 13);
		this.label4.TabIndex = 10;
		this.label4.Text = "Pass";
		this.txtUsername.Location = new System.Drawing.Point(83, 63);
		this.txtUsername.Name = "txtUsername";
		this.txtUsername.Size = new System.Drawing.Size(191, 20);
		this.txtUsername.TabIndex = 8;
		this.label3.AutoSize = true;
		this.label3.Location = new System.Drawing.Point(25, 63);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(29, 13);
		this.label3.TabIndex = 8;
		this.label3.Text = "User";
		this.chkSSL.AutoSize = true;
		this.chkSSL.Location = new System.Drawing.Point(84, 0);
		this.chkSSL.Name = "chkSSL";
		this.chkSSL.Size = new System.Drawing.Size(77, 17);
		this.chkSSL.TabIndex = 9;
		this.chkSSL.Text = "SSL / TLS";
		this.chkSSL.UseVisualStyleBackColor = true;
		this.chkAuth.AutoSize = true;
		this.chkAuth.Checked = true;
		this.chkAuth.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkAuth.Location = new System.Drawing.Point(25, 0);
		this.chkAuth.Name = "chkAuth";
		this.chkAuth.Size = new System.Drawing.Size(48, 17);
		this.chkAuth.TabIndex = 8;
		this.chkAuth.Text = "Auth";
		this.chkAuth.UseVisualStyleBackColor = true;
		this.btnAddSMTP.Image = (System.Drawing.Image)resources.GetObject("btnAddSMTP.Image");
		this.btnAddSMTP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnAddSMTP.Location = new System.Drawing.Point(232, 182);
		this.btnAddSMTP.Name = "btnAddSMTP";
		this.btnAddSMTP.Size = new System.Drawing.Size(101, 38);
		this.btnAddSMTP.TabIndex = 6;
		this.btnAddSMTP.Text = "Add";
		this.btnAddSMTP.UseVisualStyleBackColor = true;
		this.btnAddSMTP.Click += new System.EventHandler(btnAddSMTP_Click);
		this.btnTest.Image = (System.Drawing.Image)resources.GetObject("btnTest.Image");
		this.btnTest.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnTest.Location = new System.Drawing.Point(126, 182);
		this.btnTest.Name = "btnTest";
		this.btnTest.Size = new System.Drawing.Size(101, 38);
		this.btnTest.TabIndex = 5;
		this.btnTest.Text = "Test SMTP";
		this.btnTest.UseVisualStyleBackColor = true;
		this.btnTest.Click += new System.EventHandler(btnTest_Click);
		this.ctrlNumPort.Location = new System.Drawing.Point(430, 20);
		this.ctrlNumPort.Maximum = new decimal(new int[4] { 9999999, 0, 0, 0 });
		this.ctrlNumPort.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.ctrlNumPort.Name = "ctrlNumPort";
		this.ctrlNumPort.Size = new System.Drawing.Size(58, 20);
		this.ctrlNumPort.TabIndex = 4;
		this.ctrlNumPort.Value = new decimal(new int[4] { 587, 0, 0, 0 });
		this.label2.AutoSize = true;
		this.label2.Location = new System.Drawing.Point(370, 20);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(38, 13);
		this.label2.TabIndex = 3;
		this.label2.Text = "Port  : ";
		this.txtHost.Location = new System.Drawing.Point(92, 19);
		this.txtHost.Name = "txtHost";
		this.txtHost.Size = new System.Drawing.Size(191, 20);
		this.txtHost.TabIndex = 2;
		this.label1.AutoSize = true;
		this.label1.Location = new System.Drawing.Point(31, 20);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(41, 13);
		this.label1.TabIndex = 1;
		this.label1.Text = "Host  : ";
		this.groupBox3.Controls.Add(this.btnClear);
		this.groupBox3.Controls.Add(this.btnDone);
		this.groupBox3.Controls.Add(this.btnRemove);
		this.groupBox3.Controls.Add(this.gridSMTPs);
		this.groupBox3.Location = new System.Drawing.Point(7, 245);
		this.groupBox3.Name = "groupBox3";
		this.groupBox3.Size = new System.Drawing.Size(670, 326);
		this.groupBox3.TabIndex = 8;
		this.groupBox3.TabStop = false;
		this.groupBox3.Text = "SMTP List";
		this.btnClear.Image = (System.Drawing.Image)resources.GetObject("btnClear.Image");
		this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnClear.Location = new System.Drawing.Point(8, 280);
		this.btnClear.Name = "btnClear";
		this.btnClear.Size = new System.Drawing.Size(112, 36);
		this.btnClear.TabIndex = 3;
		this.btnClear.Text = "Clear";
		this.btnClear.UseVisualStyleBackColor = true;
		this.btnClear.Click += new System.EventHandler(button5_Click);
		this.btnDone.Image = (System.Drawing.Image)resources.GetObject("btnDone.Image");
		this.btnDone.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnDone.Location = new System.Drawing.Point(238, 280);
		this.btnDone.Name = "btnDone";
		this.btnDone.Size = new System.Drawing.Size(101, 36);
		this.btnDone.TabIndex = 2;
		this.btnDone.Text = "Done";
		this.btnDone.UseVisualStyleBackColor = true;
		this.btnDone.Click += new System.EventHandler(button4_Click);
		this.btnRemove.Image = (System.Drawing.Image)resources.GetObject("btnRemove.Image");
		this.btnRemove.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnRemove.Location = new System.Drawing.Point(122, 280);
		this.btnRemove.Name = "btnRemove";
		this.btnRemove.Size = new System.Drawing.Size(112, 36);
		this.btnRemove.TabIndex = 1;
		this.btnRemove.Text = "  Remove Row";
		this.btnRemove.UseVisualStyleBackColor = true;
		this.btnRemove.Click += new System.EventHandler(btnRemove_Click);
		this.gridSMTPs.AllowUserToAddRows = false;
		this.gridSMTPs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.gridSMTPs.Columns.AddRange(this.Host, this.Port, this.Username, this.Password, this.Secure, this.Limit, this.Usage, this.FromEmail);
		this.gridSMTPs.Location = new System.Drawing.Point(9, 18);
		this.gridSMTPs.Name = "gridSMTPs";
		this.gridSMTPs.RowHeadersWidth = 51;
		this.gridSMTPs.Size = new System.Drawing.Size(649, 256);
		this.gridSMTPs.TabIndex = 0;
		this.Host.HeaderText = "Host";
		this.Host.MinimumWidth = 6;
		this.Host.Name = "Host";
		this.Host.Width = 125;
		this.Port.HeaderText = "Port";
		this.Port.MinimumWidth = 6;
		this.Port.Name = "Port";
		this.Port.Width = 125;
		this.Username.HeaderText = "Username";
		this.Username.MinimumWidth = 6;
		this.Username.Name = "Username";
		this.Username.Width = 125;
		this.Password.HeaderText = "Password";
		this.Password.MinimumWidth = 6;
		this.Password.Name = "Password";
		this.Password.Width = 125;
		this.Secure.HeaderText = "Secure";
		this.Secure.MinimumWidth = 6;
		this.Secure.Name = "Secure";
		this.Secure.Width = 125;
		this.Limit.HeaderText = "Limit";
		this.Limit.Name = "Limit";
		this.Usage.HeaderText = "Usage";
		this.Usage.Name = "Usage";
		this.FromEmail.HeaderText = "FromEmail";
		this.FromEmail.Name = "FromEmail";
		this.btnOnlineCheck.BackColor = System.Drawing.Color.LimeGreen;
		this.btnOnlineCheck.Cursor = System.Windows.Forms.Cursors.Hand;
		this.btnOnlineCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.btnOnlineCheck.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.btnOnlineCheck.ForeColor = System.Drawing.Color.White;
		this.btnOnlineCheck.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnOnlineCheck.Location = new System.Drawing.Point(548, 182);
		this.btnOnlineCheck.Name = "btnOnlineCheck";
		this.btnOnlineCheck.Size = new System.Drawing.Size(106, 38);
		this.btnOnlineCheck.TabIndex = 20;
		this.btnOnlineCheck.Text = "Check Online";
		this.btnOnlineCheck.UseVisualStyleBackColor = false;
		this.btnOnlineCheck.Click += new System.EventHandler(btnOnlineCheck_Click);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(684, 576);
		base.Controls.Add(this.groupBox3);
		base.Controls.Add(this.groupBox1);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "ManageSMTP";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "HeartSender - Add / Edit SMTP";
		base.Load += new System.EventHandler(ManageSMTP_Load);
		this.groupBox1.ResumeLayout(false);
		this.groupBox1.PerformLayout();
		this.groupBox2.ResumeLayout(false);
		this.groupBox2.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.ctrlNumPort).EndInit();
		this.groupBox3.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.gridSMTPs).EndInit();
		base.ResumeLayout(false);
	}
}
