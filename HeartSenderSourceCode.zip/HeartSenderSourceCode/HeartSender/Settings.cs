using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using CommonSender;

namespace HeartSender;

public class Settings : Form
{
	private Main main;

	private IContainer components;

	public GroupBox groupBox1;

	public Label label1;

	public Label label2;

	public Label label3;

	public Label label4;

	public Label label5;

	public Label label6;

	public ComboBox ctrlBodyTransfer;

	public ComboBox ctrlTextEncoding;

	public NumericUpDown ctrlTimeout;

	public ComboBox ctrlAlternativeView;

	public ComboBox ctrlDeliveryFormat;

	public TextBox txtYourEmail;

	public Label label7;

	public Label label8;

	public Label label9;

	public Label label10;

	public Label label12;

	public ComboBox ctrlFromNameEncoding;

	public ComboBox ctrlLinkEncoding;

	public ComboBox ctrlSubjectEncoding;

	public ComboBox ctrlLetterEncryption;

	public ComboBox ctrlLetterEncoding;

	public Button btnOk;

	public Button btnDone;

	private Label label11;

	private TextBox txtAttachmentName;

	private Label label13;

	private RichTextBox ctrlPreHeader;

	public TextBox txtReplyEmail;

	public Label label14;

	private Label label15;

	private TextBox txtApiKey;

	private GroupBox groupBox2;

	private Label label16;

	private TextBox txtScriptDomain;

	private GroupBox groupBox3;

	private RichTextBox txtIMAPList;

	public Label label17;

	public Label label18;

	private NumericUpDown ctrlIMAPRun;

	public Label label19;

	private CheckBox chkEmailMX;

	private CheckBox chkAllowDuplicate;

	public Button btnTokenReset;

	private CheckBox chkAllowValidate;

	public Settings(Main _main)
	{
		InitializeComponent();
		main = _main;
	}

	private void btnOk_Click(object sender, EventArgs e)
	{
		main.settings[0] = ctrlTimeout.Value.ToString();
		main.settings[1] = ctrlTextEncoding.Text;
		main.settings[2] = ctrlBodyTransfer.Text;
		main.settings[3] = ctrlDeliveryFormat.Text;
		main.settings[4] = ctrlAlternativeView.Text;
		main.settings[5] = txtYourEmail.Text;
		main.settings[24] = txtAttachmentName.Text;
		main.settings[26] = ctrlPreHeader.Text;
		main.settings[27] = txtReplyEmail.Text;
		main.settings[28] = txtApiKey.Text;
		main.settings[29] = txtScriptDomain.Text;
		main.settings[30] = txtIMAPList.Text;
		main.settings[31] = ctrlIMAPRun.Value.ToString();
		main.settings[32] = (chkEmailMX.Checked ? "1" : "0");
		main.settings[33] = (chkAllowDuplicate.Checked ? "1" : "0");
		main.settings[35] = (chkAllowValidate.Checked ? "1" : "0");
		Main.is_validate = main.settings[35];
		Main.sender_email = txtYourEmail.Text;
		if (ctrlLetterEncoding.Text.ToLower() == "no")
		{
			main.settings[6] = "0";
		}
		else if (ctrlLetterEncoding.Text.ToLower() == "base64")
		{
			main.settings[6] = "1";
		}
		else if (ctrlLetterEncoding.Text.ToLower() == "quarted printed")
		{
			main.settings[6] = "2";
		}
		if (ctrlLetterEncryption.Text.ToLower() == "no")
		{
			main.settings[7] = "0";
		}
		else if (ctrlLetterEncryption.Text.ToLower() == "zerofont")
		{
			main.settings[7] = "1";
		}
		else if (ctrlLetterEncryption.Text.ToLower() == "unicode")
		{
			main.settings[7] = "2";
		}
		else if (ctrlLetterEncryption.Text.ToLower() == "dfn")
		{
			main.settings[7] = "3";
		}
		else if (ctrlLetterEncryption.Text.ToLower() == "ascii chars")
		{
			main.settings[7] = "4";
		}
		else if (ctrlLetterEncryption.Text.ToLower() == "zerofont2")
		{
			main.settings[7] = "5";
		}
		else if (ctrlLetterEncryption.Text.ToLower().Trim() == "max zero")
		{
			main.settings[7] = "6";
		}
		else if (ctrlLetterEncryption.Text.ToLower().Trim() == "punny code")
		{
			main.settings[7] = "7";
		}
		else if (ctrlLetterEncryption.Text.ToLower().Trim() == "small font")
		{
			main.settings[7] = "8";
		}
		else if (ctrlLetterEncryption.Text.ToLower().Trim() == "dev encryption")
		{
			main.settings[7] = "9";
		}
		else if (ctrlLetterEncryption.Text.ToLower().Trim() == "cap code")
		{
			main.settings[7] = "10";
		}
		else if (ctrlLetterEncryption.Text.ToLower().Trim() == "max2")
		{
			main.settings[7] = "11";
		}
		else if (ctrlLetterEncryption.Text.ToLower().Trim() == "max3")
		{
			main.settings[7] = "12";
		}
		else if (ctrlLetterEncryption.Text.ToLower().Trim() == "caret code")
		{
			main.settings[7] = "13";
		}
		else if (ctrlLetterEncryption.Text.ToLower().Trim() == "maxcaret")
		{
			main.settings[7] = "14";
		}
		else if (ctrlLetterEncryption.Text.ToLower().Trim() == "arabcode")
		{
			main.settings[7] = "15";
		}
		else if (ctrlLetterEncryption.Text.ToLower().Trim() == "fancycode")
		{
			main.settings[7] = "16";
		}
		else if (ctrlLetterEncryption.Text.ToLower().Trim() == "softcode")
		{
			main.settings[7] = "17";
		}
		else if (ctrlLetterEncryption.Text.ToLower().Trim() == "shortmixer")
		{
			main.settings[7] = "18";
		}
		else if (ctrlLetterEncryption.Text == "ShortMixer2")
		{
			main.settings[7] = "19";
		}
		else if (ctrlLetterEncryption.Text == "Covider")
		{
			main.settings[7] = "20";
		}
		else if (ctrlLetterEncryption.Text == "Fontr")
		{
			main.settings[7] = "21";
		}
		else if (ctrlLetterEncryption.Text == "SuperFontr")
		{
			main.settings[7] = "22";
		}
		else if (ctrlLetterEncryption.Text == "MasterInboxer")
		{
			main.settings[7] = "23";
		}
		else if (ctrlLetterEncryption.Text == "Shipr")
		{
			main.settings[7] = "24";
		}
		else if (ctrlLetterEncryption.Text == "Stylor")
		{
			main.settings[7] = "25";
		}
		if (ctrlSubjectEncoding.Text.ToLower() == "normal")
		{
			main.settings[8] = "0";
		}
		else if (ctrlSubjectEncoding.Text.ToLower() == "base64")
		{
			main.settings[8] = "1";
		}
		else if (ctrlSubjectEncoding.Text.ToLower() == "punny code")
		{
			main.settings[8] = "2";
		}
		else if (ctrlSubjectEncoding.Text.ToLower() == "cap code")
		{
			main.settings[8] = "3";
		}
		else if (ctrlSubjectEncoding.Text.ToLower() == "caret code")
		{
			main.settings[8] = "4";
		}
		if (ctrlLinkEncoding.Text.ToLower() == "normal")
		{
			main.settings[9] = "0";
		}
		else if (ctrlLinkEncoding.Text.ToLower() == "unicode")
		{
			main.settings[9] = "1";
		}
		else if (ctrlLinkEncoding.Text.ToLower() == "url encode")
		{
			main.settings[9] = "2";
		}
		main.settings[10] = ctrlFromNameEncoding.Text;
		if (ctrlFromNameEncoding.Text.ToLower() == "no")
		{
			main.settings[10] = "0";
		}
		else if (ctrlFromNameEncoding.Text.ToLower() == "yes")
		{
			main.settings[10] = "1";
		}
		else if (ctrlFromNameEncoding.Text.ToLower() == "cap code")
		{
			main.settings[10] = "2";
		}
		else if (ctrlFromNameEncoding.Text.ToLower() == "caret code")
		{
			main.settings[10] = "3";
		}
		Close();
	}

	private void btnDone_Click(object sender, EventArgs e)
	{
		Close();
	}

	private void Settings_Load(object sender, EventArgs e)
	{
		if (main.settings[0] != "")
		{
			ctrlTimeout.Value = int.Parse(main.settings[0]);
		}
		if (main.settings[1] != "")
		{
			ctrlTextEncoding.Text = main.settings[1];
		}
		if (main.settings[0] != "")
		{
			ctrlBodyTransfer.Text = main.settings[2];
		}
		if (main.settings[0] != "")
		{
			ctrlDeliveryFormat.Text = main.settings[3];
		}
		if (main.settings[0] != "")
		{
			ctrlAlternativeView.Text = main.settings[4];
		}
		if (main.settings[0] != "")
		{
			txtYourEmail.Text = main.settings[5];
		}
		if (main.settings[6] == "0")
		{
			ctrlLetterEncoding.Text = "No";
		}
		else if (main.settings[6] == "1")
		{
			ctrlLetterEncoding.Text = "Base64";
		}
		else if (main.settings[6] == "2")
		{
			ctrlLetterEncoding.Text = "Quarted Printed";
		}
		if (main.settings[7] == "0")
		{
			ctrlLetterEncryption.Text = "No";
		}
		else if (main.settings[7] == "1")
		{
			ctrlLetterEncryption.Text = "Zerofont";
		}
		else if (main.settings[7] == "2")
		{
			ctrlLetterEncryption.Text = "Unicode";
		}
		else if (main.settings[7] == "3")
		{
			ctrlLetterEncryption.Text = "DFN";
		}
		else if (main.settings[7] == "4")
		{
			ctrlLetterEncryption.Text = "ASCII Chars";
		}
		else if (main.settings[7] == "5")
		{
			ctrlLetterEncryption.Text = "Zerofont2";
		}
		else if (main.settings[7] == "6")
		{
			ctrlLetterEncryption.Text = "Max Zero";
		}
		else if (main.settings[7] == "7")
		{
			ctrlLetterEncryption.Text = "Punny Code";
		}
		else if (main.settings[7] == "8")
		{
			ctrlLetterEncryption.Text = "Small Font";
		}
		else if (main.settings[7] == "9")
		{
			ctrlLetterEncryption.Text = "Dev Encryption";
		}
		else if (main.settings[7] == "10")
		{
			ctrlLetterEncryption.Text = "Cap Code";
		}
		else if (main.settings[7] == "11")
		{
			ctrlLetterEncryption.Text = "Max2";
		}
		else if (main.settings[7] == "12")
		{
			ctrlLetterEncryption.Text = "Max3";
		}
		else if (main.settings[7] == "13")
		{
			ctrlLetterEncryption.Text = "Caret Code";
		}
		else if (main.settings[7] == "14")
		{
			ctrlLetterEncryption.Text = "MaxCaret";
		}
		else if (main.settings[7] == "15")
		{
			ctrlLetterEncryption.Text = "ArabCode";
		}
		else if (main.settings[7] == "16")
		{
			ctrlLetterEncryption.Text = "FancyCode";
		}
		else if (main.settings[7] == "17")
		{
			ctrlLetterEncryption.Text = "SoftCode";
		}
		else if (main.settings[7] == "18")
		{
			ctrlLetterEncryption.Text = "ShortMixer";
		}
		else if (main.settings[7] == "19")
		{
			ctrlLetterEncryption.Text = "ShortMixer2";
		}
		else if (main.settings[7] == "20")
		{
			ctrlLetterEncryption.Text = "Covider";
		}
		else if (main.settings[7] == "21")
		{
			ctrlLetterEncryption.Text = "Fontr";
		}
		else if (main.settings[7] == "22")
		{
			ctrlLetterEncryption.Text = "SuperFontr";
		}
		else if (main.settings[7] == "23")
		{
			ctrlLetterEncryption.Text = "MasterInboxer";
		}
		else if (main.settings[7] == "24")
		{
			ctrlLetterEncryption.Text = "Shipr";
		}
		else if (main.settings[7] == "25")
		{
			ctrlLetterEncryption.Text = "Stylor";
		}
		if (main.settings[8] == "0")
		{
			ctrlSubjectEncoding.Text = "Normal";
		}
		else if (main.settings[8] == "1")
		{
			ctrlSubjectEncoding.Text = "Base64";
		}
		else if (main.settings[8] == "2")
		{
			ctrlSubjectEncoding.Text = "Punny Code";
		}
		else if (main.settings[8] == "3")
		{
			ctrlSubjectEncoding.Text = "Cap Code";
		}
		else if (main.settings[8] == "4")
		{
			ctrlSubjectEncoding.Text = "Caret Code";
		}
		if (main.settings[9] == "0")
		{
			ctrlLinkEncoding.Text = "Normal";
		}
		else if (main.settings[9] == "1")
		{
			ctrlLinkEncoding.Text = "Unicode";
		}
		else if (main.settings[9] == "2")
		{
			ctrlLinkEncoding.Text = "Url Encode";
		}
		if (main.settings[10] == "0")
		{
			ctrlFromNameEncoding.Text = "No";
		}
		else if (ctrlFromNameEncoding.Text.ToLower() == "1")
		{
			ctrlFromNameEncoding.Text = "Yes";
		}
		else if (ctrlFromNameEncoding.Text.ToLower() == "2")
		{
			ctrlFromNameEncoding.Text = "Cap Code";
		}
		else if (ctrlFromNameEncoding.Text.ToLower() == "3")
		{
			ctrlFromNameEncoding.Text = "Caret Code";
		}
		txtAttachmentName.Text = main.settings[24];
		ctrlPreHeader.Text = main.settings[26];
		txtReplyEmail.Text = main.settings[27];
		txtApiKey.Text = main.settings[28];
		txtScriptDomain.Text = main.settings[29];
		txtIMAPList.Text = main.settings[30];
		if (main.settings[31] != "")
		{
			ctrlIMAPRun.Value = int.Parse(main.settings[31]);
		}
		if (main.settings[32] != "")
		{
			chkEmailMX.Checked = int.Parse(main.settings[32]) == 1;
		}
		if (main.settings[33] != "")
		{
			chkAllowDuplicate.Checked = int.Parse(main.settings[33]) == 1;
		}
		if (main.settings[35] != "")
		{
			chkAllowValidate.Checked = int.Parse(main.settings[35]) == 1;
		}
	}

	private void btnTokenReset_Click(object sender, EventArgs e)
	{
		if (MessageBox.Show("Do you want to reset token? \nIt will revoke access on old device!", "HeartSender", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
		{
			string new_token = new GxApi().doResetToken();
			if (new_token.Trim().ToLower() != "101")
			{
				StreamWriter streamWriter = new StreamWriter("license.txt", append: false);
				streamWriter.Write(new_token);
				streamWriter.Close();
				MessageBox.Show("Token successfully updated!", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				Application.Exit();
			}
			else
			{
				MessageBox.Show("Sorry, You are not allowed. \n\rto perform this action!.", "HeartSender", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.Settings));
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.chkAllowDuplicate = new System.Windows.Forms.CheckBox();
		this.txtReplyEmail = new System.Windows.Forms.TextBox();
		this.label14 = new System.Windows.Forms.Label();
		this.label13 = new System.Windows.Forms.Label();
		this.ctrlPreHeader = new System.Windows.Forms.RichTextBox();
		this.label11 = new System.Windows.Forms.Label();
		this.txtAttachmentName = new System.Windows.Forms.TextBox();
		this.ctrlFromNameEncoding = new System.Windows.Forms.ComboBox();
		this.ctrlLinkEncoding = new System.Windows.Forms.ComboBox();
		this.ctrlSubjectEncoding = new System.Windows.Forms.ComboBox();
		this.ctrlLetterEncryption = new System.Windows.Forms.ComboBox();
		this.ctrlLetterEncoding = new System.Windows.Forms.ComboBox();
		this.label12 = new System.Windows.Forms.Label();
		this.label10 = new System.Windows.Forms.Label();
		this.label9 = new System.Windows.Forms.Label();
		this.label8 = new System.Windows.Forms.Label();
		this.label7 = new System.Windows.Forms.Label();
		this.txtYourEmail = new System.Windows.Forms.TextBox();
		this.ctrlAlternativeView = new System.Windows.Forms.ComboBox();
		this.ctrlDeliveryFormat = new System.Windows.Forms.ComboBox();
		this.ctrlBodyTransfer = new System.Windows.Forms.ComboBox();
		this.ctrlTextEncoding = new System.Windows.Forms.ComboBox();
		this.ctrlTimeout = new System.Windows.Forms.NumericUpDown();
		this.label6 = new System.Windows.Forms.Label();
		this.label5 = new System.Windows.Forms.Label();
		this.label4 = new System.Windows.Forms.Label();
		this.label3 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.label1 = new System.Windows.Forms.Label();
		this.chkEmailMX = new System.Windows.Forms.CheckBox();
		this.label15 = new System.Windows.Forms.Label();
		this.txtApiKey = new System.Windows.Forms.TextBox();
		this.btnOk = new System.Windows.Forms.Button();
		this.btnDone = new System.Windows.Forms.Button();
		this.groupBox2 = new System.Windows.Forms.GroupBox();
		this.label16 = new System.Windows.Forms.Label();
		this.txtScriptDomain = new System.Windows.Forms.TextBox();
		this.groupBox3 = new System.Windows.Forms.GroupBox();
		this.label19 = new System.Windows.Forms.Label();
		this.label18 = new System.Windows.Forms.Label();
		this.ctrlIMAPRun = new System.Windows.Forms.NumericUpDown();
		this.label17 = new System.Windows.Forms.Label();
		this.txtIMAPList = new System.Windows.Forms.RichTextBox();
		this.btnTokenReset = new System.Windows.Forms.Button();
		this.chkAllowValidate = new System.Windows.Forms.CheckBox();
		this.groupBox1.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.ctrlTimeout).BeginInit();
		this.groupBox2.SuspendLayout();
		this.groupBox3.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.ctrlIMAPRun).BeginInit();
		base.SuspendLayout();
		this.groupBox1.Controls.Add(this.chkAllowValidate);
		this.groupBox1.Controls.Add(this.chkAllowDuplicate);
		this.groupBox1.Controls.Add(this.txtReplyEmail);
		this.groupBox1.Controls.Add(this.label14);
		this.groupBox1.Controls.Add(this.label13);
		this.groupBox1.Controls.Add(this.ctrlPreHeader);
		this.groupBox1.Controls.Add(this.label11);
		this.groupBox1.Controls.Add(this.txtAttachmentName);
		this.groupBox1.Controls.Add(this.ctrlFromNameEncoding);
		this.groupBox1.Controls.Add(this.ctrlLinkEncoding);
		this.groupBox1.Controls.Add(this.ctrlSubjectEncoding);
		this.groupBox1.Controls.Add(this.ctrlLetterEncryption);
		this.groupBox1.Controls.Add(this.ctrlLetterEncoding);
		this.groupBox1.Controls.Add(this.label12);
		this.groupBox1.Controls.Add(this.label10);
		this.groupBox1.Controls.Add(this.label9);
		this.groupBox1.Controls.Add(this.label8);
		this.groupBox1.Controls.Add(this.label7);
		this.groupBox1.Controls.Add(this.txtYourEmail);
		this.groupBox1.Controls.Add(this.ctrlAlternativeView);
		this.groupBox1.Controls.Add(this.ctrlDeliveryFormat);
		this.groupBox1.Controls.Add(this.ctrlBodyTransfer);
		this.groupBox1.Controls.Add(this.ctrlTextEncoding);
		this.groupBox1.Controls.Add(this.ctrlTimeout);
		this.groupBox1.Controls.Add(this.label6);
		this.groupBox1.Controls.Add(this.label5);
		this.groupBox1.Controls.Add(this.label4);
		this.groupBox1.Controls.Add(this.label3);
		this.groupBox1.Controls.Add(this.label2);
		this.groupBox1.Controls.Add(this.label1);
		this.groupBox1.Controls.Add(this.chkEmailMX);
		this.groupBox1.Location = new System.Drawing.Point(10, 10);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(578, 370);
		this.groupBox1.TabIndex = 0;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "Settings";
		this.chkAllowDuplicate.AutoSize = true;
		this.chkAllowDuplicate.Location = new System.Drawing.Point(439, 245);
		this.chkAllowDuplicate.Name = "chkAllowDuplicate";
		this.chkAllowDuplicate.Size = new System.Drawing.Size(127, 17);
		this.chkAllowDuplicate.TabIndex = 27;
		this.chkAllowDuplicate.Text = "Allow Duplicate Email";
		this.chkAllowDuplicate.UseVisualStyleBackColor = true;
		this.txtReplyEmail.Location = new System.Drawing.Point(439, 211);
		this.txtReplyEmail.Name = "txtReplyEmail";
		this.txtReplyEmail.Size = new System.Drawing.Size(128, 20);
		this.txtReplyEmail.TabIndex = 25;
		this.label14.AutoSize = true;
		this.label14.Location = new System.Drawing.Point(320, 211);
		this.label14.Name = "label14";
		this.label14.Size = new System.Drawing.Size(62, 13);
		this.label14.TabIndex = 24;
		this.label14.Text = "Reply Email";
		this.label13.AutoSize = true;
		this.label13.Location = new System.Drawing.Point(23, 279);
		this.label13.Name = "label13";
		this.label13.Size = new System.Drawing.Size(58, 13);
		this.label13.TabIndex = 23;
		this.label13.Text = "PreHeader";
		this.ctrlPreHeader.Location = new System.Drawing.Point(159, 276);
		this.ctrlPreHeader.Name = "ctrlPreHeader";
		this.ctrlPreHeader.Size = new System.Drawing.Size(408, 57);
		this.ctrlPreHeader.TabIndex = 22;
		this.ctrlPreHeader.Text = "";
		this.label11.AutoSize = true;
		this.label11.Location = new System.Drawing.Point(23, 243);
		this.label11.Name = "label11";
		this.label11.Size = new System.Drawing.Size(92, 13);
		this.label11.TabIndex = 21;
		this.label11.Text = "Attachment Name";
		this.txtAttachmentName.Location = new System.Drawing.Point(159, 243);
		this.txtAttachmentName.Name = "txtAttachmentName";
		this.txtAttachmentName.Size = new System.Drawing.Size(267, 20);
		this.txtAttachmentName.TabIndex = 3;
		this.ctrlFromNameEncoding.FormattingEnabled = true;
		this.ctrlFromNameEncoding.Items.AddRange(new object[4] { "Yes", "No", "Cap Code", "Caret Code" });
		this.ctrlFromNameEncoding.Location = new System.Drawing.Point(439, 179);
		this.ctrlFromNameEncoding.Name = "ctrlFromNameEncoding";
		this.ctrlFromNameEncoding.Size = new System.Drawing.Size(128, 21);
		this.ctrlFromNameEncoding.TabIndex = 20;
		this.ctrlFromNameEncoding.Text = "Yes";
		this.ctrlLinkEncoding.FormattingEnabled = true;
		this.ctrlLinkEncoding.Items.AddRange(new object[3] { "Normal", "Unicode", "Url Encode" });
		this.ctrlLinkEncoding.Location = new System.Drawing.Point(439, 141);
		this.ctrlLinkEncoding.Name = "ctrlLinkEncoding";
		this.ctrlLinkEncoding.Size = new System.Drawing.Size(128, 21);
		this.ctrlLinkEncoding.TabIndex = 18;
		this.ctrlLinkEncoding.Text = "Normal";
		this.ctrlSubjectEncoding.FormattingEnabled = true;
		this.ctrlSubjectEncoding.Items.AddRange(new object[5] { "Normal", "Unicode", "Punny Code", "Cap Code", "Caret Code" });
		this.ctrlSubjectEncoding.Location = new System.Drawing.Point(439, 109);
		this.ctrlSubjectEncoding.Name = "ctrlSubjectEncoding";
		this.ctrlSubjectEncoding.Size = new System.Drawing.Size(128, 21);
		this.ctrlSubjectEncoding.TabIndex = 17;
		this.ctrlSubjectEncoding.Text = "Punny Code";
		this.ctrlLetterEncryption.FormattingEnabled = true;
		this.ctrlLetterEncryption.Items.AddRange(new object[23]
		{
			"No", "ZeroFont", "ZeroFont2", "Max Zero", "Punny Code", "Small Font", "Dev Encryption", "Cap Code", "Max2", "Max3",
			"Caret Code", "MaxCaret", "ArabCode", "FancyCode", "SoftCode", "ShortMixer", "ShortMixer2", "Covider", "Fontr", "SuperFontr",
			"MasterInboxer", "Shipr", "Stylor"
		});
		this.ctrlLetterEncryption.Location = new System.Drawing.Point(439, 76);
		this.ctrlLetterEncryption.Name = "ctrlLetterEncryption";
		this.ctrlLetterEncryption.Size = new System.Drawing.Size(128, 21);
		this.ctrlLetterEncryption.TabIndex = 16;
		this.ctrlLetterEncryption.Text = "No";
		this.ctrlLetterEncoding.FormattingEnabled = true;
		this.ctrlLetterEncoding.Items.AddRange(new object[3] { "No", "Base64", "Quarted Printed" });
		this.ctrlLetterEncoding.Location = new System.Drawing.Point(439, 39);
		this.ctrlLetterEncoding.Name = "ctrlLetterEncoding";
		this.ctrlLetterEncoding.Size = new System.Drawing.Size(128, 21);
		this.ctrlLetterEncoding.TabIndex = 15;
		this.ctrlLetterEncoding.Text = "No";
		this.label12.AutoSize = true;
		this.label12.Location = new System.Drawing.Point(320, 185);
		this.label12.Name = "label12";
		this.label12.Size = new System.Drawing.Size(106, 13);
		this.label12.TabIndex = 13;
		this.label12.Text = "FromName Encoding";
		this.label10.AutoSize = true;
		this.label10.Location = new System.Drawing.Point(320, 144);
		this.label10.Name = "label10";
		this.label10.Size = new System.Drawing.Size(75, 13);
		this.label10.TabIndex = 13;
		this.label10.Text = "Link Encoding";
		this.label9.AutoSize = true;
		this.label9.Location = new System.Drawing.Point(320, 112);
		this.label9.Name = "label9";
		this.label9.Size = new System.Drawing.Size(91, 13);
		this.label9.TabIndex = 14;
		this.label9.Text = "Subject Encoding";
		this.label8.AutoSize = true;
		this.label8.Location = new System.Drawing.Point(320, 79);
		this.label8.Name = "label8";
		this.label8.Size = new System.Drawing.Size(87, 13);
		this.label8.TabIndex = 13;
		this.label8.Text = "Letter Encryption";
		this.label7.AutoSize = true;
		this.label7.Location = new System.Drawing.Point(320, 42);
		this.label7.Name = "label7";
		this.label7.Size = new System.Drawing.Size(82, 13);
		this.label7.TabIndex = 12;
		this.label7.Text = "Letter Encoding";
		this.txtYourEmail.Location = new System.Drawing.Point(159, 211);
		this.txtYourEmail.Name = "txtYourEmail";
		this.txtYourEmail.Size = new System.Drawing.Size(128, 20);
		this.txtYourEmail.TabIndex = 11;
		this.ctrlAlternativeView.FormattingEnabled = true;
		this.ctrlAlternativeView.Items.AddRange(new object[2] { "Yes", "No" });
		this.ctrlAlternativeView.Location = new System.Drawing.Point(159, 177);
		this.ctrlAlternativeView.Name = "ctrlAlternativeView";
		this.ctrlAlternativeView.Size = new System.Drawing.Size(128, 21);
		this.ctrlAlternativeView.TabIndex = 10;
		this.ctrlAlternativeView.Text = "Yes";
		this.ctrlDeliveryFormat.FormattingEnabled = true;
		this.ctrlDeliveryFormat.Items.AddRange(new object[3] { "International", "SevenBit", "None" });
		this.ctrlDeliveryFormat.Location = new System.Drawing.Point(159, 141);
		this.ctrlDeliveryFormat.Name = "ctrlDeliveryFormat";
		this.ctrlDeliveryFormat.Size = new System.Drawing.Size(128, 21);
		this.ctrlDeliveryFormat.TabIndex = 9;
		this.ctrlDeliveryFormat.Text = "None";
		this.ctrlBodyTransfer.FormattingEnabled = true;
		this.ctrlBodyTransfer.Items.AddRange(new object[5] { "Base64", "EightBit", "QuotedPrintable", "SevenBit", "Unknown" });
		this.ctrlBodyTransfer.Location = new System.Drawing.Point(159, 104);
		this.ctrlBodyTransfer.Name = "ctrlBodyTransfer";
		this.ctrlBodyTransfer.Size = new System.Drawing.Size(128, 21);
		this.ctrlBodyTransfer.TabIndex = 8;
		this.ctrlBodyTransfer.Text = "Base64";
		this.ctrlTextEncoding.FormattingEnabled = true;
		this.ctrlTextEncoding.Items.AddRange(new object[7] { "ASCII", "BigEndianUnicode", "Default", "Unicode", "UTF32", "UTF7", "UTF8" });
		this.ctrlTextEncoding.Location = new System.Drawing.Point(159, 71);
		this.ctrlTextEncoding.Name = "ctrlTextEncoding";
		this.ctrlTextEncoding.Size = new System.Drawing.Size(128, 21);
		this.ctrlTextEncoding.TabIndex = 7;
		this.ctrlTextEncoding.Text = "UTF8";
		this.ctrlTimeout.Location = new System.Drawing.Point(159, 39);
		this.ctrlTimeout.Maximum = new decimal(new int[4] { 100000, 0, 0, 0 });
		this.ctrlTimeout.Minimum = new decimal(new int[4] { 5000, 0, 0, 0 });
		this.ctrlTimeout.Name = "ctrlTimeout";
		this.ctrlTimeout.Size = new System.Drawing.Size(128, 20);
		this.ctrlTimeout.TabIndex = 6;
		this.ctrlTimeout.Value = new decimal(new int[4] { 5000, 0, 0, 0 });
		this.label6.AutoSize = true;
		this.label6.Location = new System.Drawing.Point(23, 211);
		this.label6.Name = "label6";
		this.label6.Size = new System.Drawing.Size(57, 13);
		this.label6.TabIndex = 5;
		this.label6.Text = "Your Email";
		this.label5.AutoSize = true;
		this.label5.Location = new System.Drawing.Point(22, 177);
		this.label5.Name = "label5";
		this.label5.Size = new System.Drawing.Size(83, 13);
		this.label5.TabIndex = 4;
		this.label5.Text = "Alternative View";
		this.label4.AutoSize = true;
		this.label4.Location = new System.Drawing.Point(21, 144);
		this.label4.Name = "label4";
		this.label4.Size = new System.Drawing.Size(80, 13);
		this.label4.TabIndex = 3;
		this.label4.Text = "Delivery Format";
		this.label3.AutoSize = true;
		this.label3.Location = new System.Drawing.Point(21, 107);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(121, 13);
		this.label3.TabIndex = 2;
		this.label3.Text = "Body Transfer Encoding";
		this.label2.AutoSize = true;
		this.label2.Location = new System.Drawing.Point(19, 74);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(73, 13);
		this.label2.TabIndex = 1;
		this.label2.Text = "TextEncoding";
		this.label1.AutoSize = true;
		this.label1.Location = new System.Drawing.Point(19, 42);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(69, 13);
		this.label1.TabIndex = 0;
		this.label1.Text = "TimeOut (ms)";
		this.chkEmailMX.AutoSize = true;
		this.chkEmailMX.Checked = true;
		this.chkEmailMX.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkEmailMX.Enabled = false;
		this.chkEmailMX.Location = new System.Drawing.Point(159, 339);
		this.chkEmailMX.Name = "chkEmailMX";
		this.chkEmailMX.Size = new System.Drawing.Size(108, 17);
		this.chkEmailMX.TabIndex = 26;
		this.chkEmailMX.Text = "Send Bug Report";
		this.chkEmailMX.UseVisualStyleBackColor = true;
		this.label15.AutoSize = true;
		this.label15.Location = new System.Drawing.Point(23, 19);
		this.label15.Name = "label15";
		this.label15.Size = new System.Drawing.Size(43, 13);
		this.label15.TabIndex = 27;
		this.label15.Text = "Api Key";
		this.txtApiKey.Location = new System.Drawing.Point(159, 19);
		this.txtApiKey.Name = "txtApiKey";
		this.txtApiKey.Size = new System.Drawing.Size(408, 20);
		this.txtApiKey.TabIndex = 26;
		this.btnOk.Image = (System.Drawing.Image)resources.GetObject("btnOk.Image");
		this.btnOk.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnOk.Location = new System.Drawing.Point(555, 488);
		this.btnOk.Name = "btnOk";
		this.btnOk.Size = new System.Drawing.Size(139, 37);
		this.btnOk.TabIndex = 1;
		this.btnOk.Text = "Save";
		this.btnOk.UseVisualStyleBackColor = true;
		this.btnOk.Click += new System.EventHandler(btnOk_Click);
		this.btnDone.Image = (System.Drawing.Image)resources.GetObject("btnDone.Image");
		this.btnDone.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnDone.Location = new System.Drawing.Point(707, 488);
		this.btnDone.Name = "btnDone";
		this.btnDone.Size = new System.Drawing.Size(139, 37);
		this.btnDone.TabIndex = 2;
		this.btnDone.Text = "Ok";
		this.btnDone.UseVisualStyleBackColor = true;
		this.btnDone.Click += new System.EventHandler(btnDone_Click);
		this.groupBox2.Controls.Add(this.label16);
		this.groupBox2.Controls.Add(this.txtScriptDomain);
		this.groupBox2.Controls.Add(this.label15);
		this.groupBox2.Controls.Add(this.txtApiKey);
		this.groupBox2.Location = new System.Drawing.Point(10, 386);
		this.groupBox2.Name = "groupBox2";
		this.groupBox2.Size = new System.Drawing.Size(578, 95);
		this.groupBox2.TabIndex = 3;
		this.groupBox2.TabStop = false;
		this.groupBox2.Text = "Script";
		this.label16.AutoSize = true;
		this.label16.Location = new System.Drawing.Point(23, 49);
		this.label16.Name = "label16";
		this.label16.Size = new System.Drawing.Size(43, 13);
		this.label16.TabIndex = 29;
		this.label16.Text = "Domain";
		this.txtScriptDomain.Location = new System.Drawing.Point(159, 49);
		this.txtScriptDomain.Name = "txtScriptDomain";
		this.txtScriptDomain.Size = new System.Drawing.Size(408, 20);
		this.txtScriptDomain.TabIndex = 28;
		this.groupBox3.Controls.Add(this.label19);
		this.groupBox3.Controls.Add(this.label18);
		this.groupBox3.Controls.Add(this.ctrlIMAPRun);
		this.groupBox3.Controls.Add(this.label17);
		this.groupBox3.Controls.Add(this.txtIMAPList);
		this.groupBox3.Location = new System.Drawing.Point(594, 10);
		this.groupBox3.Name = "groupBox3";
		this.groupBox3.Size = new System.Drawing.Size(252, 471);
		this.groupBox3.TabIndex = 4;
		this.groupBox3.TabStop = false;
		this.groupBox3.Text = "IMAP Settings";
		this.label19.AutoSize = true;
		this.label19.Location = new System.Drawing.Point(215, 446);
		this.label19.Name = "label19";
		this.label19.Size = new System.Drawing.Size(31, 13);
		this.label19.TabIndex = 28;
		this.label19.Text = "mins.";
		this.label18.AutoSize = true;
		this.label18.Location = new System.Drawing.Point(3, 446);
		this.label18.Name = "label18";
		this.label18.Size = new System.Drawing.Size(60, 13);
		this.label18.TabIndex = 26;
		this.label18.Text = "Run Every:";
		this.ctrlIMAPRun.Increment = new decimal(new int[4] { 5, 0, 0, 0 });
		this.ctrlIMAPRun.Location = new System.Drawing.Point(150, 442);
		this.ctrlIMAPRun.Maximum = new decimal(new int[4] { 500, 0, 0, 0 });
		this.ctrlIMAPRun.Minimum = new decimal(new int[4] { 10, 0, 0, 0 });
		this.ctrlIMAPRun.Name = "ctrlIMAPRun";
		this.ctrlIMAPRun.Size = new System.Drawing.Size(59, 20);
		this.ctrlIMAPRun.TabIndex = 27;
		this.ctrlIMAPRun.Value = new decimal(new int[4] { 10, 0, 0, 0 });
		this.label17.AutoSize = true;
		this.label17.Location = new System.Drawing.Point(4, 23);
		this.label17.Name = "label17";
		this.label17.Size = new System.Drawing.Size(148, 13);
		this.label17.TabIndex = 26;
		this.label17.Text = "Enter Comma Separated Title:";
		this.txtIMAPList.Location = new System.Drawing.Point(6, 39);
		this.txtIMAPList.Name = "txtIMAPList";
		this.txtIMAPList.Size = new System.Drawing.Size(240, 397);
		this.txtIMAPList.TabIndex = 5;
		this.txtIMAPList.Text = "";
		this.btnTokenReset.Image = (System.Drawing.Image)resources.GetObject("btnTokenReset.Image");
		this.btnTokenReset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnTokenReset.Location = new System.Drawing.Point(10, 488);
		this.btnTokenReset.Name = "btnTokenReset";
		this.btnTokenReset.Size = new System.Drawing.Size(139, 37);
		this.btnTokenReset.TabIndex = 5;
		this.btnTokenReset.Text = "Reset Token?";
		this.btnTokenReset.UseVisualStyleBackColor = true;
		this.btnTokenReset.Click += new System.EventHandler(btnTokenReset_Click);
		this.chkAllowValidate.AutoSize = true;
		this.chkAllowValidate.Location = new System.Drawing.Point(273, 339);
		this.chkAllowValidate.Name = "chkAllowValidate";
		this.chkAllowValidate.Size = new System.Drawing.Size(120, 17);
		this.chkAllowValidate.TabIndex = 28;
		this.chkAllowValidate.Text = "Allow Validate Email";
		this.chkAllowValidate.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(858, 533);
		base.Controls.Add(this.btnTokenReset);
		base.Controls.Add(this.groupBox3);
		base.Controls.Add(this.groupBox2);
		base.Controls.Add(this.btnDone);
		base.Controls.Add(this.btnOk);
		base.Controls.Add(this.groupBox1);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "Settings";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Additional Settings";
		base.Load += new System.EventHandler(Settings_Load);
		this.groupBox1.ResumeLayout(false);
		this.groupBox1.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.ctrlTimeout).EndInit();
		this.groupBox2.ResumeLayout(false);
		this.groupBox2.PerformLayout();
		this.groupBox3.ResumeLayout(false);
		this.groupBox3.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.ctrlIMAPRun).EndInit();
		base.ResumeLayout(false);
	}
}
