using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace HeartSender;

public class DomainLinks : Form
{
	private string[] list;

	private Main main;

	private IContainer components;

	private GroupBox groupBox1;

	private RichTextBox ctrlLinks;

	private Button btnSave;

	public DomainLinks(Main _main)
	{
		InitializeComponent();
		main = _main;
	}

	private void btnSave_Click(object sender, EventArgs e)
	{
		list = ctrlLinks.Text.Trim().Split(new string[3] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
		Main.populateLinksList(list, main);
		Close();
	}

	private void DomainLinks_Load(object sender, EventArgs e)
	{
		foreach (string link in Main.links)
		{
			ctrlLinks.Text += link;
			ctrlLinks.Text += "\n";
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.DomainLinks));
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.ctrlLinks = new System.Windows.Forms.RichTextBox();
		this.btnSave = new System.Windows.Forms.Button();
		this.groupBox1.SuspendLayout();
		base.SuspendLayout();
		this.groupBox1.Controls.Add(this.ctrlLinks);
		this.groupBox1.Location = new System.Drawing.Point(12, 9);
		this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
		this.groupBox1.Size = new System.Drawing.Size(353, 332);
		this.groupBox1.TabIndex = 0;
		this.groupBox1.TabStop = false;
		this.ctrlLinks.Location = new System.Drawing.Point(7, 14);
		this.ctrlLinks.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
		this.ctrlLinks.Name = "ctrlLinks";
		this.ctrlLinks.Size = new System.Drawing.Size(337, 312);
		this.ctrlLinks.TabIndex = 0;
		this.ctrlLinks.Text = "";
		this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.btnSave.Image = (System.Drawing.Image)resources.GetObject("btnSave.Image");
		this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnSave.Location = new System.Drawing.Point(257, 348);
		this.btnSave.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
		this.btnSave.Name = "btnSave";
		this.btnSave.Size = new System.Drawing.Size(109, 43);
		this.btnSave.TabIndex = 1;
		this.btnSave.Text = "Save";
		this.btnSave.UseVisualStyleBackColor = true;
		this.btnSave.Click += new System.EventHandler(btnSave_Click);
		base.AutoScaleDimensions = new System.Drawing.SizeF(8f, 16f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(376, 405);
		base.Controls.Add(this.btnSave);
		base.Controls.Add(this.groupBox1);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "DomainLinks";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Add Links";
		base.Load += new System.EventHandler(DomainLinks_Load);
		this.groupBox1.ResumeLayout(false);
		base.ResumeLayout(false);
	}
}
