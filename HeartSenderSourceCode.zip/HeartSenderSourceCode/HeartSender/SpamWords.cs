using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace HeartSender;

public class SpamWords : Form
{
	private string[] list;

	private Main main;

	private IContainer components;

	private GroupBox groupBox1;

	private RichTextBox ctrlSpamWords;

	private Button btnSave;

	public SpamWords(Main _main)
	{
		InitializeComponent();
		main = _main;
	}

	private void btnSave_Click(object sender, EventArgs e)
	{
		list = ctrlSpamWords.Text.Trim().Split(new string[3] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
		Main.populateSpamWordsList(list, main);
		main.settings[34] = string.Join(",", Main.spamwords);
		Close();
	}

	private void SpamWords_Load(object sender, EventArgs e)
	{
		Main.spamwords = Main.spamwords.Distinct().ToList();
		foreach (string link in Main.spamwords)
		{
			ctrlSpamWords.Text += link;
			ctrlSpamWords.Text += "\n";
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeartSender.SpamWords));
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.ctrlSpamWords = new System.Windows.Forms.RichTextBox();
		this.btnSave = new System.Windows.Forms.Button();
		this.groupBox1.SuspendLayout();
		base.SuspendLayout();
		this.groupBox1.Controls.Add(this.ctrlSpamWords);
		this.groupBox1.Location = new System.Drawing.Point(4, 2);
		this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
		this.groupBox1.Size = new System.Drawing.Size(353, 460);
		this.groupBox1.TabIndex = 1;
		this.groupBox1.TabStop = false;
		this.ctrlSpamWords.Location = new System.Drawing.Point(7, 14);
		this.ctrlSpamWords.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
		this.ctrlSpamWords.Name = "ctrlSpamWords";
		this.ctrlSpamWords.Size = new System.Drawing.Size(337, 438);
		this.ctrlSpamWords.TabIndex = 0;
		this.ctrlSpamWords.Text = "";
		this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.btnSave.Image = (System.Drawing.Image)resources.GetObject("btnSave.Image");
		this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.btnSave.Location = new System.Drawing.Point(250, 470);
		this.btnSave.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
		this.btnSave.Name = "btnSave";
		this.btnSave.Size = new System.Drawing.Size(108, 43);
		this.btnSave.TabIndex = 2;
		this.btnSave.Text = "Save";
		this.btnSave.UseVisualStyleBackColor = true;
		this.btnSave.Click += new System.EventHandler(btnSave_Click);
		base.AutoScaleDimensions = new System.Drawing.SizeF(8f, 16f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(363, 521);
		base.Controls.Add(this.btnSave);
		base.Controls.Add(this.groupBox1);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "SpamWords";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Spam Words";
		base.Load += new System.EventHandler(SpamWords_Load);
		this.groupBox1.ResumeLayout(false);
		base.ResumeLayout(false);
	}
}
