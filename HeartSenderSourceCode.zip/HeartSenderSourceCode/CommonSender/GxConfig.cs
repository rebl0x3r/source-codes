using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace CommonSender;

[Serializable]
public class GxConfig
{
	public int priority;

	public int user_random;

	public int using_tag;

	public int using_attachment;

	public string name_attachment;

	public int email_countsend;

	public int sending_delay;

	public int masking;

	public string date;

	public int letter_encrypt;

	public int letter_encode;

	public int subject_encode;

	public int link_encode;

	public int image_encode;

	public string list_email;

	public string letter;

	public string file_attachment;

	public string target_email_name;

	public int use_reply_email;

	public string reply_email;

	public string reply_email_name;

	public string from_name;

	public string subject;

	public string from_email;

	public string spam_words;

	public List<GxSMTP> smtp;

	public List<string> links;

	public List<string> socks;

	public List<string> shells;

	public bool is_valid;

	public string template;

	public int confirmed_email;

	public int failed_email;

	public int mail_limit;

	public int fromname_encode;

	public int remove_email;

	public int verify_email;

	public string text_encoding;

	public string btencoding;

	public string smtpdf;

	public string preheader;

	public string replyEmail;

	public string api_key = "";

	public string api_domain = "";

	public string imap_keywords = "";

	public double imap_time = 60.0;

	public bool enable_duplicate;

	public bool enable_validate_email = true;

	public GxConfig()
	{
		is_valid = false;
		smtp = new List<GxSMTP>();
		links = new List<string>();
		socks = new List<string>();
	}

	public bool validate()
	{
		if (hasSmtp())
		{
			return true;
		}
		return false;
	}

	public bool hasEmailList()
	{
		if (list_email == "" || list_email == null || !File.Exists(getBasePath() + list_email))
		{
			return false;
		}
		return true;
	}

	public bool hasEmailTemplate()
	{
		if (letter == "" || letter == null || !File.Exists(getBasePath() + letter))
		{
			return false;
		}
		return true;
	}

	public bool hasSmtp()
	{
		if (smtp.Count == 0)
		{
			return false;
		}
		return true;
	}

	public bool hasFromName()
	{
		if (from_name == "" || from_name == null)
		{
			return false;
		}
		return true;
	}

	public bool hasSubject()
	{
		if (subject == "" || subject == null)
		{
			return false;
		}
		return true;
	}

	public static string getBasePath()
	{
		return "";
	}

	public static string strTruncate(string value, int maxLength)
	{
		if (string.IsNullOrEmpty(value))
		{
			return value;
		}
		if (value.Length > maxLength)
		{
			return value.Substring(0, maxLength);
		}
		return value;
	}

	public static string baseUrl()
	{
		return GxLogger.getBaseUrl();
	}

	public static string solutionName()
	{
		return GxLogger.getName();
	}

	public static string toBase64(string str)
	{
		return Convert.ToBase64String(Encoding.UTF8.GetBytes(str));
	}

	public static string strEncode(string str)
	{
		return Convert.ToBase64String(Encoding.UTF8.GetBytes(str));
	}

	public static string strDecode(string str)
	{
		return Encoding.UTF8.GetString(Convert.FromBase64String(str));
	}
}
