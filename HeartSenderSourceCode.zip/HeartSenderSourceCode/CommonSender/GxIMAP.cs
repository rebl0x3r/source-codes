using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using HeartSender;
using MailKit;
using MailKit.Net.Imap;
using MimeKit;

namespace CommonSender;

[Serializable]
public class GxIMAP
{
	private Main _main;

	private IMAP _imap;

	public List<string> emails = new List<string>();

	public GxIMAP(Main m, IMAP p)
	{
		_main = m;
		_imap = p;
		emails = new List<string>();
	}

	public void execute(GxIMAPAccount account, BackgroundWorker worker_job)
	{
		Main.imap_emails.Clear();
		using ImapClient c = new ImapClient();
		try
		{
			c.Connect(account.server_name, account.port, account.is_ssl);
			c.AuthenticationMechanisms.Remove("XOAUTH2");
			c.Authenticate(account.username, account.password);
			IMailFolder inbox = c.Inbox;
			inbox.Open(FolderAccess.ReadWrite);
			IList<IMessageSummary> list = inbox.Fetch(0, account.limit - 1, MessageSummaryItems.Flags | MessageSummaryItems.Size | MessageSummaryItems.UniqueId);
			int counter = 0;
			foreach (IMessageSummary summary in list)
			{
				MimeMessage i = c.Inbox.GetMessage(summary.UniqueId);
				string wholeMessage = i.Subject + "\n" + i.Bcc?.ToString() + "\n" + i.Body?.ToString() + "\n" + i.From?.ToString() + "\n" + i.To;
				string[] array = removeDuplicates(extractEmails(wholeMessage));
				new DataGridViewRow();
				string[] array2 = array;
				foreach (string email in array2)
				{
					if (counter > account.limit)
					{
						break;
					}
					emails.Add(email);
					Main.imap_emails.Add(email);
					worker_job.ReportProgress(1, email);
					counter++;
				}
				if (counter > account.limit)
				{
					break;
				}
			}
		}
		catch (Exception e)
		{
			Console.WriteLine("ERROR :: " + e.Message.ToString());
		}
	}

	public string[] extractEmails(string data)
	{
		MatchCollection matchCollection = new Regex("\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*", RegexOptions.IgnoreCase).Matches(data);
		StringBuilder sb = new StringBuilder();
		foreach (Match emailMatch in matchCollection)
		{
			sb.AppendLine(emailMatch.Value);
		}
		return sb.ToString().Split('\n');
	}

	public string[] removeDuplicates(string[] s)
	{
		HashSet<string> hashSet = new HashSet<string>(s);
		string[] result = new string[hashSet.Count];
		hashSet.CopyTo(result);
		return result.Where((string e) => !string.IsNullOrEmpty(e)).ToArray();
	}
}
