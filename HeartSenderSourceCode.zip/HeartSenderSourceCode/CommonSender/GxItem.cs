using System;

namespace CommonSender;

[Serializable]
public class GxItem
{
	public string email;

	public string firstname;

	public string lastname;

	public string subject;

	public string from_name;

	public string message;

	public string attachment;

	public int counter;

	public GxConfig config;

	public string log;

	public string time;

	public bool is_sent;

	public string reply_email_name;

	public string target_email_name;

	public string reply_email;

	public string from_email;

	public string shell_url;

	public string letter;

	public string[] headers;

	public int smtp_index = -1;

	public bool error_handling;

	public int progress_count;

	public int sending_delay;

	public GxItem()
	{
		log = "";
		reply_email_name = "";
		target_email_name = "";
	}
}
