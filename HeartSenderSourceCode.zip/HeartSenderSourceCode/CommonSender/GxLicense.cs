using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Text.RegularExpressions;

namespace CommonSender;

[Serializable]
public class GxLicense
{
	private string license_path = "";

	private string license_verison = "1.0";

	private string contact_email = "softwarecodertools@gmail.com";

	public static string message = "";

	public GxLicense()
	{
		license_path = GxConfig.getBasePath() + "license.txt";
	}

	public string getVersion()
	{
		return license_verison;
	}

	public string getContactEmail()
	{
		return contact_email;
	}

	public string getLicenseToken()
	{
		return File.ReadAllText(license_path).Trim();
	}

	public string[] validLicense()
	{
		if (!File.Exists(license_path))
		{
			GxLogger.writeLog("License File => Doesn't exist");
			return new string[2] { "404", "Sorry, couldn't find license token." };
		}
		string license = File.ReadAllText(license_path).Trim();
		if (!validate(license))
		{
			return new string[2] { "404", message };
		}
		return new string[2] { "200", "License validated!!!" };
	}

	public void SetSystemTimeZone(string timeZoneId)
	{
		Process process = Process.Start(new ProcessStartInfo
		{
			FileName = "tzutil.exe",
			Arguments = "/s \"" + timeZoneId + "\"",
			UseShellExecute = false,
			CreateNoWindow = true
		});
		if (process != null)
		{
			process.WaitForExit();
			TimeZoneInfo.ClearCachedData();
		}
	}

	private bool validate(string key)
	{
		SetSystemTimeZone("GMT Standard Time");
		long time = ((DateTimeOffset)TimeZone.CurrentTimeZone.ToLocalTime(DateTime.Now)).ToUnixTimeSeconds();
		string request_code = getUniqCode(time.ToString());
		string response = doGetCall(key, request_code);
		if (response != "-1" && response != "-2" && response != "-3")
		{
			long num = codeToInt(response);
			time = Math.Abs(num - time) + 1;
			if (num != 0L && time <= 432000 && time >= 0)
			{
				GxLogger.writeLog("License => Success");
				return true;
			}
			message = "Sorry, your license is not valid!";
		}
		else
		{
			switch (response)
			{
			case "-1":
				message = " Your License Locked\n Reason: Multipal Devices.\n Contact With Seller For Reset ";
				break;
			case "-2":
				message = "Sorry, your request is incorrect.";
				break;
			case "-3":
				message = "You are using older version. Please upgrade!";
				break;
			}
		}
		GxLogger.writeLog("License => Failed");
		return false;
	}

	public string getMacAddress()
	{
		string macAddress = string.Empty;
		long maxSpeed = -1L;
		NetworkInterface[] allNetworkInterfaces = NetworkInterface.GetAllNetworkInterfaces();
		foreach (NetworkInterface nic in allNetworkInterfaces)
		{
			string tempMac = nic.GetPhysicalAddress().ToString();
			if (nic.Speed > maxSpeed && !string.IsNullOrEmpty(tempMac) && tempMac.Length >= 12)
			{
				maxSpeed = nic.Speed;
				macAddress = tempMac;
			}
		}
		GxLogger.writeLog("C => " + macAddress);
		return macAddress;
	}

	public string doGetCall(string token, string code)
	{
		try
		{
			GxHardware hardware = new GxHardware();
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create(GxConfig.baseUrl() + "api/validate?t=" + GxConfig.toBase64(getMacAddress()) + "&k=" + token + "&c=" + code + "&ss=hv3&p1=" + GxConfig.toBase64(hardware.getMotherboard()) + "&p2=" + GxConfig.toBase64(hardware.getBIOS()) + "&p3=" + GxConfig.toBase64(hardware.getCPU()) + "&v=" + GxLogger.getVersionNumber());
			obj.Method = "GET";
			HttpWebResponse obj2 = (HttpWebResponse)obj.GetResponse();
			string result = new StreamReader(encoding: Encoding.GetEncoding("utf-8"), stream: obj2.GetResponseStream()).ReadToEnd();
			GxLogger.writeLog("Response => " + result);
			obj2.Close();
			return result;
		}
		catch (Exception)
		{
			return "404";
		}
	}

	public string getUniqCode(string time)
	{
		time = GxConfig.strEncode(time);
		List<string> groups = (from Match m in Regex.Matches(time.Trim(), "[\\s\\S]{1,4}")
			select m.Value).ToList();
		char[] chars = (groups[2] + groups[0] + groups[3] + groups[1]).ToCharArray();
		int num = new Random().Next(1, 9);
		int indx = 0;
		char[] array = chars;
		foreach (char c in array)
		{
			if (indx % 2 == 0)
			{
				chars[indx] = (char)(c + num);
			}
			else
			{
				chars[indx] = (char)(c - num);
			}
			indx++;
		}
		string uniq_code = GxConfig.strEncode(string.Join("", chars) + GxConfig.strEncode(num.ToString()) + "gL" + GxConfig.strEncode(num.ToString()).Length);
		groups.Clear();
		string final_code = "";
		if (uniq_code.Length % 2 == 0)
		{
			final_code = uniq_code.PadRight(36, '=');
			groups = (from Match m in Regex.Matches(final_code.Trim(), "[\\s\\S]{0," + final_code.Length / 6 + "}")
				select m.Value).ToList();
			return groups[3] + groups[0] + groups[4] + uniq_code.Length.ToString().PadLeft(2, '0') + groups[1] + groups[2] + groups[5];
		}
		final_code = uniq_code.PadRight(25, '=');
		groups = (from Match m in Regex.Matches(final_code.Trim(), "[\\s\\S]{1," + final_code.Length / 5 + "}")
			select m.Value).ToList();
		return groups[2] + groups[0] + groups[3] + uniq_code.Length.ToString().PadLeft(2, '0') + groups[1] + groups[4];
	}

	public long codeToInt(string code)
	{
		string len = "";
		string uniq_code = "";
		if (code.Length < 25)
		{
			return 0L;
		}
		List<string> groups;
		if (code.Length % 2 == 0)
		{
			len = code.Substring(18, 2);
			uniq_code = code.Substring(0, 18) + code.Substring(20);
			groups = (from Match m in Regex.Matches(uniq_code.Trim(), "[\\s\\S]{1,6}")
				select m.Value).ToList();
			uniq_code = groups[1] + groups[3] + groups[4] + groups[0] + groups[2] + groups[5];
		}
		else
		{
			len = code.Substring(15, 2);
			uniq_code = code.Substring(0, 15) + code.Substring(17);
			groups = (from Match m in Regex.Matches(uniq_code.Trim(), "[\\s\\S]{1,5}")
				select m.Value).ToList();
			uniq_code = groups[1] + groups[3] + groups[0] + groups[2] + groups[4];
		}
		uniq_code = uniq_code.Substring(0, int.Parse(len));
		uniq_code = GxConfig.strDecode(uniq_code);
		string[] tokens = uniq_code.Split(new string[1] { "gL" }, StringSplitOptions.None);
		len = tokens[1];
		int random_number = int.Parse(GxConfig.strDecode(tokens[0].Substring(tokens[0].Length - int.Parse(len))));
		uniq_code = tokens[0].Substring(0, tokens[0].Length - int.Parse(len));
		char[] chars = uniq_code.ToCharArray();
		for (int i = 0; i < chars.Length; i++)
		{
			if (i % 2 == 0)
			{
				chars[i] = (char)(chars[i] - random_number);
			}
			else
			{
				chars[i] = (char)(chars[i] + random_number);
			}
		}
		uniq_code = string.Join("", chars);
		groups.Clear();
		groups = (from Match m in Regex.Matches(uniq_code.Trim(), "[\\s\\S]{1,4}")
			select m.Value).ToList();
		uniq_code = groups[1] + groups[3] + groups[0] + groups[2];
		uniq_code = GxConfig.strDecode(uniq_code);
		long num = 0L;
		if (long.TryParse(uniq_code, out num))
		{
			return long.Parse(uniq_code);
		}
		return 0L;
	}

	public bool checkProxy(string code)
	{
		try
		{
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create("http://api.heartsender.com/api/check?t=" + GxConfig.toBase64(code));
			obj.Method = "GET";
			HttpWebResponse webresponse = (HttpWebResponse)obj.GetResponse();
			Encoding enc = Encoding.GetEncoding("utf-8");
			string text = new StreamReader(webresponse.GetResponseStream(), enc).ReadToEnd();
			webresponse.Close();
			return text.Trim() == "1";
		}
		catch (Exception)
		{
			return false;
		}
	}
}
