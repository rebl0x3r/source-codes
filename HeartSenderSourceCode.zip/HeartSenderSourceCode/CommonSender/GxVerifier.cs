using System;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CommonSender;

public class GxVerifier
{
	public class EmailResult
	{
		public string Success { get; set; }

		public string Email { get; set; }

		public string Valid { get; set; }

		public string Status { get; set; }

		public string SMTPResult { get; set; }

		public string SMTPCode { get; set; }

		public string Transaction { get; set; }
	}

	public class EmailVal
	{
		public bool smtp_check { get; set; }
	}

	public int execute(string email)
	{
		try
		{
			string url = "https://gsuite.tools/verify-email?email=" + email + "&mail_from=info%40mail.com";
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create(url);
			obj.Headers["authority"] = "gsuite.tools";
			obj.Headers["upgrade-insecure-requests"] = "1";
			obj.UserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36";
			obj.Headers["sec-fetch-mode"] = "navigate";
			obj.Headers["sec-fetch-user"] = "?1";
			obj.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3";
			obj.Headers["sec-fetch-site"] = "same-origin";
			obj.Referer = url;
			obj.Headers["accept-language"] = "en-GB,en-US;q=0.9,en;q=0.8";
			obj.Headers["cookie"] = "cf_clearance=a47a86a8dc98c39b75f7506c898fb9a15005302e-1580807948-0-150; __cfduid=d8190450e0926775d83446c249b058aae1580807948; _ga=GA1.2.1765737347.1580807951; _gid=GA1.2.1561512301.1580807951; _gat=1; cookieconsent_dismissed=yes";
			obj.Method = "GET";
			HttpWebResponse webresponse = (HttpWebResponse)obj.GetResponse();
			Encoding enc = Encoding.GetEncoding("utf-8");
			string input = new StreamReader(webresponse.GetResponseStream(), enc).ReadToEnd();
			webresponse.Close();
			return Regex.IsMatch(input, "\\&\\#10003\\;\\s+VALID\\s+EMAIL\\s+ADDRESS\\s+\\&\\#10003\\;|250.*recipient\\s+ok", RegexOptions.IgnoreCase) ? 1 : 0;
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
			return -1;
		}
	}
}
