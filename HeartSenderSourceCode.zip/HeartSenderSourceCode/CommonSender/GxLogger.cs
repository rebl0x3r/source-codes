using System;

namespace CommonSender;

[Serializable]
public class GxLogger
{
	public static string getVersionNumber()
	{
		return "3.00.33";
	}

	public void toLogger(string[] parameters, bool append = false)
	{
	}

	public static void writeLog(string str, bool is_append = true)
	{
		_ = GxConfig.getBasePath() + "data.log";
	}

	public static string getName()
	{
		return "HeartSenderV3";
	}

	public static string getBaseUrl()
	{
		return "http://mrcodertools.com/web/";
	}
}
