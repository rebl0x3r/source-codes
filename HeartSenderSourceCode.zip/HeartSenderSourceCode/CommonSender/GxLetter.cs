namespace CommonSender;

public class GxLetter
{
	public string name;

	public string letter;

	public string attachment;

	public bool is_html;

	public bool is_enable;

	public string attachment_tags;

	public string fromname;

	public string[] fromemail;

	public string subject;
}
