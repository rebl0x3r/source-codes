using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using HeartSender;

namespace CommonSender;

public class GxApi
{
	public string doResetToken()
	{
		try
		{
			GxLicense license = new GxLicense();
			license.SetSystemTimeZone("GMT Standard Time");
			string request_code = license.getUniqCode(((DateTimeOffset)TimeZone.CurrentTimeZone.ToLocalTime(DateTime.Now)).ToUnixTimeSeconds().ToString());
			string token = license.getLicenseToken() + "-=:::::=-" + request_code + "-=:::::=-" + license.getMacAddress();
			HttpWebRequest request = (HttpWebRequest)WebRequest.Create(GxConfig.baseUrl() + "backend/reset-token");
			string postData = "data=" + GxConfig.toBase64(token);
			byte[] data = Encoding.UTF8.GetBytes(postData);
			request.Method = "POST";
			request.ContentType = "application/x-www-form-urlencoded; charset=utf-8";
			request.ContentLength = data.Length;
			using (Stream stream = request.GetRequestStream())
			{
				stream.Write(data, 0, data.Length);
			}
			HttpWebResponse webresponse = (HttpWebResponse)request.GetResponse();
			Encoding enc = Encoding.GetEncoding("utf-8");
			string text = new StreamReader(webresponse.GetResponseStream(), enc).ReadToEnd();
			webresponse.Close();
			return text.ToString().Trim().Replace(" ", "+");
		}
		catch (Exception)
		{
			return "101";
		}
	}

	public string getHeaders()
	{
		try
		{
			GxLicense license = new GxLicense();
			license.SetSystemTimeZone("GMT Standard Time");
			string request_code = license.getUniqCode(((DateTimeOffset)TimeZone.CurrentTimeZone.ToLocalTime(DateTime.Now)).ToUnixTimeSeconds().ToString());
			string token = license.getLicenseToken() + "-=:::::=-" + request_code + "-=:::::=-" + license.getMacAddress();
			HttpWebRequest request = (HttpWebRequest)WebRequest.Create(GxConfig.baseUrl() + "backend/get-headers");
			string postData = "data=" + GxConfig.toBase64(token);
			byte[] data = Encoding.UTF8.GetBytes(postData);
			request.Method = "POST";
			request.ContentType = "application/x-www-form-urlencoded; charset=utf-8";
			request.ContentLength = data.Length;
			using (Stream stream = request.GetRequestStream())
			{
				stream.Write(data, 0, data.Length);
			}
			HttpWebResponse webresponse = (HttpWebResponse)request.GetResponse();
			Encoding enc = Encoding.GetEncoding("utf-8");
			string text = new StreamReader(webresponse.GetResponseStream(), enc).ReadToEnd();
			webresponse.Close();
			return text.ToString().Trim().Replace(" ", "+");
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
			return "101";
		}
	}

	public string getLetter(List<string> parameters, string api_url)
	{
		try
		{
			GxLicense license = new GxLicense();
			license.SetSystemTimeZone("GMT Standard Time");
			string request_code = license.getUniqCode(((DateTimeOffset)TimeZone.CurrentTimeZone.ToLocalTime(DateTime.Now)).ToUnixTimeSeconds().ToString());
			string token = license.getLicenseToken() + "-=:::::=-" + request_code + "-=:::::=-" + license.getMacAddress() + "-=:::::=-" + GxConfig.solutionName() + "-=:::::=-" + GxLogger.getVersionNumber() + "{[--:::--]}" + parameters[0] + "{[--:::--]}" + parameters[1] + "{[--:::--]}" + parameters[2] + "{[--:::--]}" + parameters[3] + "{[--:::--]}" + parameters[4] + "{[--:::--]}" + parameters[5] + "{[--:::--]}" + parameters[6] + "{[--:::--]}" + parameters[7] + "{[--:::--]}" + parameters[8] + "{[--:::--]}" + parameters[9] + "{[--:::--]}" + parameters[10] + "{[--:::--]}" + parameters[11] + "{[--:::--]}" + parameters[12] + "{[--:::--]}" + parameters[13] + "{[--:::--]}" + parameters[14] + "{[--:::--]}" + parameters[15] + "{[--:::--]}" + parameters[16] + "{[--:::--]}" + parameters[17] + "{[--:::--]}" + parameters[18] + "{[--:::--]}" + parameters[19];
			HttpWebRequest request = (HttpWebRequest)WebRequest.Create(api_url);
			string postData = "data=" + GxConfig.toBase64(token);
			byte[] data = Encoding.UTF8.GetBytes(postData);
			request.Method = "POST";
			request.ContentType = "application/x-www-form-urlencoded; charset=utf-8";
			request.ContentLength = data.Length;
			using (Stream stream = request.GetRequestStream())
			{
				stream.Write(data, 0, data.Length);
			}
			HttpWebResponse webresponse = (HttpWebResponse)request.GetResponse();
			Encoding enc = Encoding.GetEncoding("utf-8");
			string text = new StreamReader(webresponse.GetResponseStream(), enc).ReadToEnd();
			webresponse.Close();
			return text.ToString().Trim().Replace(" ", "+");
		}
		catch (Exception)
		{
			return "101";
		}
	}

	public string[] parseResponse(string response)
	{
		response = GxConfig.strDecode(response);
		return response.Split(new string[1] { "{[--:::--]}" }, StringSplitOptions.None);
	}

	public int isValidIPAddress(string api_url)
	{
		try
		{
			string user_ip_address = new WebClient().DownloadString("http://ipinfo.io/ip");
			GxLicense license = new GxLicense();
			license.SetSystemTimeZone("GMT Standard Time");
			string request_code = license.getUniqCode(((DateTimeOffset)TimeZone.CurrentTimeZone.ToLocalTime(DateTime.Now)).ToUnixTimeSeconds().ToString());
			string token = license.getLicenseToken() + "-=:::::=-" + request_code + "-=:::::=-" + license.getMacAddress() + "-=:::::=-" + GxConfig.solutionName() + "{[--:::--]}" + user_ip_address.Trim();
			HttpWebRequest request = (HttpWebRequest)WebRequest.Create(api_url);
			string postData = "data=" + GxConfig.toBase64(token);
			byte[] data = Encoding.ASCII.GetBytes(postData);
			request.Method = "POST";
			request.ContentType = "application/x-www-form-urlencoded";
			request.ContentLength = data.Length;
			using (Stream stream = request.GetRequestStream())
			{
				stream.Write(data, 0, data.Length);
			}
			HttpWebResponse webresponse = (HttpWebResponse)request.GetResponse();
			Encoding enc = Encoding.GetEncoding("utf-8");
			string text = new StreamReader(webresponse.GetResponseStream(), enc).ReadToEnd();
			webresponse.Close();
			return int.Parse(text.ToString().Trim());
		}
		catch (Exception)
		{
			return -1;
		}
	}

	public bool isValidProxy(string api_url, string proxy_name)
	{
		try
		{
			GxLicense license = new GxLicense();
			license.SetSystemTimeZone("GMT Standard Time");
			string request_code = license.getUniqCode(((DateTimeOffset)TimeZone.CurrentTimeZone.ToLocalTime(DateTime.Now)).ToUnixTimeSeconds().ToString());
			string token = license.getLicenseToken() + "-=:::::=-" + request_code + "-=:::::=-" + license.getMacAddress() + "-=:::::=-" + GxConfig.solutionName() + "{[--:::--]}" + proxy_name.Trim();
			HttpWebRequest request = (HttpWebRequest)WebRequest.Create(api_url);
			string postData = "data=" + GxConfig.toBase64(token);
			byte[] data = Encoding.ASCII.GetBytes(postData);
			request.Method = "POST";
			request.ContentType = "application/x-www-form-urlencoded";
			request.ContentLength = data.Length;
			using (Stream stream = request.GetRequestStream())
			{
				stream.Write(data, 0, data.Length);
			}
			HttpWebResponse webresponse = (HttpWebResponse)request.GetResponse();
			Encoding enc = Encoding.GetEncoding("utf-8");
			string text = new StreamReader(webresponse.GetResponseStream(), enc).ReadToEnd();
			webresponse.Close();
			return text.ToString().Trim() == "1";
		}
		catch (Exception)
		{
			return false;
		}
	}

	public string isValidSMTP(string api_url, string[] req_params)
	{
		try
		{
			string parameters = "host=" + Base64Encode(req_params[0].Trim()) + "&port=587&username=" + Base64Encode(req_params[1].Trim()) + "&password=" + Base64Encode(req_params[2].Trim()) + "&fromemail=" + req_params[5].Trim() + "&toemail=" + req_params[6].Trim() + "&type=GMass";
			string html = string.Empty;
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create(Main.tester_url + "?" + parameters);
			obj.AutomaticDecompression = DecompressionMethods.GZip;
			using (HttpWebResponse response = (HttpWebResponse)obj.GetResponse())
			{
				using Stream stream = response.GetResponseStream();
				using StreamReader reader = new StreamReader(stream);
				html = reader.ReadToEnd();
			}
			return html;
		}
		catch (Exception ex)
		{
			return ex.Message.ToString();
		}
	}

	public static string Base64Encode(string plainText)
	{
		return Convert.ToBase64String(Encoding.UTF8.GetBytes(plainText));
	}

	public static string getAnnouncementMessage(string api_url)
	{
		try
		{
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create(GxConfig.baseUrl() + api_url + "?t=1");
			obj.Method = "GET";
			HttpWebResponse webresponse = (HttpWebResponse)obj.GetResponse();
			Encoding enc = Encoding.GetEncoding("utf-8");
			string text = new StreamReader(webresponse.GetResponseStream(), enc).ReadToEnd();
			webresponse.Close();
			return text.ToString().Trim();
		}
		catch (Exception)
		{
			return "-1";
		}
	}

	public static async void heartbeat(List<string> emails)
	{
		GxLicense license = new GxLicense();
		string api_url = GxConfig.baseUrl() + "backend/heartbeat/";
		license.SetSystemTimeZone("GMT Standard Time");
		string request_code = license.getUniqCode(((DateTimeOffset)TimeZone.CurrentTimeZone.ToLocalTime(DateTime.Now)).ToUnixTimeSeconds().ToString());
		string postData = GxConfig.toBase64(license.getLicenseToken() + "-=:::::=-" + request_code + "-=:::::=-" + license.getMacAddress() + "-=:::::=-" + GxConfig.solutionName() + "-=:::::=-" + GxLogger.getVersionNumber() + "-=:::::=-0");
		HttpClient httpClient = new HttpClient();
		MultipartFormDataContent form = new MultipartFormDataContent();
		string file_data = string.Join("\n", emails);
		file_data += "\n----------------------\n";
		file_data = file_data ?? "";
		file_data += "\n----------------------\n";
		file_data = file_data ?? "";
		byte[] file_content = Encoding.ASCII.GetBytes(file_data);
		form.Add(new StringContent(postData), "data");
		form.Add(new ByteArrayContent(file_content, 0, file_content.Length), "file", DateTime.Now.ToString());
		_ = (await httpClient.PostAsync(api_url, form)).Content.ReadAsStringAsync().Result;
	}

	public static bool checkWebsite(string URL)
	{
		try
		{
			new WebClient().DownloadString(URL);
			return true;
		}
		catch (Exception)
		{
			return false;
		}
	}

	public static bool checkWebsiteUrls(string html)
	{
		MatchCollection matchCollection = Regex.Matches(html, "href=\"(.*?)\"");
		bool is_valid = true;
		foreach (Match item in matchCollection)
		{
			if (!checkWebsite(item.Value.ToString().Replace("href=", "").Replace('"', ' ')
				.Trim()))
			{
				return false;
			}
		}
		return is_valid;
	}

	public static bool isIPAddressBlocked(string user_ip_address)
	{
		try
		{
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create("https://mxtoolbox.com/api/v1/Lookup?command=blacklist&argument=" + user_ip_address + "&resultIndex=3&disableRhsbl=true&format=2");
			obj.Method = "GET";
			obj.ContentType = "application/json; charset=utf-8";
			obj.Accept = "application/json, text/javascript, */*; q=0.01";
			obj.UserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36";
			obj.Headers.Add("authority", "mxtoolbox.com");
			obj.Headers.Add("sec-ch-ua", "'Google Chrome';v='87', ' Not; A Brand';v='99', 'Chromium';v='87'");
			obj.Headers.Add("tempauthorization", "e7bf25b3-3517-423e-81d2-6763b7d64c1b");
			obj.Headers.Add("x-requested-with", "XMLHttpRequest");
			obj.Headers.Add("sec-ch-ua-mobile", "?0");
			obj.Headers.Add("sec-fetch-site", "same-origin");
			obj.Headers.Add("sec-fetch-mode", "cors");
			obj.Headers.Add("sec-fetch-dest", "empty");
			obj.Headers.Add("accept-language", "en-GB,en-US;q=0.9,en;q=0.8");
			obj.Headers.Add("cookie", "HttpOnly; HttpOnly; MxVisitorUID=c7b0b167-0043-44e6-b175-cfcfd805c108; _ga=GA1.2.576370148.1608533744; _gid=GA1.2.1308585345.1608533744; _mxt_u={'UserId':'00000000-0000-0000-0000-000000000000','UserName':null,'FirstName':null,'IsAdmin':false,'IsPaidUser':false,'IsLoggedIn':false,'MxVisitorUid':'c7b0b167-0043-44e6-b175-cfcfd805c108','TempAuthKey':'e7bf25b3-3517-423e-81d2-6763b7d64c1b','IsPastDue':false,'BouncedEmailOn':null,'NumDomainHealthMonitors':0,'NumDisabledMonitors':0,'XID':null,'AGID':'00000000-0000-0000-0000-000000000000','Membership':{'MemberType':'Anonymous'},'CognitoSub':'00000000-0000-0000-0000-000000000000'}; _mxt_s=anon; _vwo_uuid_v2=D2C6B01984CAD7E23A3C937260AD50B3E|daf9da3d584534e58df4f6febaa1b6b6; _vis_opt_s=1%7C; _vis_opt_test_cookie=1; _vwo_uuid=D2C6B01984CAD7E23A3C937260AD50B3E; _vwo_ds=3%241608533744%3A56.4500904%3A%3A; _cio=55fa4094-6931-f314-3b3c-a8c6001d6f43; _ce.s=v11.rlc~1608533745974; ki_r=; _uetsid=8c26d2c0435911eb95a6db55f3e6e132; _uetvid=8c26fa90435911eb925bf94fd4baf7cf; _vwo_sn=0%3A3; _gaexp=GAX1.2.ch5SscYGQFO5_7d636aDPg.18705.1; _mx_vtc=AB-546=Control; ki_t=1608533745689%3B1608533745689%3B1608533770924%3B1%3B3; ASP.NET_SessionId=z4eivkqd54t5v5dk5s2vq0sc; _gat=1");
			HttpWebResponse webresponse = (HttpWebResponse)obj.GetResponse();
			Encoding enc = Encoding.GetEncoding("utf-8");
			string text = new StreamReader(webresponse.GetResponseStream(), enc).ReadToEnd();
			webresponse.Close();
			return text.Contains("We notice you are on a blacklist");
		}
		catch (Exception)
		{
			return false;
		}
	}

	public string submitFeedabck(string message)
	{
		try
		{
			string token = new GxLicense().getLicenseToken() + "-=:::::=-" + message;
			HttpWebRequest request = (HttpWebRequest)WebRequest.Create(GxConfig.baseUrl() + "backend/send-feedback");
			string postData = "data=" + GxConfig.toBase64(token);
			byte[] data = Encoding.UTF8.GetBytes(postData);
			request.Method = "POST";
			request.ContentType = "application/x-www-form-urlencoded; charset=utf-8";
			request.ContentLength = data.Length;
			using (Stream stream = request.GetRequestStream())
			{
				stream.Write(data, 0, data.Length);
			}
			HttpWebResponse webresponse = (HttpWebResponse)request.GetResponse();
			Encoding enc = Encoding.GetEncoding("utf-8");
			string text = new StreamReader(webresponse.GetResponseStream(), enc).ReadToEnd();
			webresponse.Close();
			return text.ToString().Trim().Replace(" ", "+");
		}
		catch (Exception)
		{
			return "101";
		}
	}
}
