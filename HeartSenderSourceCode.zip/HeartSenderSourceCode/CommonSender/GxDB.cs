using System;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32;

namespace CommonSender;

[Serializable]
public class GxDB
{
	public static RegistryKey registry;

	private RegistryKey getConnection()
	{
		if (registry == null)
		{
			registry = Registry.CurrentUser.CreateSubKey("SOFTWARE\\HeartSender");
		}
		return registry;
	}

	public void add(string[] param)
	{
		try
		{
			registry = getConnection();
			string unique_key = "HS_SMTP_" + param[2];
			int counter = 1;
			if (registry.GetValue(unique_key) != null)
			{
				counter = int.Parse(registry.GetValue(unique_key).ToString());
				counter++;
			}
			registry.SetValue(unique_key, counter.ToString().Trim().ToLower());
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.Message.ToString());
		}
	}

	public int getSmtpCount(string code)
	{
		try
		{
			registry = getConnection();
			string unique_key = "HS_SMTP_" + code;
			if (registry.GetValue(unique_key) != null)
			{
				return int.Parse(registry.GetValue(unique_key).ToString());
			}
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.Message.ToString());
		}
		return 0;
	}

	public static string createMD5(string input)
	{
		using MD5 md5 = MD5.Create();
		byte[] inputBytes = Encoding.ASCII.GetBytes(input);
		byte[] hashBytes = md5.ComputeHash(inputBytes);
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < hashBytes.Length; i++)
		{
			sb.Append(hashBytes[i].ToString("X2"));
		}
		return sb.ToString();
	}
}
