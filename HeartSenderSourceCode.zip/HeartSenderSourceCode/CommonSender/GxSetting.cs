using System;
using HeartSender;

namespace CommonSender;

[Serializable]
public class GxSetting
{
	public GxConfig config;

	public Main main;

	public GxSetting(Main _main)
	{
		main = _main;
	}

	public bool parseData()
	{
		return toGxConfig();
	}

	public bool toGxConfig()
	{
		config = new GxConfig();
		main.settings[23].Split('/');
		config.priority = int.Parse(main.settings[11]);
		config.user_random = 0;
		config.using_tag = 1;
		config.using_attachment = ((main.settings[23] != "") ? 1 : 0);
		config.name_attachment = main.settings[24];
		config.email_countsend = int.Parse(main.settings[19]);
		config.sending_delay = int.Parse(main.settings[21]);
		config.masking = 0;
		config.date = "America/Adak";
		config.letter_encrypt = int.Parse(main.settings[7]);
		config.letter_encode = int.Parse(main.settings[6]);
		config.subject_encode = int.Parse(main.settings[8]);
		config.link_encode = int.Parse(main.settings[9]);
		config.image_encode = 0;
		config.list_email = "";
		config.letter = "";
		config.file_attachment = main.settings[23];
		config.target_email_name = "";
		config.use_reply_email = 0;
		config.reply_email = "";
		config.reply_email_name = "";
		config.from_name = main.settings[16];
		config.subject = main.settings[17];
		config.confirmed_email = 1;
		config.failed_email = 1;
		config.mail_limit = 0;
		config.fromname_encode = int.Parse(main.settings[10]);
		config.remove_email = 1;
		main.settings[32] = ((main.settings[32].ToString().Length == 0) ? "0" : main.settings[32]);
		config.verify_email = int.Parse(main.settings[32]);
		config.smtp = Main.smtps;
		config.links = Main.links;
		config.text_encoding = main.settings[1];
		config.btencoding = main.settings[2];
		config.preheader = main.settings[26];
		config.replyEmail = main.settings[27];
		config.api_key = main.settings[28];
		config.api_domain = main.settings[29];
		config.imap_keywords = main.settings[30];
		main.settings[31] = ((main.settings[31].ToString().Length == 0) ? "10" : main.settings[31]);
		config.imap_time = double.Parse(main.settings[31]);
		main.settings[33] = ((main.settings[33].ToString().Length == 0) ? "0" : main.settings[33]);
		config.enable_duplicate = main.settings[33] == "1";
		main.settings[35] = ((main.settings[35].ToString().Length == 0) ? "0" : main.settings[35]);
		config.enable_validate_email = main.settings[35] == "1";
		if (config.validate())
		{
			return true;
		}
		return false;
	}

	public void sendEmail(int i)
	{
		Console.WriteLine("Email Sent: " + i);
	}
}
