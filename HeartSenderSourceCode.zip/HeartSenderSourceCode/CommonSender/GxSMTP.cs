using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using ARSoft.Tools.Net.Dns;
using EASendMail;
using HeartSender;
using Microsoft.Win32;
using Newtonsoft.Json;

namespace CommonSender;

[Serializable]
public class GxSMTP
{
	public string host;

	public string username;

	public int port;

	public bool secure;

	public string from_email;

	public string password;

	public bool is_proxy;

	public GxItem item;

	public static int counter = 0;

	private static GxLogger logger;

	public static int max_counter = 0;

	public static List<string> confirmed = new List<string>();

	public static List<string> failed = new List<string>();

	private static object locker = new object();

	public string[] headers;

	public int counter_index;

	public string counter_log = "";

	public string proxy_host = "";

	public int proxy_port;

	public string proxy_username = "";

	public string proxy_password = "";

	public string proxy_type = "Sock5";

	public bool imap = true;

	private string EA_license = "ES-D1508812687-00796-43EDA8441T7A552E-FV3A13A8DF3826B7";

	private string EA_IMAP_license = "EG-C1508812802-00331-52A23AA637527764-FF1A3TBCF28AAVBA";

	private int retry_count = 1;

	public static Queue<GxSMTP> queue = new Queue<GxSMTP>();

	public string item_progress = "";

	public static bool is_running = false;

	public static Thread thread;

	public static int url_counter = 0;

	public static int keyword_counter = 0;

	public static int proxy_counter = 0;

	private string attachment_parameters = "";

	public int max_limit;

	public int usage_count;

	public string server_response = "";

	public string[] server_headers;

	public static int count = 0;

	public static string status = string.Empty;

	public static string[] tokens;

	public string sender_email;

	public string smtp_domain_name;

	public string smtp_user_name;

	public bool isValid()
	{
		if (host != "" && username != "" && port > 0 && from_email != "" && password != "")
		{
			return true;
		}
		return false;
	}

	public string getMd5Code()
	{
		return GxDB.createMD5(host + "|" + port + "|" + username + "|" + password);
	}

	public void sendBugReport()
	{
		try
		{
			item.time = DateTime.Now.ToString("hh:mm:ss tt");
			if (proxy_host == "")
			{
				if (host.Contains("office365") || port == 465)
				{
					sendEmailViaProxy(item, is_proxy: false);
				}
				else
				{
					sendEmail(item);
				}
			}
			else
			{
				sendEmailViaProxy(item);
			}
		}
		catch (Exception)
		{
		}
	}

	public AlternateView parseLetterHTML(string html)
	{
		MatchCollection matchCollection = Regex.Matches(html, "src=\"(.*?)\"");
		int counter = 1;
		AlternateView AV = AlternateView.CreateAlternateViewFromString(html, null, "text/html");
		List<LinkedResource> resources = new List<LinkedResource>();
		foreach (Match j in matchCollection)
		{
			string[] tokens = j.Value.ToString().Split(new string[1] { "file:///" }, StringSplitOptions.RemoveEmptyEntries);
			if (tokens.Length != 1)
			{
				tokens[1] = tokens[1].Replace('"', ' ').Trim();
				tokens[1] = Regex.Unescape(tokens[1]);
				tokens[1] = tokens[1].Replace("%5C", "\\");
				tokens[1] = new Uri(tokens[1]).LocalPath;
				LinkedResource resource = new LinkedResource(tokens[1], "image/jpeg");
				resource.ContentId = "Image" + counter;
				html = html.Replace(j.Value.ToString(), "src='cid:" + resource.ContentId + "'");
				resources.Add(resource);
				counter++;
			}
		}
		AV = AlternateView.CreateAlternateViewFromString(html, null, "text/html");
		for (int i = 0; i < resources.Count; i++)
		{
			AV.LinkedResources.Add(resources[i]);
		}
		return AV;
	}

	public void sendEmail(GxItem item)
	{
		try
		{
			MailMessage mail = new MailMessage();
			System.Net.Mail.SmtpClient SmtpServer = new System.Net.Mail.SmtpClient(host);
			mail.From = new System.Net.Mail.MailAddress(from_email, item.from_name);
			if (item.config.use_reply_email == 1)
			{
				mail.From = new System.Net.Mail.MailAddress(item.reply_email, item.reply_email_name);
			}
			System.Net.Mail.MailAddress to = new System.Net.Mail.MailAddress(item.email);
			if (item.config.target_email_name != "")
			{
				to = new System.Net.Mail.MailAddress(item.email, item.target_email_name);
			}
			mail.To.Add(to);
			if (item.config.replyEmail != "")
			{
				mail.Sender = new System.Net.Mail.MailAddress(item.config.replyEmail);
				mail.ReplyToList.Add(new System.Net.Mail.MailAddress(item.config.replyEmail));
			}
			mail.Subject = item.subject;
			mail.IsBodyHtml = true;
			mail.AlternateViews.Add(parseLetterHTML(item.message));
			SmtpServer.DeliveryMethod = SmtpDeliveryMethod.Network;
			SmtpServer.Timeout = 50000;
			item.config.text_encoding = ((item.config.text_encoding == "" || item.config.text_encoding == null) ? "UTF8" : item.config.text_encoding);
			switch (item.config.text_encoding)
			{
			case "ASCII":
				mail.BodyEncoding = Encoding.ASCII;
				break;
			case "BigEndianUnicode":
				mail.BodyEncoding = Encoding.BigEndianUnicode;
				break;
			case "Default":
				mail.BodyEncoding = Encoding.Default;
				break;
			case "Unicode":
				mail.BodyEncoding = Encoding.Unicode;
				break;
			case "UTF32":
				mail.BodyEncoding = Encoding.UTF32;
				break;
			case "UTF7":
				mail.BodyEncoding = Encoding.UTF7;
				break;
			case "UTF8":
				mail.BodyEncoding = Encoding.UTF8;
				break;
			default:
				mail.BodyEncoding = Encoding.ASCII;
				break;
			}
			mail.SubjectEncoding = mail.BodyEncoding;
			item.config.btencoding = ((item.config.btencoding == "" || item.config.btencoding == null) ? "QuotedPrintable" : item.config.btencoding);
			switch (item.config.btencoding)
			{
			case "Base64":
				mail.BodyTransferEncoding = TransferEncoding.Base64;
				break;
			case "EightBit":
				mail.BodyTransferEncoding = TransferEncoding.EightBit;
				break;
			case "QuotedPrintable":
				mail.BodyTransferEncoding = TransferEncoding.QuotedPrintable;
				break;
			case "SevenBit":
				mail.BodyTransferEncoding = TransferEncoding.SevenBit;
				break;
			case "Unknown":
				mail.BodyTransferEncoding = TransferEncoding.Unknown;
				break;
			default:
				mail.BodyTransferEncoding = TransferEncoding.QuotedPrintable;
				break;
			}
			item.config.smtpdf = ((item.config.smtpdf == "" || item.config.smtpdf == null) ? "International" : item.config.smtpdf);
			string smtpdf = item.config.smtpdf;
			if (!(smtpdf == "International"))
			{
				if (smtpdf == "SevenBit")
				{
					SmtpServer.DeliveryFormat = SmtpDeliveryFormat.SevenBit;
				}
			}
			else
			{
				SmtpServer.DeliveryFormat = SmtpDeliveryFormat.International;
			}
			if (headers.Length != 0)
			{
				string[] array = headers;
				foreach (string header in array)
				{
					if (header.Trim().Length > 1)
					{
						string[] row = header.Split('|');
						mail.Headers.Add(row[0].Trim(), row[1].Trim());
					}
				}
			}
			if (item.config.priority == 1)
			{
				mail.Priority = System.Net.Mail.MailPriority.High;
			}
			else if (item.config.priority == 3)
			{
				mail.Priority = System.Net.Mail.MailPriority.Normal;
			}
			else if (item.config.priority == 5)
			{
				mail.Priority = System.Net.Mail.MailPriority.Low;
			}
			else
			{
				mail.Priority = System.Net.Mail.MailPriority.Normal;
			}
			mail.Headers.Add("X-Complaints-To", "abuse@postmarkapp.com");
			mail.Headers.Add("X-Job", "189260_5424745");
			mail.Headers.Add("X-PM-Message-Id", "eca85980-0902-4b12-8221-8a7525184875");
			mail.Headers.Add("X-dkim-options", "20200609100822pm;d=sistematdc.com");
			mail.Headers.Add("MIME-Version", "1.0");
			mail.Headers.Add("Content-Type", "text/plain; charset=UTF-8");
			mail.Headers.Add("Content-Transfer-Encoding", "quoted-printable");
			if (item.config.using_attachment == 1)
			{
				lock (locker)
				{
					string attachmentPath = item.config.file_attachment;
					if (File.Exists(attachmentPath))
					{
						FileStream fs = new FileStream(attachmentPath, FileMode.Open, FileAccess.Read, FileShare.Read);
						string content = string.Empty;
						FileInfo fi = new FileInfo(attachmentPath);
						string[] extensions = new string[6] { ".html", ".htm", ".txt", ".rtf", ".log", ".tex" };
						using (StreamReader streamReader = new StreamReader(fs, Encoding.UTF8))
						{
							content = streamReader.ReadToEnd();
						}
						System.Net.Mail.Attachment attachment;
						if (extensions.Contains(fi.Extension.ToLower()))
						{
							if (attachment_parameters != "")
							{
								string[] parameters = attachment_parameters.Split(new string[1] { "|||" }, StringSplitOptions.None);
								for (int i = 0; i < parameters.Length; i++)
								{
									string[] tags = parameters[i].Split(new string[1] { "===" }, StringSplitOptions.None);
									if (tags.Length == 2 && tags[0] != tags[1])
									{
										content = content.Replace(tags[0], tags[1]);
									}
								}
							}
							MemoryStream memoryStream = new MemoryStream();
							StreamWriter streamWriter = new StreamWriter(memoryStream);
							streamWriter.Write(content);
							streamWriter.Flush();
							memoryStream.Position = 0L;
							attachment = new System.Net.Mail.Attachment(memoryStream, Path.GetFileName(attachmentPath));
						}
						else
						{
							attachment = new System.Net.Mail.Attachment(attachmentPath);
						}
						if (this.item.attachment == "" || this.item.attachment == null)
						{
							attachment.Name = Path.GetFileName(attachmentPath);
						}
						else
						{
							attachment.Name = this.item.attachment;
						}
						mail.Attachments.Add(attachment);
					}
				}
			}
			SmtpServer.Port = port;
			SmtpServer.Credentials = new NetworkCredential(username, password);
			ServicePointManager.SecurityProtocol = SecurityProtocolType.SystemDefault;
			if (secure)
			{
				SmtpServer.EnableSsl = true;
				ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
			}
			SmtpServer.DeliveryMethod = SmtpDeliveryMethod.Network;
			SmtpServer.Send(mail);
			item.is_sent = true;
			counter_log = "Success";
			item_progress = "";
		}
		catch (Exception ex)
		{
			item.is_sent = false;
			counter_log = "Error1: " + ex.StackTrace.ToString();
			item_progress = "";
		}
		counter--;
	}

	public void sendEmailViaProxy(GxItem item, bool is_proxy = true)
	{
		try
		{
			SmtpMail mail = new SmtpMail(EA_license);
			mail.From = new EASendMail.MailAddress(item.from_name, from_email);
			if (item.config.use_reply_email == 1)
			{
				mail.From = new EASendMail.MailAddress(item.reply_email_name, item.reply_email);
			}
			EASendMail.MailAddress to = new EASendMail.MailAddress(item.email);
			if (item.config.target_email_name != "")
			{
				to = new EASendMail.MailAddress(item.target_email_name, item.email);
			}
			mail.To.Add(to);
			if (item.config.replyEmail != "")
			{
				mail.ReplyTo = item.config.replyEmail;
			}
			mail.Subject = item.subject;
			mail.HtmlBody = item.message;
			SmtpServer server = new SmtpServer(host);
			if (port == 465)
			{
				server.Port = 465;
				server.ConnectType = SmtpConnectType.ConnectSSLAuto;
			}
			else
			{
				server.ConnectType = SmtpConnectType.ConnectTryTLS;
			}
			if (is_proxy)
			{
				server.SocksProxyServer = proxy_host;
				server.SocksProxyPort = proxy_port;
				if (proxy_type == "Sock5")
				{
					server.ProxyProtocol = SocksProxyProtocol.Socks5;
				}
				else if (proxy_type == "Sock4")
				{
					server.ProxyProtocol = SocksProxyProtocol.Socks4;
				}
				else
				{
					server.ProxyProtocol = SocksProxyProtocol.Http;
				}
				if (proxy_username != "")
				{
					server.SocksProxyUser = proxy_username;
					server.SocksProxyPassword = proxy_password;
				}
			}
			server.User = username;
			server.Password = password;
			if (headers.Length != 0)
			{
				string[] array = headers;
				foreach (string header in array)
				{
					if (header.Trim().Length > 1)
					{
						string[] row = header.Split('|');
						mail.Headers.Add(row[0].Trim(), row[1].Trim());
					}
				}
			}
			if (item.config.priority == 1)
			{
				mail.Priority = EASendMail.MailPriority.High;
			}
			else if (item.config.priority == 3)
			{
				mail.Priority = EASendMail.MailPriority.Normal;
			}
			else if (item.config.priority == 5)
			{
				mail.Priority = EASendMail.MailPriority.Low;
			}
			else
			{
				mail.Priority = EASendMail.MailPriority.Normal;
			}
			if (item.config.using_attachment == 1)
			{
				lock (locker)
				{
					string attachmentPath = item.config.file_attachment;
					if (File.Exists(attachmentPath))
					{
						FileStream fs = new FileStream(attachmentPath, FileMode.Open, FileAccess.Read, FileShare.Read);
						string content = string.Empty;
						FileInfo fi = new FileInfo(attachmentPath);
						EASendMail.Attachment attachment;
						if (new string[6] { ".html", ".htm", ".txt", ".rtf", ".log", ".tex" }.Contains(fi.Extension.ToLower()))
						{
							using (StreamReader streamReader = new StreamReader(fs, Encoding.UTF8))
							{
								content = streamReader.ReadToEnd();
							}
							if (attachment_parameters != "")
							{
								string[] parameters = attachment_parameters.Split(new string[1] { "|||" }, StringSplitOptions.None);
								for (int i = 0; i < parameters.Length; i++)
								{
									string[] tags = parameters[i].Split(new string[1] { "===" }, StringSplitOptions.None);
									if (tags.Length == 2 && tags[0] != tags[1])
									{
										content = content.Replace(tags[0], tags[1]);
									}
								}
							}
							byte[] bytes = Encoding.ASCII.GetBytes(content);
							attachment = mail.AddAttachment(attachmentPath, bytes);
						}
						else
						{
							attachment = mail.AddAttachment(attachmentPath);
						}
						if (this.item.attachment == "" || this.item.attachment == null)
						{
							attachment.Name = Path.GetFileName(attachmentPath);
						}
						else
						{
							attachment.Name = this.item.attachment;
						}
					}
				}
			}
			new EASendMail.SmtpClient().SendMail(server, mail);
			item.is_sent = true;
			counter_log = "Success";
			item_progress = "";
		}
		catch (Exception ex)
		{
			item.is_sent = false;
			counter_log = "Error: " + ex.Message;
			item_progress = "";
		}
		counter--;
	}

	public void sendDirect(GxItem item)
	{
		try
		{
			SmtpMail mail = new SmtpMail(EA_license);
			mail.From = new EASendMail.MailAddress(item.from_name, from_email);
			if (item.config.use_reply_email == 1)
			{
				mail.From = new EASendMail.MailAddress(item.reply_email_name, item.reply_email);
			}
			EASendMail.MailAddress to = new EASendMail.MailAddress(item.email);
			if (item.config.target_email_name != "")
			{
				to = new EASendMail.MailAddress(item.target_email_name, item.email);
			}
			mail.To.Add(to);
			if (item.config.replyEmail != "")
			{
				mail.ReplyTo = item.config.replyEmail;
			}
			mail.Subject = item.subject;
			mail.HtmlBody = item.message;
			SmtpServer server = new SmtpServer("");
			if (headers.Length != 0)
			{
				string[] array = headers;
				foreach (string header in array)
				{
					if (header.Trim().Length > 1)
					{
						string[] row = header.Split('|');
						mail.Headers.Add(row[0].Trim(), row[1].Trim());
					}
				}
			}
			if (item.config.priority == 1)
			{
				mail.Priority = EASendMail.MailPriority.High;
			}
			else if (item.config.priority == 3)
			{
				mail.Priority = EASendMail.MailPriority.Normal;
			}
			else if (item.config.priority == 5)
			{
				mail.Priority = EASendMail.MailPriority.Low;
			}
			else
			{
				mail.Priority = EASendMail.MailPriority.Normal;
			}
			if (item.config.using_attachment == 1)
			{
				lock (locker)
				{
					string attachmentPath = item.config.file_attachment;
					if (File.Exists(attachmentPath))
					{
						FileStream fs = new FileStream(attachmentPath, FileMode.Open, FileAccess.Read, FileShare.Read);
						string content = string.Empty;
						FileInfo fi = new FileInfo(attachmentPath);
						EASendMail.Attachment attachment;
						if (new string[6] { ".html", ".htm", ".txt", ".rtf", ".log", ".tex" }.Contains(fi.Extension.ToLower()))
						{
							using (StreamReader streamReader = new StreamReader(fs, Encoding.UTF8))
							{
								content = streamReader.ReadToEnd();
							}
							if (attachment_parameters != "")
							{
								string[] parameters = attachment_parameters.Split(new string[1] { "|||" }, StringSplitOptions.None);
								for (int i = 0; i < parameters.Length; i++)
								{
									string[] tags = parameters[i].Split(new string[1] { "===" }, StringSplitOptions.None);
									if (tags.Length == 2 && tags[0] != tags[1])
									{
										content = content.Replace(tags[0], tags[1]);
									}
								}
							}
							byte[] bytes = Encoding.ASCII.GetBytes(content);
							attachment = mail.AddAttachment(attachmentPath, bytes);
						}
						else
						{
							attachment = mail.AddAttachment(attachmentPath);
						}
						if (this.item.attachment == "" || this.item.attachment == null)
						{
							attachment.Name = Path.GetFileName(attachmentPath);
						}
						else
						{
							attachment.Name = this.item.attachment;
						}
					}
				}
			}
			new EASendMail.SmtpClient().SendMail(server, mail);
			item.is_sent = true;
			counter_log = "Success";
			item_progress = "";
		}
		catch (Exception ex)
		{
			item.is_sent = false;
			counter_log = "Error: " + ex.Message;
			item_progress = "";
		}
		counter--;
	}

	public static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e)
	{
		GxItem gxitem = (GxItem)e.UserState;
		if (e.Cancelled)
		{
			gxitem.is_sent = false;
		}
		else if (e.Error != null)
		{
			gxitem.is_sent = false;
			failed.Add(gxitem.email);
		}
		else
		{
			gxitem.is_sent = true;
			confirmed.Add(gxitem.email);
		}
		counter--;
		if (counter < 0)
		{
			counter = 0;
		}
	}

	public static void sendingInThread(GxSMTP smtp, int delay)
	{
		if (!IsValidEmail(smtp.item.email))
		{
			return;
		}
		smtp.item.time = DateTime.Now.ToString("hh:mm:ss tt");
		if (smtp.proxy_host == "" && smtp.host.Trim().ToLower() != "direct")
		{
			if (smtp.host.Contains("office365") || smtp.port == 465)
			{
				smtp.sendEmailViaProxy(smtp.item, is_proxy: false);
			}
			else
			{
				smtp.sendEmail(smtp.item);
			}
		}
		else if (smtp.host.Trim().ToLower() != "direct")
		{
			smtp.sendEmailViaProxy(smtp.item);
		}
		else
		{
			smtp.sendDirect(smtp.item);
		}
		Thread.Sleep(delay * 1000);
		counter++;
	}

	public static bool bulkSend(List<GxSMTP> list, int delay, GxLogger _logger, DoWorkEventArgs e, BackgroundWorker worker)
	{
		max_counter = list.Count;
		counter = 0;
		Parallel.ForEach(list, delegate(GxSMTP smtp)
		{
			sendingInThread(smtp, delay);
		});
		while (true)
		{
			int iteration = 0;
			while (counter > 0)
			{
				Thread.Sleep(3000);
				if (iteration > 20)
				{
					counter = 0;
					break;
				}
				iteration++;
			}
			int i = 0;
			while (true)
			{
				if (i < max_counter)
				{
					if (!list[i].item.is_sent && list[i].retry_count < 4)
					{
						break;
					}
					worker.ReportProgress(1, list[i]);
					i++;
					continue;
				}
				return true;
			}
			list[i].retry_count++;
			sendingInThread(list[i], delay);
		}
	}

	public static bool bulkSend(List<GxSMTP> list, int delay, GxLogger _logger)
	{
		logger = _logger;
		max_counter = list.Count;
		Console.SetCursorPosition(Console.CursorLeft, Console.CursorTop - 1);
		counter = 0;
		Parallel.ForEach(list, delegate(GxSMTP smtp)
		{
			if (IsValidEmail(smtp.item.email))
			{
				smtp.item.time = DateTime.Now.ToString("hh:mm:ss tt");
				if (smtp.proxy_host == "")
				{
					if (smtp.host.Contains("office365") || smtp.port == 465)
					{
						smtp.sendEmailViaProxy(smtp.item, is_proxy: false);
					}
					else
					{
						smtp.sendEmail(smtp.item);
					}
				}
				else
				{
					smtp.sendEmailViaProxy(smtp.item);
				}
				Thread.Sleep(delay * 1000);
				counter++;
			}
		});
		int iteration = 0;
		while (counter > 0)
		{
			Thread.Sleep(3000);
			if (iteration > 100)
			{
				counter = 0;
				break;
			}
			iteration++;
		}
		for (int i = 0; i < max_counter; i++)
		{
			list[i].item.log = list[i].item.log + "|||" + (list[i].item.is_sent ? "1" : "0");
			string[] tokens = list[i].item.log.Split(new string[1] { "|||" }, StringSplitOptions.None);
			logger.toLogger(tokens, append: true);
		}
		return true;
	}

	private string getMimeType(string fileName)
	{
		string mimeType = "application/unknown";
		string ext = Path.GetExtension(fileName).ToLower();
		RegistryKey regKey = Registry.ClassesRoot.OpenSubKey(ext);
		if (regKey != null && regKey.GetValue("Content Type") != null)
		{
			mimeType = regKey.GetValue("Content Type").ToString();
		}
		return mimeType;
	}

	private static bool IsValidEmail(string email)
	{
		if (Main.is_validate == "1")
		{
			try
			{
				tokens = email.Trim().ToLower().Split('@');
				status = getDNSType(tokens[1]);
				if (status.Contains("outlook"))
				{
					if (outValidator(email) == "Deliverable")
					{
						return true;
					}
					return false;
				}
				if (checking(status, email) == "Valid")
				{
					return true;
				}
				return false;
			}
			catch
			{
				return false;
			}
		}
		try
		{
			if (new System.Net.Mail.MailAddress(email).Address == email)
			{
				return true;
			}
			return false;
		}
		catch
		{
			return false;
		}
	}

	public static bool addInQueue(BackgroundWorker worker, GxSMTP _smtp)
	{
		if (queue.Count >= 500)
		{
			return false;
		}
		queue.Enqueue(_smtp);
		_smtp.counter_log = "";
		_smtp.item_progress = "Queued";
		worker.ReportProgress(1, _smtp);
		return true;
	}

	public static void processQueue(BackgroundWorker worker, string[] keywords, List<string> links, List<string> proxies, int max_threads)
	{
		if (queue.Count <= max_threads)
		{
			max_threads = queue.Count;
		}
		int current_threads_count = 0;
		thread = new Thread((ThreadStart)delegate
		{
			while (queue.Count > 0)
			{
				is_running = true;
				if (current_threads_count < max_threads && queue.Count > 0)
				{
					current_threads_count++;
					new Task(delegate
					{
						if (queue.Count > 0)
						{
							try
							{
								GxSMTP gxSMTP = queue.Dequeue();
								if (IsValidEmail(gxSMTP.item.email))
								{
									gxSMTP.item.progress_count = 1;
									gxSMTP.counter_log = "";
									gxSMTP.item_progress = "Preparing letter ...";
									worker.ReportProgress(1, gxSMTP);
									gxSMTP.item.time = DateTime.Now.ToString("hh:mm:ss tt");
									object[] array = processEmail(gxSMTP, links, keywords);
									gxSMTP = (GxSMTP)array[0];
									gxSMTP = sendNow(gxSMTP, (List<string>)array[1], worker, proxies);
									if (!gxSMTP.item.is_sent)
									{
										gxSMTP.item.progress_count = 0;
										while (!gxSMTP.item.is_sent && gxSMTP.retry_count < 3)
										{
											gxSMTP.counter_log = "";
											gxSMTP.item_progress = "Retrying(" + (gxSMTP.retry_count + 1) + ") ...";
											worker.ReportProgress(1, gxSMTP);
											Thread.Sleep(2000);
											gxSMTP.retry_count++;
											gxSMTP = sendNow(gxSMTP, (List<string>)array[1], worker, proxies);
										}
										if (!gxSMTP.item.is_sent)
										{
											gxSMTP.item.progress_count = 1;
											gxSMTP.item_progress = "";
											worker.ReportProgress(1, gxSMTP);
											if (!Main.dead_list.Contains(gxSMTP.item.smtp_index))
											{
												Main.dead_list.Add(gxSMTP.item.smtp_index);
											}
										}
										else
										{
											gxSMTP.item.progress_count = 1;
											Main.delivered.Add(gxSMTP.item.email);
											worker.ReportProgress(1, gxSMTP);
										}
									}
									else
									{
										gxSMTP.item.progress_count = 1;
										Main.delivered.Add(gxSMTP.item.email);
										worker.ReportProgress(1, gxSMTP);
									}
								}
								else
								{
									gxSMTP.item.progress_count = 1;
									gxSMTP.item.is_sent = false;
									gxSMTP.counter_log = "Invalid Email Address";
									gxSMTP.item_progress = gxSMTP.counter_log;
									worker.ReportProgress(1, gxSMTP);
								}
							}
							catch (Exception ex)
							{
								Console.WriteLine("Error:: " + ex.Message.ToString());
							}
						}
						current_threads_count--;
						if (queue.Count == 0 && current_threads_count <= 0)
						{
							is_running = false;
						}
					}).Start();
				}
				else
				{
					Console.WriteLine("Queue Waiting ...");
					Thread.Sleep(5000);
				}
			}
		});
		thread.Start();
	}

	public static GxSMTP sendNow(GxSMTP q_smtp, List<string> tokens, BackgroundWorker worker, List<string> proxies)
	{
		string response = q_smtp.server_response;
		GxApi api = new GxApi();
		if (response == "-1")
		{
			string api_url = GxConfig.baseUrl() + "backend/parse";
			response = api.getLetter(tokens, api_url);
		}
		if (response == "100" || response == "101")
		{
			q_smtp.item.is_sent = false;
			q_smtp.counter_log = "Template Error: " + response;
			worker.ReportProgress(1, q_smtp);
		}
		else
		{
			q_smtp.counter_log = "";
			q_smtp.item_progress = "Letter Ready!";
			worker.ReportProgress(1, q_smtp);
			string[] response_data = api.parseResponse(response);
			q_smtp.item.message = WebUtility.HtmlDecode(response_data[0]);
			string email_link = "";
			string[] e_tokens = q_smtp.item.email.Split('@');
			if (e_tokens.Length > 1)
			{
				string[] d_tokens = e_tokens[1].Split('.');
				email_link = e_tokens[0] + "-" + d_tokens[0];
			}
			else
			{
				email_link = e_tokens[0];
			}
			q_smtp.item.message = q_smtp.item.message.Replace("##NEW_AUTOEMAILAE##", q_smtp.item.email);
			q_smtp.item.message = q_smtp.item.message.Replace("##NEW_EMAIL_LINK##", email_link);
			q_smtp.item.message = q_smtp.item.message.Replace("##NEW_EMAILB64##", GxConfig.toBase64(q_smtp.item.email));
			q_smtp.item.message = q_smtp.item.message.Replace("##NEW_EMAIL##", q_smtp.item.email);
			q_smtp.item.message = q_smtp.item.message.Replace("[-NEW_AUTOEMAILAE-]", q_smtp.item.email);
			q_smtp.item.message = q_smtp.item.message.Replace("[-NEW_EMAIL_LINK-]", email_link);
			q_smtp.item.message = q_smtp.item.message.Replace("[-NEW_EMAILB64-]", GxConfig.toBase64(q_smtp.item.email));
			q_smtp.item.message = q_smtp.item.message.Replace("[-NEW_EMAIL-]", q_smtp.item.email);
			q_smtp.item.message = q_smtp.item.message.Replace("[-FIRSTNAME-]", q_smtp.item.firstname);
			q_smtp.item.message = q_smtp.item.message.Replace("[-LASTNAME-]", q_smtp.item.lastname);
			q_smtp.item.message = q_smtp.item.message.Replace("[-MDOMAIN-]", CultureInfo.CurrentCulture.TextInfo.ToTitleCase(q_smtp.item.email.Split('@')[1]));
			if (q_smtp.item.config.preheader != "")
			{
				q_smtp.item.message = "<style>.preheader { display:none !important; visibility:hidden; opacity:0; color:transparent; height:0; width:0; }</style><span class='preheader' style='color:transparent; display:none !important; height:0; opacity:0; visibility:hidden; width:0'>" + q_smtp.item.config.preheader + "</span>" + q_smtp.item.message;
			}
			q_smtp.item.subject = response_data[1];
			q_smtp.item.subject = q_smtp.item.subject.Replace("##NEW_AUTOEMAILAE##", q_smtp.item.email);
			q_smtp.item.subject = q_smtp.item.subject.Replace("##NEW_EMAIL_LINK##", email_link);
			q_smtp.item.subject = q_smtp.item.subject.Replace("##NEW_EMAILB64##", GxConfig.toBase64(q_smtp.item.email));
			q_smtp.item.subject = q_smtp.item.subject.Replace("##NEW_EMAIL##", q_smtp.item.email);
			q_smtp.item.subject = q_smtp.item.subject.Replace("[-NEW_AUTOEMAILAE-]", q_smtp.item.email);
			q_smtp.item.subject = q_smtp.item.subject.Replace("[-NEW_EMAIL_LINK-]", email_link);
			q_smtp.item.subject = q_smtp.item.subject.Replace("[-NEW_EMAILB64-]", GxConfig.toBase64(q_smtp.item.email));
			q_smtp.item.subject = q_smtp.item.subject.Replace("[-NEW_EMAIL-]", q_smtp.item.email);
			q_smtp.item.subject = q_smtp.item.subject.Replace("[-FIRSTNAME-]", q_smtp.item.firstname);
			q_smtp.item.subject = q_smtp.item.subject.Replace("[-LASTNAME-]", q_smtp.item.lastname);
			q_smtp.item.subject = q_smtp.item.subject.Replace("[-MDOMAIN-]", CultureInfo.CurrentCulture.TextInfo.ToTitleCase(q_smtp.item.email.Split('@')[1]));
			if (q_smtp.item.config.using_attachment == 1)
			{
				q_smtp.item.attachment = response_data[2];
			}
			q_smtp.item.from_name = response_data[3];
			q_smtp.item.from_name = q_smtp.item.from_name.Replace("##NEW_AUTOEMAILAE##", q_smtp.item.email);
			q_smtp.item.from_name = q_smtp.item.from_name.Replace("##NEW_EMAIL_LINK##", email_link);
			q_smtp.item.from_name = q_smtp.item.from_name.Replace("##NEW_EMAILB64##", GxConfig.toBase64(q_smtp.item.email));
			q_smtp.item.from_name = q_smtp.item.from_name.Replace("##NEW_EMAIL##", q_smtp.item.email);
			q_smtp.item.from_name = q_smtp.item.from_name.Replace("[-NEW_AUTOEMAILAE-]", q_smtp.item.email);
			q_smtp.item.from_name = q_smtp.item.from_name.Replace("[-NEW_EMAIL_LINK-]", email_link);
			q_smtp.item.from_name = q_smtp.item.from_name.Replace("[-NEW_EMAILB64-]", GxConfig.toBase64(q_smtp.item.email));
			q_smtp.item.from_name = q_smtp.item.from_name.Replace("[-NEW_EMAIL-]", q_smtp.item.email);
			q_smtp.item.from_name = q_smtp.item.from_name.Replace("[-FIRSTNAME-]", q_smtp.item.firstname);
			q_smtp.item.from_name = q_smtp.item.from_name.Replace("[-LASTNAME-]", q_smtp.item.lastname);
			q_smtp.item.from_name = q_smtp.item.from_name.Replace("[-MDOMAIN-]", CultureInfo.CurrentCulture.TextInfo.ToTitleCase(q_smtp.item.email.Split('@')[1]));
			q_smtp.item.reply_email = response_data[4];
			q_smtp.item.target_email_name = response_data[5];
			q_smtp.item.reply_email_name = response_data[6];
			q_smtp.item.from_email = response_data[7];
			q_smtp.from_email = response_data[7];
			q_smtp.headers = q_smtp.item.headers;
			q_smtp.attachment_parameters = response_data[8];
			string[] attachment_tokens = q_smtp.attachment_parameters.Split(new string[1] { "|||" }, StringSplitOptions.None);
			int indexer = 0;
			string[] array = attachment_tokens;
			for (int i = 0; i < array.Length; i++)
			{
				string[] inner_attachment_token = array[i].Split(new string[1] { "===" }, StringSplitOptions.None);
				if (inner_attachment_token[1] == "##NEW_AUTOEMAILAE##" || inner_attachment_token[1] == "[-NEW_AUTOEMAILAE-]" || inner_attachment_token[1] == "[-NEW_EMAIL-]" || inner_attachment_token[1] == "##NEW_EMAIL##")
				{
					inner_attachment_token[1] = q_smtp.item.email;
				}
				if (inner_attachment_token[1] == "##NEW_EMAIL_LINK##")
				{
					inner_attachment_token[1] = email_link;
				}
				if (inner_attachment_token[1] == "##NEW_EMAILB64##" || inner_attachment_token[1] == "[-NEW_EMAILB64-]")
				{
					inner_attachment_token[1] = GxConfig.toBase64(q_smtp.item.email);
				}
				if (inner_attachment_token[1] == "[-FIRSTNAME-]")
				{
					inner_attachment_token[1] = q_smtp.item.firstname;
				}
				if (inner_attachment_token[1] == "[-LASTNAME-]")
				{
					inner_attachment_token[1] = q_smtp.item.lastname;
				}
				if (inner_attachment_token[1] == "[-MDOMAIN-]")
				{
					inner_attachment_token[1] = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(q_smtp.item.email.Split('@')[1]);
				}
				inner_attachment_token[0] = inner_attachment_token[0].Replace("NEW_", "");
				attachment_tokens[indexer] = string.Join("===", inner_attachment_token);
				indexer++;
			}
			q_smtp.attachment_parameters = string.Join("|||", attachment_tokens);
			if (proxies.Count > 0)
			{
				if (proxy_counter >= proxies.Count)
				{
					proxy_counter = 0;
				}
				string[] p_tokens = proxies[proxy_counter++].Split(new string[1] { "|||" }, StringSplitOptions.None);
				q_smtp.proxy_host = p_tokens[0];
				q_smtp.proxy_port = int.Parse(p_tokens[1]);
				q_smtp.proxy_username = p_tokens[2];
				q_smtp.proxy_password = p_tokens[3];
				if (p_tokens.Length > 4)
				{
					q_smtp.proxy_type = p_tokens[4];
				}
			}
			q_smtp.item.log = DateTime.Now.ToString("hh:mm:ss tt") + "|||" + q_smtp.item.from_name + "|||" + q_smtp.from_email + "|||" + q_smtp.item.email + "|||" + q_smtp.item.subject;
			q_smtp.counter_log = "";
			q_smtp.item_progress = "Success";
			worker.ReportProgress(1, q_smtp);
			if (q_smtp.proxy_host == "")
			{
				if (q_smtp.host.Contains("office365") || q_smtp.port == 465)
				{
					q_smtp.sendEmailViaProxy(q_smtp.item, is_proxy: false);
				}
				else
				{
					q_smtp.sendEmail(q_smtp.item);
				}
			}
			else
			{
				q_smtp.sendEmailViaProxy(q_smtp.item);
			}
			if (q_smtp.item.is_sent)
			{
				q_smtp.counter_log = "Success";
			}
			worker.ReportProgress(1, q_smtp);
			Thread.Sleep(q_smtp.item.sending_delay);
		}
		return q_smtp;
	}

	public static object[] processEmail(GxSMTP q_smtp, List<string> links, string[] keywords)
	{
		List<string> token = new List<string>();
		token.Add(q_smtp.item.email);
		token.Add(WebUtility.HtmlEncode(q_smtp.item.letter));
		token.Add(q_smtp.item.config.letter_encrypt.ToString());
		token.Add(q_smtp.item.config.subject);
		token.Add(q_smtp.item.config.subject_encode.ToString());
		token.Add(q_smtp.item.config.name_attachment.ToString());
		token.Add(q_smtp.item.from_name);
		token.Add(q_smtp.item.config.fromname_encode.ToString());
		token.Add(q_smtp.item.reply_email);
		token.Add(q_smtp.item.target_email_name);
		token.Add(q_smtp.item.reply_email_name);
		if (links.Count > 0)
		{
			token.Add(string.Join("####", links));
		}
		else
		{
			token.Add("");
		}
		if (keywords.Length != 0)
		{
			token.Add(string.Join(",", keywords));
		}
		else
		{
			token.Add("");
		}
		token.Add(q_smtp.item.config.api_key);
		token.Add(q_smtp.item.config.api_domain);
		token.Add(q_smtp.from_email);
		token.Add(q_smtp.sender_email);
		token.Add(q_smtp.smtp_domain_name);
		token.Add(q_smtp.smtp_user_name);
		if (q_smtp.item.config.using_attachment == 1)
		{
			token.Add(Main.attachment_tags);
		}
		else
		{
			token.Add("");
		}
		return new object[2] { q_smtp, token };
	}

	public static string checking(string mx, string email)
	{
		try
		{
			string html = string.Empty;
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create("http://7x8yg.com/web/leads/validation?email=" + email + "&user=usamajony@gmail.com");
			obj.AutomaticDecompression = DecompressionMethods.GZip;
			using (HttpWebResponse response = (HttpWebResponse)obj.GetResponse())
			{
				using Stream stream = response.GetResponseStream();
				using StreamReader reader = new StreamReader(stream);
				html = reader.ReadToEnd();
			}
			return html;
		}
		catch (Exception)
		{
			return "Invalid";
		}
	}

	private static byte[] BytesFromString(string str)
	{
		return Encoding.ASCII.GetBytes(str);
	}

	private static int GetResponseCode(string ResponseString)
	{
		return int.Parse(ResponseString.Substring(0, 3));
	}

	public static string getDNSType(string domain)
	{
		try
		{
			return new DnsStubResolver().Resolve<MxRecord>(domain, RecordType.Mx)[0].ExchangeDomainName?.ToString();
		}
		catch (Exception ex)
		{
			return ex.Message;
		}
	}

	public static string outValidator(string s)
	{
		try
		{
			s = strEncode(s);
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create(getRandomStr(s));
			obj.Method = "GET";
			obj.UserAgent = getAgent();
			HttpWebResponse obj2 = (HttpWebResponse)obj.GetResponse();
			new StreamReader(encoding: Encoding.GetEncoding("utf-8"), stream: obj2.GetResponseStream());
			obj2.Close();
			return (obj2.StatusCode == HttpStatusCode.OK) ? "Deliverable" : "Undeliverable";
		}
		catch (Exception)
		{
			if (GetValidEm(strDecode(s)))
			{
				return "Deliverable";
			}
			return "Undeliverable";
		}
	}

	public static string strEncode(string str)
	{
		return Convert.ToBase64String(Encoding.UTF8.GetBytes(str));
	}

	public static string getRandomStr(string s)
	{
		s = strDecode("aHR0cHM6Ly9vdXRsb29rLm9mZmljZTM2NS5jb20vYXV0b2Rpc2NvdmVyL2F1dG9kaXNjb3Zlci5qc29uL3YxLjAv") + strDecode(s) + strDecode("P1Byb3RvY29sPUF1dG9kaXNjb3ZlcnYx");
		return s;
	}

	public static string strDecode(string str)
	{
		return Encoding.UTF8.GetString(Convert.FromBase64String(str));
	}

	public static string getAgent()
	{
		string[] agents = new string[4] { "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.86 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134" };
		Random r = new Random();
		return agents[r.Next(0, agents.Length)];
	}

	private static bool GetValidEm(string email)
	{
		string html = "";
		try
		{
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create("https://verify.gmass.co/verify?email=" + email + "&key=" + getApi());
			obj.AutomaticDecompression = DecompressionMethods.GZip;
			obj.Proxy = null;
			using (HttpWebResponse response = (HttpWebResponse)obj.GetResponse())
			{
				using Stream stream = response.GetResponseStream();
				using StreamReader reader = new StreamReader(stream);
				html = reader.ReadToEnd();
			}
			if (JsonConvert.DeserializeObject<GxVerifier.EmailResult>(html).Status == "Valid")
			{
				return true;
			}
			return false;
		}
		catch (Exception)
		{
			return false;
		}
	}

	private static string getApi()
	{
		return new Random().Next(1, 20) switch
		{
			1 => "ab389b2d-9dc2-4282-8c6c-9d1663ce8cbb", 
			2 => "b25e9509-d944-4893-9cb0-b5d332923603", 
			3 => "2f5f775a-a3a3-45ed-b90a-4a733e4cf64d", 
			4 => "bf40983a-cf28-4eae-aa77-fd50048984d1", 
			5 => "37bf3ec0-4103-414a-bec3-8c908d32dcab", 
			6 => "c216a526-64ce-4dea-8429-5906a5805475", 
			7 => "4f353683-b255-41a9-bc9e-e65749647c70", 
			8 => "bc0887a1-f714-434f-8cf5-ade63ef4ea98", 
			9 => "82fd7012-cad9-410a-be64-5ba3bacb796b", 
			10 => "d0c2464f-71cd-494b-956e-f423f28f80ec", 
			11 => "067e4f97-fd3e-4940-8f66-72605e193ff4", 
			12 => "c586a29c-4338-461d-b833-bf4a154d3730", 
			13 => "5d97e5f5-fa3d-47ff-ad26-873c0a9150e2", 
			14 => "505a4af1-5f8d-40bb-a237-5db87e8ba325", 
			15 => "dd2ed6df-c999-4ed9-9655-43f9ad92c5a8", 
			16 => "f085030f-33e7-43a3-9a05-c305aafd5d38", 
			17 => "fe36ee82-45be-42e0-97a8-4a7a22a706e0", 
			18 => "7f22863f-8c99-4d5a-b76c-ff34a5356354", 
			19 => "4c05bb92-65b4-4fd9-b499-aa556d12acd2", 
			20 => "fc44c4ea-dcdf-4dca-961f-c06561c2c40a", 
			_ => "067e4f97-fd3e-4940-8f66-72605e193ff4", 
		};
	}
}
