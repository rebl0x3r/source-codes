using System.Globalization;
using System.Linq;
using System.Management;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using Microsoft.VisualBasic;

namespace CommonSender;

public class GxHardware
{
	protected class WMI_CLASSES
	{
		public static readonly string[] MOTHERBOARD = new string[4] { "Win32_BaseBoard", "Name", "Manufacturer", "Version" };

		public static readonly string[] GPU = new string[4] { "Win32_VideoController", "Name", "DeviceID", "DriverVersion" };

		public static readonly string[] CDROM = new string[4] { "Win32_CDROMDrive", "Name", "Manufacturer", "DeviceID" };

		public static readonly string[] CPU = new string[4] { "Win32_Processor", "Name", "Manufacturer", "ProcessorId" };

		public static readonly string[] HDD = new string[4] { "Win32_DiskDrive", "Name", "Manufacturer", "Model" };

		public static readonly string[] BIOS = new string[4] { "Win32_BIOS", "Name", "Manufacturer", "Version" };
	}

	public string LastID { get; set; }

	public string Generate()
	{
		string[] strArray = new string[3]
		{
			GetProperties(WMI_CLASSES.MOTHERBOARD),
			GetProperties(WMI_CLASSES.BIOS),
			GetProperties(WMI_CLASSES.CPU)
		};
		LastID = GetHash(string.Join(string.Empty, strArray));
		return LastID;
	}

	public string GetProperties(string[] wmiData)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("root\\CIMV2", GenerateQuery(wmiData)))
			{
				using ManagementObjectCollection objectCollection = managementObjectSearcher.Get();
				try
				{
					ManagementObjectCollection.ManagementObjectEnumerator enumerator = objectCollection.GetEnumerator();
					while (enumerator.MoveNext())
					{
						ManagementObject current = (ManagementObject)enumerator.Current;
						using (current)
						{
							int num = wmiData.Length - 1;
							for (int index = 1; index <= num; index++)
							{
								stringBuilder.Append(RuntimeHelpers.GetObjectValue(current[wmiData[index]]));
							}
						}
					}
				}
				finally
				{
					ManagementObjectCollection.ManagementObjectEnumerator enumerator = null;
				}
			}
			return stringBuilder.ToString();
		}
	}

	private string GenerateQuery(string[] wmiData)
	{
		StringBuilder stringBuilder = new StringBuilder();
		string empty = string.Empty;
		stringBuilder.Append("SELECT ");
		checked
		{
			int num = wmiData.Length - 1;
			for (int index = 0; index <= num; index++)
			{
				if (index == 0)
				{
					empty = wmiData[index];
				}
				else
				{
					stringBuilder.Append((index < wmiData.Length - 1) ? $"{wmiData[index]}, " : $"{wmiData[index]} ");
				}
			}
			stringBuilder.Append($"FROM {empty}");
			return stringBuilder.ToString();
		}
	}

	private string GetHash(string data)
	{
		using SHA1CryptoServiceProvider cryptoServiceProvider = new SHA1CryptoServiceProvider();
		return GetHexString(cryptoServiceProvider.ComputeHash(Encoding.UTF8.GetBytes(data)));
	}

	private string GetHexString(byte[] bt)
	{
		StringBuilder stringBuilder1 = new StringBuilder();
		checked
		{
			int num1 = bt.Count() - 1;
			for (int index = 0; index <= num1; index++)
			{
				byte num4 = bt[index];
				int num2 = num4 & 0xF;
				int num3 = unchecked((byte)((uint)num4 >> 4)) & 0xF;
				if (num3 > 9)
				{
					string str2 = Strings.ChrW(num3 - 10 + 65).ToString(CultureInfo.InvariantCulture);
					stringBuilder1.Append(str2);
				}
				else
				{
					stringBuilder1.Append(num3.ToString(CultureInfo.InvariantCulture));
				}
				if (num2 > 9)
				{
					string str = Strings.ChrW(num2 - 10 + 65).ToString(CultureInfo.InvariantCulture);
					stringBuilder1.Append(str);
				}
				else
				{
					stringBuilder1.Append(num2.ToString(CultureInfo.InvariantCulture));
				}
				if (index + 1 != bt.Count() && unchecked(checked(index + 1) % 2) == 0)
				{
					stringBuilder1.Append("-");
				}
			}
			return stringBuilder1.ToString();
		}
	}

	public string getMotherboard()
	{
		return GetProperties(WMI_CLASSES.MOTHERBOARD);
	}

	public string getBIOS()
	{
		return GetProperties(WMI_CLASSES.BIOS);
	}

	public string getCPU()
	{
		return GetProperties(WMI_CLASSES.CPU);
	}
}
