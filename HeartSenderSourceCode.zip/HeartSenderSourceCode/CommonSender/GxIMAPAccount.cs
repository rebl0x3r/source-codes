using System;

namespace CommonSender;

[Serializable]
public class GxIMAPAccount
{
	public string server_name;

	public string username;

	public string password;

	public int port;

	public int limit;

	public bool is_ssl;
}
