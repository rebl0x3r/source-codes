<?php


$dbcon = mysql_connect("localhost","jeruueve_nexus","blid12345") or die("mysql not connected");
$dbselect = mysql_select_db("jeruueve_nexus",$dbcon) or die("database not found");



?>