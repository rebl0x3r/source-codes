=== Plugin Name ===
Contributors: HotThemes
Donate link: https://hot-themes.com/
Tags: gutenberg, blocks, accordion, header, parallax, map, google-map, button
Requires at least: 5.0
Tested up to: 5.2
Stable tag: 1.0.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A collection of several blocks for new WordPress editor (Gutenberg).

== Description ==

Hot Blocks plugin by [HotThemes](http://hot-themes.com/ "HotThemes") is a collection of several blocks for new WordPress editor (Gutenberg). Currently, this plugin adds 6 new blocks in new category called Hot Blocks.

Hot Header block is useful if you want to add a header with background image and overlay color to your pages with a big heading (h1) and some intro text (it's recommeded to use page template that doesn't display page title).

Hot Parallax is a placeholder for other blocks. If you select a background image for the Hot Parallax block, it will use a parallax scrolling effect.

Hot Accordion block contains heading and placeholder for other blocks below the heading. User can reveal or hide the content below the heading by clicking on it. It's useful for FAQ pages and for pages with a lot of content.

Hot Map block allows you to include a Google Map to your post or page simply by entering address or point of interest. It supports align-wide.

There are also some simpler blocks like button with custom dimensions and font size, background color block container, and wide text block that allows your paragraph to use full screen width (only if theme supports align-wide).

== Installation ==

1. Install plugin as usually from WordPress.org. You can also manually download it, unpack and upload `plugin_hot_blocks` directory to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. You will see a new blocks category named as Hot Blocks in the pane with blocks.
4. Add any of these blocks to your post/page by clicking on it.
5. Some blocks have parameters in Block controls pane.

== Frequently Asked Questions ==

= What to do with plugin after installation? =

Create or edit a post or page. Click Add Block button, look for Hot Blocks category and add blocks by clicking on them.

= There's no align-wide option? =

Make sure that your theme supports align-wide (older themes usually don't support this).

== Screenshots ==

== Changelog ==

= 1.0 =
* The initial release

== Upgrade Notice ==

= 1.0 =
The initial release