<?php
/**
 * Plugin Name: Hot Blocks
 * Description: Gutenberg blocks by HotThemes.
 * Version: 1.0.7
 * Author: HotThemes
 * Author URI: https://hot-themes.com
 *
 * @package hotblocks
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// create blocks category
add_filter( 'block_categories', function( $categories, $post ) {
    return array_merge(
        $categories,
        array(
            array(
                'slug' => 'hot-blocks',
                'title' => __( 'Hot Blocks', 'hot-blocks' ),
            ),
        )
    );
}, 10, 2 );

// assets for editor
function hot_blocks_editor_assets() {
    wp_enqueue_script(
        'hotblocks',
        plugins_url( 'build/index.build.js', __FILE__ ),
        array( 'wp-blocks', 'wp-element', 'wp-editor' )
    );
    wp_enqueue_style(
        'font-awesome',
        plugins_url( 'css/font-awesome.min.css', __FILE__ ),
        array( 'wp-edit-blocks' )
    );
    wp_enqueue_style(
		'hotblocks-editor-style',
        plugins_url( 'css/editor.css', __FILE__ ),
        array( 'wp-edit-blocks' )
	);
};
add_action( 'enqueue_block_editor_assets', 'hot_blocks_editor_assets');

// assets for front-end
function hot_blocks_assets() {
    wp_enqueue_script(
        'hotblocks-js',
        plugins_url( 'js/hot_blocks.js', __FILE__ ),
        array( 'wp-blocks', 'wp-element', 'wp-editor' )
    );
    wp_enqueue_style(
		'hotblocks',
        plugins_url( 'css/view.css', __FILE__ )
	);
}
add_action( 'enqueue_block_assets', 'hot_blocks_assets');

